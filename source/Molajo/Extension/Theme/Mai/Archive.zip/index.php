<?php
use Molajo\Service\Services;
/**
 * @package    Molajo
 * @copyright  2012 Babs Gösgens. All rights reserved.
 * @license    GNU GPL v 2, or later and MIT, see License folder
 * <include:profiler/>
 */
defined('MOLAJO') or die; ?>
<include:head/>

<dl class="tabs">
   <dd class="active"><a href="<?php echo $_SERVER['REQUEST_URI'] ?>#simple1">Simple Tab 1</a></dd>
   <dd><a href="<?php echo $_SERVER['REQUEST_URI'] ?>#simple2">Simple Tab 2</a></dd>
   <dd><a href="<?php echo $_SERVER['REQUEST_URI'] ?>#simple3">Simple Tab 3</a></dd>
</dl>

<ul class="tabs-content">
   <li class="active" id="simple1Tab">This is simple tab 1's content. Pretty neat, huh?</li>
   <li id="simple2Tab">This is simple tab 2's content. Now you see it!</li>
   <li id="simple3Tab">This is simple tab 3's content. It's, you know...okay.</li>
</ul>

<!-- loading jquery manually cuz it's not yetin my theme's head -->
<script src="/source/Molajo/Extension/Theme/Mai/js/fallback/jquery.min.js"></script>
<include:defer/>
