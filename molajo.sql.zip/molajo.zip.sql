-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2011 at 11:35 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `molajo`
--

-- --------------------------------------------------------

--
-- Table structure for table `molajo_actions`
--

CREATE TABLE `molajo_actions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `title` varchar(255) NOT NULL DEFAULT ' ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_actions_table_title` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `molajo_actions`
--

INSERT INTO `molajo_actions` VALUES(7, 'admin');
INSERT INTO `molajo_actions` VALUES(2, 'create');
INSERT INTO `molajo_actions` VALUES(6, 'delete');
INSERT INTO `molajo_actions` VALUES(4, 'edit');
INSERT INTO `molajo_actions` VALUES(1, 'login');
INSERT INTO `molajo_actions` VALUES(5, 'publish');
INSERT INTO `molajo_actions` VALUES(3, 'view');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_applications`
--

CREATE TABLE `molajo_applications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Application Primary Key',
  `name` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `path` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL Alias',
  `description` mediumtext,
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `custom_fields` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `molajo_applications`
--

INSERT INTO `molajo_applications` VALUES(1, 'site', '', 'Primary application for site visitors', '{}', '{}');
INSERT INTO `molajo_applications` VALUES(2, 'administrator', 'administrator', 'Administrative site area for site construction', '{}', '{}');
INSERT INTO `molajo_applications` VALUES(3, 'content', 'content', 'Area for content development', '{}', '{}');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_application_extension_instances`
--

CREATE TABLE `molajo_application_extension_instances` (
  `application_id` int(11) unsigned NOT NULL,
  `extension_instance_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`application_id`,`extension_instance_id`),
  KEY `fk_application_extensions_applications2` (`application_id`),
  KEY `fk_application_extensions_extension_instances2` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_application_extension_instances`
--

INSERT INTO `molajo_application_extension_instances` VALUES(1, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 5);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 7);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 12);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 13);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 15);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 17);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 33);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 34);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 36);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 37);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 38);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 39);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 40);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 41);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 42);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 43);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 44);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 45);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 46);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 47);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 48);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 49);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 50);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 51);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 52);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 53);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 54);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 55);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 56);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 57);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 58);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 59);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 60);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 61);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 62);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 63);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 64);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 65);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 66);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 67);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 68);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 69);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 70);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 71);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 72);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 73);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 74);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 75);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 76);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 77);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 78);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 79);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 80);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 81);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 82);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 83);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 84);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 85);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 86);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 87);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 88);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 89);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 90);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 91);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 92);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 93);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 94);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 95);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 108);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 111);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 112);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 114);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 117);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 121);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 124);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 125);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 126);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 128);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 129);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 132);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 137);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 138);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 169);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 170);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 171);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 172);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 173);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 174);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 175);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 176);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 177);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 178);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 179);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 180);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 181);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 182);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 183);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 184);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 185);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 186);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 187);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 188);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 189);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 190);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 191);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 192);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 193);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 194);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 195);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 196);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 197);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 198);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 199);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 200);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 201);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 202);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 203);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 204);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 205);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 206);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 207);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 208);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 209);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 210);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 232);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 235);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 240);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 3);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 4);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 5);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 6);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 7);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 8);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 9);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 10);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 11);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 12);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 13);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 14);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 15);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 16);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 17);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 18);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 33);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 34);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 36);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 37);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 38);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 39);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 40);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 41);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 42);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 43);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 44);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 45);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 46);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 47);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 48);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 49);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 50);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 51);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 52);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 53);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 54);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 55);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 56);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 57);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 58);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 59);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 60);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 61);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 62);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 63);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 64);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 65);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 66);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 67);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 68);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 69);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 70);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 71);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 72);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 73);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 74);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 75);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 76);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 77);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 78);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 79);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 80);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 81);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 82);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 83);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 84);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 85);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 86);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 87);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 88);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 89);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 90);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 91);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 92);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 93);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 94);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 95);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 109);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 111);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 112);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 114);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 117);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 121);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 123);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 124);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 125);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 126);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 127);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 128);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 129);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 132);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 136);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 137);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 169);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 170);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 171);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 172);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 173);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 174);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 175);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 176);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 177);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 178);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 179);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 180);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 181);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 182);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 183);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 184);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 185);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 186);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 187);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 188);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 189);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 190);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 191);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 192);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 193);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 194);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 195);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 196);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 197);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 198);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 199);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 200);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 201);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 202);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 203);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 204);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 205);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 206);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 207);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 208);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 209);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 210);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 234);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 235);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 239);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 5);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 7);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 12);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 13);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 15);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 17);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 33);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 34);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 36);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 37);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 38);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 39);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 40);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 41);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 42);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 43);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 44);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 45);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 46);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 47);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 48);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 49);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 50);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 51);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 52);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 53);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 54);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 55);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 56);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 57);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 58);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 59);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 60);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 61);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 62);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 63);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 64);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 65);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 66);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 67);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 68);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 69);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 70);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 71);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 72);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 73);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 74);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 75);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 76);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 77);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 78);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 79);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 80);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 81);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 82);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 83);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 84);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 85);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 86);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 87);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 88);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 89);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 90);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 91);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 92);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 93);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 94);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 95);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 108);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 111);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 112);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 114);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 117);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 121);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 124);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 125);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 126);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 128);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 129);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 132);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 137);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 138);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 169);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 170);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 171);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 172);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 173);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 174);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 175);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 176);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 177);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 178);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 179);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 180);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 181);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 182);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 183);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 184);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 185);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 186);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 187);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 188);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 189);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 190);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 191);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 192);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 193);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 194);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 195);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 196);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 197);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 198);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 199);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 200);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 201);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 202);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 203);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 204);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 205);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 206);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 207);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 208);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 209);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 210);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 232);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 235);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 240);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_assets`
--

CREATE TABLE `molajo_assets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Assets Primary Key',
  `source_table_id` int(11) unsigned NOT NULL DEFAULT '0',
  `source_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Content Primary Key',
  `title` varchar(255) NOT NULL DEFAULT ' ',
  `sef_request` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL',
  `request` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'The actually link the menu item refers to.',
  `primary_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `redirect_to_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_group_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__groupings table',
  PRIMARY KEY (`id`),
  KEY `fk_assets_source_tables2` (`source_table_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=287 ;

--
-- Dumping data for table `molajo_assets`
--

INSERT INTO `molajo_assets` VALUES(1, 2, 1, 'ROOT', 'categories/1', 'index.php?option=com_categories&id=1', 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(2, 2, 2, 'Articles', 'categories/2', 'index.php?option=com_categories&id=2', 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(4, 6, 4, 'Administrator', '', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(5, 6, 2, 'Guest', '', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(6, 6, 1, 'Public', '', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(7, 6, 3, 'Registered', '', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(11, 1, 1, 'site', '', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(12, 1, 2, 'administrator', 'administrator', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(13, 1, 3, 'content', 'content', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(14, 1, 1, 'Core', '', '', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(15, 4, 2, 'com_articles', 'extensions/components/2', 'index.php?option=com_extensions&view=components&id=2', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(16, 4, 3, 'com_assets', 'extensions/components/3', 'index.php?option=com_extensions&view=components&id=3', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(17, 4, 4, 'com_categories', 'extensions/components/4', 'index.php?option=com_extensions&view=components&id=4', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(18, 4, 5, 'com_comments', 'extensions/components/5', 'index.php?option=com_extensions&view=components&id=5', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(19, 4, 6, 'com_configuration', 'extensions/components/6', 'index.php?option=com_extensions&view=components&id=6', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(20, 4, 7, 'com_contacts', 'extensions/components/7', 'index.php?option=com_extensions&view=components&id=7', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(21, 4, 8, 'com_dashboard', 'extensions/components/8', 'index.php?option=com_extensions&view=components&id=8', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(22, 4, 9, 'com_extensions', 'extensions/components/9', 'index.php?option=com_extensions&view=components&id=9', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(23, 4, 10, 'com_groups', 'extensions/components/10', 'index.php?option=com_extensions&view=components&id=10', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(24, 4, 11, 'com_installer', 'extensions/components/11', 'index.php?option=com_extensions&view=components&id=11', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(25, 4, 12, 'com_layouts', 'extensions/components/12', 'index.php?option=com_extensions&view=components&id=12', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(26, 4, 13, 'com_login', 'extensions/components/13', 'index.php?option=com_extensions&view=components&id=13', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(27, 4, 14, 'com_maintain', 'extensions/components/14', 'index.php?option=com_extensions&view=components&id=14', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(28, 4, 15, 'com_media', 'extensions/components/15', 'index.php?option=com_extensions&view=components&id=15', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(29, 4, 16, 'com_profile', 'extensions/components/16', 'index.php?option=com_extensions&view=components&id=16', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(30, 4, 17, 'com_search', 'extensions/components/17', 'index.php?option=com_extensions&view=components&id=17', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(31, 4, 18, 'com_users', 'extensions/components/18', 'index.php?option=com_extensions&view=components&id=18', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(46, 4, 19, 'English (UK)', 'extensions/languages/19', 'index.php?option=com_extensions&view=languages&id=19', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(47, 4, 20, 'English (US)', 'extensions/languages/20', 'index.php?option=com_extensions&view=languages&id=20', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(49, 4, 21, 'head', 'extensions/layouts/21', 'index.php?option=com_extensions&view=layouts&id=21', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(50, 4, 22, 'messages', 'extensions/layouts/22', 'index.php?option=com_extensions&view=layouts&id=22', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(51, 4, 23, 'errors', 'extensions/layouts/23', 'index.php?option=com_extensions&view=layouts&id=23', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(52, 4, 24, 'atom', 'extensions/layouts/24', 'index.php?option=com_extensions&view=layouts&id=24', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(53, 4, 25, 'rss', 'extensions/layouts/25', 'index.php?option=com_extensions&view=layouts&id=25', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(54, 4, 26, 'admin_acl_panel', 'extensions/layouts/26', 'index.php?option=com_extensions&view=layouts&id=26', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(55, 4, 27, 'admin_activity', 'extensions/layouts/27', 'index.php?option=com_extensions&view=layouts&id=27', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(56, 4, 28, 'admin_dashboard', 'extensions/layouts/28', 'index.php?option=com_extensions&view=layouts&id=28', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(57, 4, 29, 'admin_edit', 'extensions/layouts/29', 'index.php?option=com_extensions&view=layouts&id=29', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(58, 4, 30, 'admin_favorites', 'extensions/layouts/30', 'index.php?option=com_extensions&view=layouts&id=30', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(59, 4, 31, 'admin_feed', 'extensions/layouts/31', 'index.php?option=com_extensions&view=layouts&id=31', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(60, 4, 32, 'admin_footer', 'extensions/layouts/32', 'index.php?option=com_extensions&view=layouts&id=32', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(61, 4, 33, 'admin_header', 'extensions/layouts/33', 'index.php?option=com_extensions&view=layouts&id=33', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(62, 4, 34, 'admin_inbox', 'extensions/layouts/34', 'index.php?option=com_extensions&view=layouts&id=34', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(63, 4, 35, 'admin_launchpad', 'extensions/layouts/35', 'index.php?option=com_extensions&view=layouts&id=35', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(64, 4, 36, 'admin_list', 'extensions/layouts/36', 'index.php?option=com_extensions&view=layouts&id=36', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(65, 4, 37, 'admin_login', 'extensions/layouts/37', 'index.php?option=com_extensions&view=layouts&id=37', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(66, 4, 38, 'admin_modal', 'extensions/layouts/38', 'index.php?option=com_extensions&view=layouts&id=38', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(67, 4, 39, 'admin_pagination', 'extensions/layouts/39', 'index.php?option=com_extensions&view=layouts&id=39', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(68, 4, 40, 'admin_toolbar', 'extensions/layouts/40', 'index.php?option=com_extensions&view=layouts&id=40', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(69, 4, 41, 'audio', 'extensions/layouts/41', 'index.php?option=com_extensions&view=layouts&id=41', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(70, 4, 42, 'contact_form', 'extensions/layouts/42', 'index.php?option=com_extensions&view=layouts&id=42', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(71, 4, 43, 'default', 'extensions/layouts/43', 'index.php?option=com_extensions&view=layouts&id=43', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(72, 4, 44, 'dummy', 'extensions/layouts/44', 'index.php?option=com_extensions&view=layouts&id=44', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(73, 4, 45, 'faq', 'extensions/layouts/45', 'index.php?option=com_extensions&view=layouts&id=45', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(74, 4, 46, 'item', 'extensions/layouts/46', 'index.php?option=com_extensions&view=layouts&id=46', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(75, 4, 47, 'list', 'extensions/layouts/47', 'index.php?option=com_extensions&view=layouts&id=47', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(76, 4, 48, 'items', 'extensions/layouts/48', 'index.php?option=com_extensions&view=layouts&id=48', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(77, 4, 49, 'list', 'extensions/layouts/49', 'index.php?option=com_extensions&view=layouts&id=49', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(78, 4, 50, 'pagination', 'extensions/layouts/50', 'index.php?option=com_extensions&view=layouts&id=50', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(79, 4, 51, 'social_bookmarks', 'extensions/layouts/51', 'index.php?option=com_extensions&view=layouts&id=51', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(80, 4, 52, 'syntaxhighlighter', 'extensions/layouts/52', 'index.php?option=com_extensions&view=layouts&id=52', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(81, 4, 53, 'table', 'extensions/layouts/53', 'index.php?option=com_extensions&view=layouts&id=53', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(82, 4, 54, 'tree', 'extensions/layouts/54', 'index.php?option=com_extensions&view=layouts&id=54', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(83, 4, 55, 'twig_example', 'extensions/layouts/55', 'index.php?option=com_extensions&view=layouts&id=55', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(84, 4, 56, 'video', 'extensions/layouts/56', 'index.php?option=com_extensions&view=layouts&id=56', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(85, 4, 57, 'button', 'extensions/layouts/57', 'index.php?option=com_extensions&view=layouts&id=57', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(86, 4, 58, 'colorpicker', 'extensions/layouts/58', 'index.php?option=com_extensions&view=layouts&id=58', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(87, 4, 59, 'datepicker', 'extensions/layouts/59', 'index.php?option=com_extensions&view=layouts&id=59', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(88, 4, 60, 'list', 'extensions/layouts/60', 'index.php?option=com_extensions&view=layouts&id=60', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(89, 4, 61, 'media', 'extensions/layouts/61', 'index.php?option=com_extensions&view=layouts&id=61', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(90, 4, 62, 'number', 'extensions/layouts/62', 'index.php?option=com_extensions&view=layouts&id=62', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(91, 4, 63, 'option', 'extensions/layouts/63', 'index.php?option=com_extensions&view=layouts&id=63', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(92, 4, 64, 'rules', 'extensions/layouts/64', 'index.php?option=com_extensions&view=layouts&id=64', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(93, 4, 65, 'spacer', 'extensions/layouts/65', 'index.php?option=com_extensions&view=layouts&id=65', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(94, 4, 66, 'text', 'extensions/layouts/66', 'index.php?option=com_extensions&view=layouts&id=66', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(95, 4, 67, 'textarea', 'extensions/layouts/67', 'index.php?option=com_extensions&view=layouts&id=67', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(96, 4, 68, 'user', 'extensions/layouts/68', 'index.php?option=com_extensions&view=layouts&id=68', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(97, 4, 69, 'article', 'extensions/layouts/69', 'index.php?option=com_extensions&view=layouts&id=69', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(98, 4, 70, 'aside', 'extensions/layouts/70', 'index.php?option=com_extensions&view=layouts&id=70', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(99, 4, 71, 'div', 'extensions/layouts/71', 'index.php?option=com_extensions&view=layouts&id=71', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(100, 4, 72, 'footer', 'extensions/layouts/72', 'index.php?option=com_extensions&view=layouts&id=72', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(101, 4, 73, 'header', 'extensions/layouts/73', 'index.php?option=com_extensions&view=layouts&id=73', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(102, 4, 74, 'horizontal', 'extensions/layouts/74', 'index.php?option=com_extensions&view=layouts&id=74', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(103, 4, 75, 'nav', 'extensions/layouts/75', 'index.php?option=com_extensions&view=layouts&id=75', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(104, 4, 76, 'none', 'extensions/layouts/76', 'index.php?option=com_extensions&view=layouts&id=76', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(105, 4, 77, 'outline', 'extensions/layouts/77', 'index.php?option=com_extensions&view=layouts&id=77', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(106, 4, 78, 'section', 'extensions/layouts/78', 'index.php?option=com_extensions&view=layouts&id=78', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(107, 4, 79, 'table', 'extensions/layouts/79', 'index.php?option=com_extensions&view=layouts&id=79', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(108, 4, 80, 'tabs', 'extensions/layouts/80', 'index.php?option=com_extensions&view=layouts&id=80', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(112, 4, 81, 'Doctrine', 'extensions/libraries/81', 'index.php?option=com_extensions&view=libraries&id=81', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(113, 4, 82, 'includes', 'extensions/libraries/82', 'index.php?option=com_extensions&view=libraries&id=82', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(114, 4, 83, 'jplatform', 'extensions/libraries/83', 'index.php?option=com_extensions&view=libraries&id=83', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(115, 4, 84, 'molajo', 'extensions/libraries/84', 'index.php?option=com_extensions&view=libraries&id=84', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(116, 4, 85, 'Twig', 'extensions/libraries/85', 'index.php?option=com_extensions&view=libraries&id=85', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(119, 4, 86, 'mod_assetwidget', 'extensions/modules/86', 'index.php?option=com_extensions&view=modules&id=86', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(120, 4, 87, 'mod_aclwidget', 'extensions/modules/87', 'index.php?option=com_extensions&view=modules&id=87', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(121, 4, 88, 'mod_breadcrumbs', 'extensions/modules/88', 'index.php?option=com_extensions&view=modules&id=88', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(122, 4, 89, 'mod_debug', 'extensions/modules/89', 'index.php?option=com_extensions&view=modules&id=89', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(123, 4, 90, 'mod_categorywidget', 'extensions/modules/90', 'index.php?option=com_extensions&view=modules&id=90', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(124, 4, 91, 'mod_content', 'extensions/modules/91', 'index.php?option=com_extensions&view=modules&id=91', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(125, 4, 92, 'mod_custom', 'extensions/modules/92', 'index.php?option=com_extensions&view=modules&id=92', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(126, 4, 93, 'mod_groupwidget', 'extensions/modules/93', 'index.php?option=com_extensions&view=modules&id=93', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(127, 4, 94, 'mod_feed', 'extensions/modules/94', 'index.php?option=com_extensions&view=modules&id=94', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(128, 4, 95, 'mod_filters', 'extensions/modules/95', 'index.php?option=com_extensions&view=modules&id=95', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(129, 4, 96, 'mod_filebrowser', 'extensions/modules/96', 'index.php?option=com_extensions&view=modules&id=96', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(130, 4, 97, 'mod_footer', 'extensions/modules/97', 'index.php?option=com_extensions&view=modules&id=97', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(131, 4, 98, 'mod_gallery', 'extensions/modules/98', 'index.php?option=com_extensions&view=modules&id=98', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(132, 4, 99, 'mod_grid', 'extensions/modules/99', 'index.php?option=com_extensions&view=modules&id=99', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(133, 4, 100, 'mod_gridbatch', 'extensions/modules/100', 'index.php?option=com_extensions&view=modules&id=100', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(134, 4, 101, 'mod_header', 'extensions/modules/101', 'index.php?option=com_extensions&view=modules&id=101', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(135, 4, 102, 'mod_iconbutton', 'extensions/modules/102', 'index.php?option=com_extensions&view=modules&id=102', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(136, 4, 103, 'mod_launchpad', 'extensions/modules/103', 'index.php?option=com_extensions&view=modules&id=103', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(137, 4, 104, 'mod_layout', 'extensions/modules/104', 'index.php?option=com_extensions&view=modules&id=104', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(138, 4, 105, 'mod_login', 'extensions/modules/105', 'index.php?option=com_extensions&view=modules&id=105', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(139, 4, 106, 'mod_logout', 'extensions/modules/106', 'index.php?option=com_extensions&view=modules&id=106', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(140, 4, 107, 'mod_members', 'extensions/modules/107', 'index.php?option=com_extensions&view=modules&id=107', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(141, 4, 108, 'mod_menu', 'extensions/modules/108', 'index.php?option=com_extensions&view=modules&id=108', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(142, 4, 109, 'mod_pagination', 'extensions/modules/109', 'index.php?option=com_extensions&view=modules&id=109', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(143, 4, 110, 'mod_plugins', 'extensions/modules/110', 'index.php?option=com_extensions&view=modules&id=110', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(144, 4, 111, 'mod_quicklinks', 'extensions/modules/111', 'index.php?option=com_extensions&view=modules&id=111', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(145, 4, 112, 'mod_search', 'extensions/modules/112', 'index.php?option=com_extensions&view=modules&id=112', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(146, 4, 113, 'mod_submenu', 'extensions/modules/113', 'index.php?option=com_extensions&view=modules&id=113', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(147, 4, 114, 'mod_textbox', 'extensions/modules/114', 'index.php?option=com_extensions&view=modules&id=114', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(148, 4, 115, 'mod_title', 'extensions/modules/115', 'index.php?option=com_extensions&view=modules&id=115', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(149, 4, 116, 'mod_toolbar', 'extensions/modules/116', 'index.php?option=com_extensions&view=modules&id=116', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(150, 4, 117, 'mod_search', 'extensions/modules/117', 'index.php?option=com_extensions&view=modules&id=117', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(151, 4, 118, 'mod_syndicate', 'extensions/modules/118', 'index.php?option=com_extensions&view=modules&id=118', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(182, 4, 119, 'example', 'extensions/plugins/119', 'index.php?option=com_extensions&view=plugins&id=119', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(183, 4, 120, 'molajo', 'extensions/plugins/120', 'index.php?option=com_extensions&view=plugins&id=120', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(184, 4, 121, 'broadcast', 'extensions/plugins/121', 'index.php?option=com_extensions&view=plugins&id=121', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(185, 4, 122, 'content', 'extensions/plugins/122', 'index.php?option=com_extensions&view=plugins&id=122', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(186, 4, 123, 'emailcloak', 'extensions/plugins/123', 'index.php?option=com_extensions&view=plugins&id=123', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(187, 4, 124, 'links', 'extensions/plugins/124', 'index.php?option=com_extensions&view=plugins&id=124', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(188, 4, 125, 'loadmodule', 'extensions/plugins/125', 'index.php?option=com_extensions&view=plugins&id=125', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(189, 4, 126, 'media', 'extensions/plugins/126', 'index.php?option=com_extensions&view=plugins&id=126', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(190, 4, 127, 'protect', 'extensions/plugins/127', 'index.php?option=com_extensions&view=plugins&id=127', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(191, 4, 128, 'responses', 'extensions/plugins/128', 'index.php?option=com_extensions&view=plugins&id=128', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(192, 4, 129, 'aloha', 'extensions/plugins/129', 'index.php?option=com_extensions&view=plugins&id=129', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(193, 4, 130, 'none', 'extensions/plugins/130', 'index.php?option=com_extensions&view=plugins&id=130', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(194, 4, 131, 'article', 'extensions/plugins/131', 'index.php?option=com_extensions&view=plugins&id=131', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(195, 4, 132, 'editor', 'extensions/plugins/132', 'index.php?option=com_extensions&view=plugins&id=132', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(196, 4, 133, 'image', 'extensions/plugins/133', 'index.php?option=com_extensions&view=plugins&id=133', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(197, 4, 134, 'pagebreak', 'extensions/plugins/134', 'index.php?option=com_extensions&view=plugins&id=134', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(198, 4, 135, 'readmore', 'extensions/plugins/135', 'index.php?option=com_extensions&view=plugins&id=135', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(199, 4, 136, 'molajo', 'extensions/plugins/136', 'index.php?option=com_extensions&view=plugins&id=136', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(200, 4, 137, 'extend', 'extensions/plugins/137', 'index.php?option=com_extensions&view=plugins&id=137', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(201, 4, 138, 'minifier', 'extensions/plugins/138', 'index.php?option=com_extensions&view=plugins&id=138', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(202, 4, 139, 'search', 'extensions/plugins/139', 'index.php?option=com_extensions&view=plugins&id=139', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(203, 4, 140, 'tags', 'extensions/plugins/140', 'index.php?option=com_extensions&view=plugins&id=140', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(204, 4, 141, 'urls', 'extensions/plugins/141', 'index.php?option=com_extensions&view=plugins&id=141', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(205, 4, 142, 'molajosample', 'extensions/plugins/142', 'index.php?option=com_extensions&view=plugins&id=142', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(206, 4, 143, 'categories', 'extensions/plugins/143', 'index.php?option=com_extensions&view=plugins&id=143', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(207, 4, 144, 'articles', 'extensions/plugins/144', 'index.php?option=com_extensions&view=plugins&id=144', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(208, 4, 145, 'cache', 'extensions/plugins/145', 'index.php?option=com_extensions&view=plugins&id=145', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(209, 4, 146, 'compress', 'extensions/plugins/146', 'index.php?option=com_extensions&view=plugins&id=146', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(210, 4, 147, 'create', 'extensions/plugins/147', 'index.php?option=com_extensions&view=plugins&id=147', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(211, 4, 148, 'debug', 'extensions/plugins/148', 'index.php?option=com_extensions&view=plugins&id=148', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(212, 4, 149, 'languagefilter', 'extensions/plugins/149', 'index.php?option=com_extensions&view=plugins&id=149', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(213, 4, 150, 'log', 'extensions/plugins/150', 'index.php?option=com_extensions&view=plugins&id=150', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(214, 4, 151, 'logout', 'extensions/plugins/151', 'index.php?option=com_extensions&view=plugins&id=151', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(215, 4, 152, 'molajo', 'extensions/plugins/152', 'index.php?option=com_extensions&view=plugins&id=152', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(216, 4, 153, 'p3p', 'extensions/plugins/153', 'index.php?option=com_extensions&view=plugins&id=153', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(217, 4, 154, 'parameters', 'extensions/plugins/154', 'index.php?option=com_extensions&view=plugins&id=154', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(218, 4, 155, 'redirect', 'extensions/plugins/155', 'index.php?option=com_extensions&view=plugins&id=155', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(219, 4, 156, 'remember', 'extensions/plugins/156', 'index.php?option=com_extensions&view=plugins&id=156', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(220, 4, 157, 'system', 'extensions/plugins/157', 'index.php?option=com_extensions&view=plugins&id=157', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(221, 4, 158, 'webservices', 'extensions/plugins/158', 'index.php?option=com_extensions&view=plugins&id=158', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(222, 4, 159, 'molajo', 'extensions/plugins/159', 'index.php?option=com_extensions&view=plugins&id=159', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(223, 4, 160, 'profile', 'extensions/plugins/160', 'index.php?option=com_extensions&view=plugins&id=160', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(245, 4, 161, 'construct', 'extensions/templates/161', 'index.php?option=com_extensions&view=templates&id=161', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(246, 4, 162, 'install', 'extensions/templates/162', 'index.php?option=com_extensions&view=templates&id=162', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(247, 4, 163, 'molajito', 'extensions/templates/163', 'index.php?option=com_extensions&view=templates&id=163', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(248, 4, 164, 'system', 'extensions/templates/164', 'index.php?option=com_extensions&view=templates&id=164', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(252, 4, 165, 'Admin', 'extensions/menus/165', 'index.php?option=com_extensions&view=menus&id=165', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(253, 4, 166, 'Main Menu', 'extensions/menus/166', 'index.php?option=com_extensions&view=menus&id=166', 1, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(255, 10, 2, 'Content', 'index.php?option=com_dashboard&view=content', 'content', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(256, 10, 3, 'Articles', 'index.php?option=com_articles', 'content/articles', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(257, 10, 4, 'Contacts', 'index.php?option=com_contacts', 'content/contacts', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(258, 10, 5, 'Comments', 'index.php?option=com_comments', 'content/comments', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(259, 10, 6, 'Layouts', 'index.php?option=com_layouts', 'content/layouts', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(260, 10, 7, 'Media', 'index.php?option=com_media', 'content/media', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(261, 10, 8, 'Users', 'index.php?option=com_dashboard&view=users', 'users', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(262, 10, 9, 'Profile', 'index.php?option=com_profile', 'users/profiles', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(263, 10, 10, 'Users', 'index.php?option=com_users', 'users/users', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(264, 10, 11, 'Groups', 'index.php?option=com_groups', 'users/groups', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(265, 10, 12, 'Assets', 'index.php?option=com_assets&view=users', 'users/assets', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(266, 10, 13, 'Interface', 'index.php?option=com_dashboard&view=interface', 'interface', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(267, 10, 14, 'Categories', 'index.php?option=com_categories', 'interface/categories', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(268, 10, 15, 'Menus', 'index.php?option=com_extensions&view=menus', 'interface/menus', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(269, 10, 16, 'Menu Items', 'index.php?option=com_extensions&view=menuitems', 'interface/menuitems', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(270, 10, 17, 'Modules', 'index.php?option=com_extensions&view=modules', 'interface/modules', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(271, 10, 18, 'Templates', 'index.php?option=com_extensions&view=templates', 'interface/templates', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(272, 10, 19, 'Options', 'index.php?option=com_dashboard&view=options', 'options', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(273, 10, 20, 'Site', 'index.php?option=com_extensions&view=sites', 'options/sites', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(274, 10, 21, 'Applications', 'index.php?option=com_extensions&view=applications', 'options/applications', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(275, 10, 22, 'Checkin', 'index.php?option=com_maintain&view=checkin', 'options/checkin', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(276, 10, 23, 'Clean Cache', 'index.php?option=com_maintain&view=cleancache', 'options/cleancache', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(277, 10, 24, 'Redirects', 'index.php?option=com_maintain&view=redirects', 'options/redirects', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(278, 10, 25, 'Plugins', 'index.php?option=com_extensions&view=plugins', 'options/plugins', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(279, 10, 26, 'Install', 'index.php?option=com_dashboard&view=install', 'install', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(280, 10, 27, 'Create', 'index.php?option=com_installer&view=create', 'install/create', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(281, 10, 28, 'Install', 'index.php?option=com_installer&view=install', 'install/install', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(282, 10, 29, 'Discover', 'index.php?option=com_installer&view=discover', 'install/discover', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(283, 10, 30, 'Update', 'index.php?option=com_installer&view=update', 'install/update', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(284, 10, 31, 'Uninstall', 'index.php?option=com_installer&view=uninstall', 'install/uninstall', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(285, 10, 32, 'Search', 'index.php?option=com_search', 'search', 1, 'en-GB', 0, 0, 2);
INSERT INTO `molajo_assets` VALUES(286, 10, 33, 'Home', 'index.php?option=com_layouts', 'home', 1, 'en-GB', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_asset_categories`
--

CREATE TABLE `molajo_asset_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `asset_id` int(11) unsigned NOT NULL DEFAULT '0',
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_content_categories_categories2` (`category_id`),
  KEY `fk_asset_categories_assets2` (`asset_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=256 ;

--
-- Dumping data for table `molajo_asset_categories`
--

INSERT INTO `molajo_asset_categories` VALUES(1, 4, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(2, 5, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(3, 6, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(4, 7, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(5, 11, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(6, 12, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(7, 13, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(8, 14, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(9, 15, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(10, 16, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(11, 17, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(12, 18, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(13, 19, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(14, 20, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(15, 21, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(16, 22, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(17, 23, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(18, 24, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(19, 25, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(20, 26, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(21, 27, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(22, 28, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(23, 29, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(24, 30, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(25, 31, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(26, 46, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(27, 47, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(28, 49, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(29, 50, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(30, 51, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(31, 52, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(32, 53, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(33, 54, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(34, 55, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(35, 56, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(36, 57, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(37, 58, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(38, 59, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(39, 60, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(40, 61, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(41, 62, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(42, 63, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(43, 64, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(44, 65, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(45, 66, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(46, 67, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(47, 68, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(48, 69, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(49, 70, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(50, 71, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(51, 72, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(52, 73, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(53, 74, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(54, 75, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(55, 76, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(56, 77, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(57, 78, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(58, 79, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(59, 80, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(60, 81, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(61, 82, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(62, 83, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(63, 84, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(64, 85, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(65, 86, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(66, 87, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(67, 88, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(68, 89, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(69, 90, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(70, 91, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(71, 92, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(72, 93, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(73, 94, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(74, 95, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(75, 96, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(76, 97, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(77, 98, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(78, 99, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(79, 100, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(80, 101, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(81, 102, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(82, 103, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(83, 104, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(84, 105, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(85, 106, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(86, 107, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(87, 108, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(88, 112, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(89, 113, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(90, 114, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(91, 115, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(92, 116, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(93, 119, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(94, 120, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(95, 121, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(96, 122, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(97, 123, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(98, 124, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(99, 125, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(100, 126, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(101, 127, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(102, 128, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(103, 129, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(104, 130, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(105, 131, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(106, 132, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(107, 133, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(108, 134, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(109, 135, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(110, 136, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(111, 137, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(112, 138, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(113, 139, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(114, 140, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(115, 141, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(116, 142, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(117, 143, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(118, 144, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(119, 145, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(120, 146, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(121, 147, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(122, 148, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(123, 149, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(124, 150, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(125, 151, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(126, 182, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(127, 183, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(128, 184, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(129, 185, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(130, 186, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(131, 187, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(132, 188, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(133, 189, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(134, 190, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(135, 191, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(136, 192, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(137, 193, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(138, 194, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(139, 195, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(140, 196, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(141, 197, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(142, 198, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(143, 199, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(144, 200, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(145, 201, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(146, 202, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(147, 203, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(148, 204, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(149, 205, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(150, 206, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(151, 207, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(152, 208, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(153, 209, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(154, 210, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(155, 211, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(156, 212, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(157, 213, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(158, 214, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(159, 215, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(160, 216, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(161, 217, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(162, 218, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(163, 219, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(164, 220, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(165, 221, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(166, 222, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(167, 223, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(168, 245, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(169, 246, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(170, 247, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(171, 248, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(172, 252, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(173, 253, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(174, 255, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(175, 256, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(176, 257, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(177, 258, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(178, 259, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(179, 260, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(180, 261, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(181, 262, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(182, 263, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(183, 264, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(184, 265, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(185, 266, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(186, 267, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(187, 268, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(188, 269, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(189, 270, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(190, 271, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(191, 272, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(192, 273, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(193, 274, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(194, 275, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(195, 276, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(196, 277, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(197, 278, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(198, 279, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(199, 280, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(200, 281, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(201, 282, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(202, 283, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(203, 284, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(204, 285, 1, 1);
INSERT INTO `molajo_asset_categories` VALUES(205, 286, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_categories`
--

CREATE TABLE `molajo_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `content_text` mediumtext,
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `start_publishing_datetime` datetime DEFAULT '0000-00-00 00:00:00',
  `stop_publishing_datetime` datetime DEFAULT '0000-00-00 00:00:00',
  `version` int(11) unsigned NOT NULL DEFAULT '0',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `metakey` text COMMENT 'The meta keywords for the page.',
  `metadesc` text COMMENT 'The meta description for the page.',
  `metadata` text COMMENT 'JSON encoded metadata properties.',
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`status`),
  KEY `idx_checkout` (`checked_out_by`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `molajo_categories`
--

INSERT INTO `molajo_categories` VALUES(1, 'ROOT', '', 'root', '<p>Root category</p>', 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_categories` VALUES(2, 'Articles', 'com_articles', 'articles', '<p>Category for Articles</p>', 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, 2, 1, NULL, NULL, NULL, NULL, NULL, 'en-GB', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_content`
--

CREATE TABLE `molajo_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT '' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'URL Alias',
  `content_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Content Type: Links to #__configuration.option_id = 10 and component_option values matching ',
  `content_text` mediumtext COMMENT 'Content Primary Text Field, can include break to designate Introductory and Full text',
  `content_link` varchar(2083) DEFAULT NULL COMMENT 'Content Link for Weblink or Newsfeed Field',
  `content_email_address` varchar(255) DEFAULT NULL COMMENT 'Content Email Field',
  `content_numeric_value` tinyint(4) DEFAULT NULL COMMENT 'Content Numeric Value, ex. vote on poll',
  `content_file` varchar(255) NOT NULL DEFAULT '' COMMENT 'Content Network Path to File',
  `user_default` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'User DEFAULT 1-DEFAULT 0-Not DEFAULT',
  `category_default` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Category DEFAULT 1-DEFAULT 0-Not DEFAULT',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Featured 1-Featured 0-Not Featured',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Stickied 1-Stickied 0-Not Stickied',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created by Alias',
  `created_by_email` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Email Address',
  `created_by_website` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Website',
  `created_by_ip_address` char(15) NOT NULL DEFAULT '' COMMENT 'Created By IP Address',
  `created_by_referer` varchar(255) NOT NULL DEFAULT '' COMMENT 'Created By Referer',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Nested set parent',
  `lft` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Nested set lft',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Nested set rgt',
  `level` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'The cached level in the nested tree',
  `metakey` text COMMENT 'Meta Key',
  `metadesc` text COMMENT 'Meta Description',
  `metadata` text COMMENT 'Meta Data',
  `custom_fields` mediumtext COMMENT 'Attributes (Custom Fields)',
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `language` char(7) DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `idx_component_component_id_id` (`id`),
  KEY `idx_checkout` (`checked_out_by`),
  KEY `idx_state` (`status`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`),
  KEY `idx_stickied_catid` (`stickied`),
  KEY `fk_content_extension_instances2` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `molajo_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_extensions`
--

CREATE TABLE `molajo_extensions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `extension_type_id` int(11) unsigned NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(255) NOT NULL,
  `update_site_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_extensions_extension_types2` (`extension_type_id`),
  KEY `fk_extensions_update_sites2` (`update_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=167 ;

--
-- Dumping data for table `molajo_extensions`
--

INSERT INTO `molajo_extensions` VALUES(1, 'Core', 0, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(2, 'com_articles', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(3, 'com_assets', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(4, 'com_categories', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(5, 'com_comments', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(6, 'com_configuration', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(7, 'com_contacts', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(8, 'com_dashboard', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(9, 'com_extensions', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(10, 'com_groups', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(11, 'com_installer', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(12, 'com_layouts', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(13, 'com_login', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(14, 'com_maintain', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(15, 'com_media', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(16, 'com_profile', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(17, 'com_search', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(18, 'com_users', 1, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(19, 'English (UK)', 2, 'en-UK', '', 1);
INSERT INTO `molajo_extensions` VALUES(20, 'English (US)', 2, 'en-US', '', 1);
INSERT INTO `molajo_extensions` VALUES(21, 'head', 3, '', 'document', 1);
INSERT INTO `molajo_extensions` VALUES(22, 'messages', 3, '', 'document', 1);
INSERT INTO `molajo_extensions` VALUES(23, 'errors', 3, '', 'document', 1);
INSERT INTO `molajo_extensions` VALUES(24, 'atom', 3, '', 'document', 1);
INSERT INTO `molajo_extensions` VALUES(25, 'rss', 3, '', 'document', 1);
INSERT INTO `molajo_extensions` VALUES(26, 'admin_acl_panel', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(27, 'admin_activity', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(28, 'admin_dashboard', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(29, 'admin_edit', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(30, 'admin_favorites', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(31, 'admin_feed', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(32, 'admin_footer', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(33, 'admin_header', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(34, 'admin_inbox', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(35, 'admin_launchpad', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(36, 'admin_list', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(37, 'admin_login', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(38, 'admin_modal', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(39, 'admin_pagination', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(40, 'admin_toolbar', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(41, 'audio', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(42, 'contact_form', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(43, 'default', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(44, 'dummy', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(45, 'faq', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(46, 'item', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(47, 'list', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(48, 'items', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(49, 'list', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(50, 'pagination', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(51, 'social_bookmarks', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(52, 'syntaxhighlighter', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(53, 'table', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(54, 'tree', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(55, 'twig_example', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(56, 'video', 3, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(57, 'button', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(58, 'colorpicker', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(59, 'datepicker', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(60, 'list', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(61, 'media', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(62, 'number', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(63, 'option', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(64, 'rules', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(65, 'spacer', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(66, 'text', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(67, 'textarea', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(68, 'user', 3, '', 'formfields', 1);
INSERT INTO `molajo_extensions` VALUES(69, 'article', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(70, 'aside', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(71, 'div', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(72, 'footer', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(73, 'header', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(74, 'horizontal', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(75, 'nav', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(76, 'none', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(77, 'outline', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(78, 'section', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(79, 'table', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(80, 'tabs', 3, '', 'wrap', 1);
INSERT INTO `molajo_extensions` VALUES(81, 'Doctrine', 10, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(82, 'includes', 10, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(83, 'jplatform', 10, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(84, 'molajo', 10, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(85, 'Twig', 10, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(86, 'mod_assetwidget', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(87, 'mod_aclwidget', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(88, 'mod_breadcrumbs', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(89, 'mod_debug', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(90, 'mod_categorywidget', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(91, 'mod_content', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(92, 'mod_custom', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(93, 'mod_groupwidget', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(94, 'mod_feed', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(95, 'mod_filters', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(96, 'mod_filebrowser', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(97, 'mod_footer', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(98, 'mod_gallery', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(99, 'mod_grid', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(100, 'mod_gridbatch', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(101, 'mod_header', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(102, 'mod_iconbutton', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(103, 'mod_launchpad', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(104, 'mod_layout', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(105, 'mod_login', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(106, 'mod_logout', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(107, 'mod_members', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(108, 'mod_menu', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(109, 'mod_pagination', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(110, 'mod_plugins', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(111, 'mod_quicklinks', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(112, 'mod_search', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(113, 'mod_submenu', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(114, 'mod_textbox', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(115, 'mod_title', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(116, 'mod_toolbar', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(117, 'mod_search', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(118, 'mod_syndicate', 6, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(119, 'example', 8, '', 'acl', 1);
INSERT INTO `molajo_extensions` VALUES(120, 'molajo', 8, '', 'authentication', 1);
INSERT INTO `molajo_extensions` VALUES(121, 'broadcast', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(122, 'content', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(123, 'emailcloak', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(124, 'links', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(125, 'loadmodule', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(126, 'media', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(127, 'protect', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(128, 'responses', 8, '', 'content', 1);
INSERT INTO `molajo_extensions` VALUES(129, 'aloha', 8, '', 'editors', 1);
INSERT INTO `molajo_extensions` VALUES(130, 'none', 8, '', 'editors', 1);
INSERT INTO `molajo_extensions` VALUES(131, 'article', 8, '', 'editor-buttons', 1);
INSERT INTO `molajo_extensions` VALUES(132, 'editor', 8, '', 'editor-buttons', 1);
INSERT INTO `molajo_extensions` VALUES(133, 'image', 8, '', 'editor-buttons', 1);
INSERT INTO `molajo_extensions` VALUES(134, 'pagebreak', 8, '', 'editor-buttons', 1);
INSERT INTO `molajo_extensions` VALUES(135, 'readmore', 8, '', 'editor-buttons', 1);
INSERT INTO `molajo_extensions` VALUES(136, 'molajo', 8, '', 'extension', 1);
INSERT INTO `molajo_extensions` VALUES(137, 'extend', 8, '', 'molajo', 1);
INSERT INTO `molajo_extensions` VALUES(138, 'minifier', 8, '', 'molajo', 1);
INSERT INTO `molajo_extensions` VALUES(139, 'search', 8, '', 'molajo', 1);
INSERT INTO `molajo_extensions` VALUES(140, 'tags', 8, '', 'molajo', 1);
INSERT INTO `molajo_extensions` VALUES(141, 'urls', 8, '', 'molajo', 1);
INSERT INTO `molajo_extensions` VALUES(142, 'molajosample', 8, '', 'query', 1);
INSERT INTO `molajo_extensions` VALUES(143, 'categories', 8, '', 'search', 1);
INSERT INTO `molajo_extensions` VALUES(144, 'articles', 8, '', 'search', 1);
INSERT INTO `molajo_extensions` VALUES(145, 'cache', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(146, 'compress', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(147, 'create', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(148, 'debug', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(149, 'languagefilter', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(150, 'log', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(151, 'logout', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(152, 'molajo', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(153, 'p3p', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(154, 'parameters', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(155, 'redirect', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(156, 'remember', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(157, 'system', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(158, 'webservices', 8, '', 'system', 1);
INSERT INTO `molajo_extensions` VALUES(159, 'molajo', 8, '', 'user', 1);
INSERT INTO `molajo_extensions` VALUES(160, 'profile', 8, '', 'user', 1);
INSERT INTO `molajo_extensions` VALUES(161, 'construct', 9, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(162, 'install', 9, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(163, 'molajito', 9, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(164, 'system', 9, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(165, 'Admin', 5, '', '', 1);
INSERT INTO `molajo_extensions` VALUES(166, 'Main Menu', 5, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extension_instances`
--

CREATE TABLE `molajo_extension_instances` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key for Component Content',
  `extension_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext COMMENT 'Content Primary Text Field, can include break to designate Introductory and Full text',
  `protected` tinyint(4) NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `position` varchar(50) NOT NULL DEFAULT ' ' COMMENT 'User DEFAULT 1-DEFAULT 0-Not DEFAULT',
  `language` char(7) DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `idx_component_component_id_id` (`extension_id`,`id`),
  KEY `idx_checkout` (`checked_out_by`),
  KEY `idx_state` (`status`),
  KEY `idx_createdby` (`created_by`),
  KEY `fk_extension_instances_extensions2` (`extension_id`),
  KEY `fk_extension_instances_extension_types2` (`extension_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=242 ;

--
-- Dumping data for table `molajo_extension_instances`
--

INSERT INTO `molajo_extension_instances` VALUES(1, 1, 0, 'Core', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instances` VALUES(2, 2, 1, 'com_articles', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instances` VALUES(3, 3, 1, 'com_assets', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instances` VALUES(4, 4, 1, 'com_categories', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instances` VALUES(5, 5, 1, 'com_comments', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instances` VALUES(6, 6, 1, 'com_configuration', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instances` VALUES(7, 7, 1, 'com_contacts', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instances` VALUES(8, 8, 1, 'com_dashboard', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instances` VALUES(9, 9, 1, 'com_extensions', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instances` VALUES(10, 10, 1, 'com_groups', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instances` VALUES(11, 11, 1, 'com_installer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instances` VALUES(12, 12, 1, 'com_layouts', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instances` VALUES(13, 13, 1, 'com_login', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instances` VALUES(14, 14, 1, 'com_maintain', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instances` VALUES(15, 15, 1, 'com_media', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instances` VALUES(16, 16, 1, 'com_profile', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instances` VALUES(17, 17, 1, 'com_search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instances` VALUES(18, 18, 1, 'com_users', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instances` VALUES(33, 19, 2, 'English (UK)', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instances` VALUES(34, 20, 2, 'English (US)', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instances` VALUES(36, 21, 3, 'head', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instances` VALUES(37, 22, 3, 'messages', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instances` VALUES(38, 23, 3, 'errors', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instances` VALUES(39, 24, 3, 'atom', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instances` VALUES(40, 25, 3, 'rss', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instances` VALUES(41, 26, 3, 'admin_acl_panel', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instances` VALUES(42, 27, 3, 'admin_activity', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instances` VALUES(43, 28, 3, 'admin_dashboard', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instances` VALUES(44, 29, 3, 'admin_edit', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instances` VALUES(45, 30, 3, 'admin_favorites', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instances` VALUES(46, 31, 3, 'admin_feed', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instances` VALUES(47, 32, 3, 'admin_footer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instances` VALUES(48, 33, 3, 'admin_header', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instances` VALUES(49, 34, 3, 'admin_inbox', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 34);
INSERT INTO `molajo_extension_instances` VALUES(50, 35, 3, 'admin_launchpad', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 35);
INSERT INTO `molajo_extension_instances` VALUES(51, 36, 3, 'admin_list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 36);
INSERT INTO `molajo_extension_instances` VALUES(52, 37, 3, 'admin_login', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 37);
INSERT INTO `molajo_extension_instances` VALUES(53, 38, 3, 'admin_modal', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 38);
INSERT INTO `molajo_extension_instances` VALUES(54, 39, 3, 'admin_pagination', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 39);
INSERT INTO `molajo_extension_instances` VALUES(55, 40, 3, 'admin_toolbar', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 40);
INSERT INTO `molajo_extension_instances` VALUES(56, 41, 3, 'audio', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 41);
INSERT INTO `molajo_extension_instances` VALUES(57, 42, 3, 'contact_form', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 42);
INSERT INTO `molajo_extension_instances` VALUES(58, 43, 3, 'default', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 43);
INSERT INTO `molajo_extension_instances` VALUES(59, 44, 3, 'dummy', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 44);
INSERT INTO `molajo_extension_instances` VALUES(60, 45, 3, 'faq', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 45);
INSERT INTO `molajo_extension_instances` VALUES(61, 46, 3, 'item', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 46);
INSERT INTO `molajo_extension_instances` VALUES(62, 47, 3, 'list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 47);
INSERT INTO `molajo_extension_instances` VALUES(63, 48, 3, 'items', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 48);
INSERT INTO `molajo_extension_instances` VALUES(64, 49, 3, 'list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 49);
INSERT INTO `molajo_extension_instances` VALUES(65, 50, 3, 'pagination', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 50);
INSERT INTO `molajo_extension_instances` VALUES(66, 51, 3, 'social_bookmarks', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 51);
INSERT INTO `molajo_extension_instances` VALUES(67, 52, 3, 'syntaxhighlighter', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 52);
INSERT INTO `molajo_extension_instances` VALUES(68, 53, 3, 'table', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 53);
INSERT INTO `molajo_extension_instances` VALUES(69, 54, 3, 'tree', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 54);
INSERT INTO `molajo_extension_instances` VALUES(70, 55, 3, 'twig_example', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 55);
INSERT INTO `molajo_extension_instances` VALUES(71, 56, 3, 'video', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 56);
INSERT INTO `molajo_extension_instances` VALUES(72, 57, 3, 'button', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 57);
INSERT INTO `molajo_extension_instances` VALUES(73, 58, 3, 'colorpicker', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 58);
INSERT INTO `molajo_extension_instances` VALUES(74, 59, 3, 'datepicker', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 59);
INSERT INTO `molajo_extension_instances` VALUES(75, 60, 3, 'list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 60);
INSERT INTO `molajo_extension_instances` VALUES(76, 61, 3, 'media', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 61);
INSERT INTO `molajo_extension_instances` VALUES(77, 62, 3, 'number', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 62);
INSERT INTO `molajo_extension_instances` VALUES(78, 63, 3, 'option', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 63);
INSERT INTO `molajo_extension_instances` VALUES(79, 64, 3, 'rules', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 64);
INSERT INTO `molajo_extension_instances` VALUES(80, 65, 3, 'spacer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 65);
INSERT INTO `molajo_extension_instances` VALUES(81, 66, 3, 'text', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 66);
INSERT INTO `molajo_extension_instances` VALUES(82, 67, 3, 'textarea', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 67);
INSERT INTO `molajo_extension_instances` VALUES(83, 68, 3, 'user', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 68);
INSERT INTO `molajo_extension_instances` VALUES(84, 69, 3, 'article', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 69);
INSERT INTO `molajo_extension_instances` VALUES(85, 70, 3, 'aside', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 70);
INSERT INTO `molajo_extension_instances` VALUES(86, 71, 3, 'div', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 71);
INSERT INTO `molajo_extension_instances` VALUES(87, 72, 3, 'footer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 72);
INSERT INTO `molajo_extension_instances` VALUES(88, 73, 3, 'header', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 73);
INSERT INTO `molajo_extension_instances` VALUES(89, 74, 3, 'horizontal', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 74);
INSERT INTO `molajo_extension_instances` VALUES(90, 75, 3, 'nav', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 75);
INSERT INTO `molajo_extension_instances` VALUES(91, 76, 3, 'none', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 76);
INSERT INTO `molajo_extension_instances` VALUES(92, 77, 3, 'outline', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 77);
INSERT INTO `molajo_extension_instances` VALUES(93, 78, 3, 'section', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 78);
INSERT INTO `molajo_extension_instances` VALUES(94, 79, 3, 'table', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 79);
INSERT INTO `molajo_extension_instances` VALUES(95, 80, 3, 'tabs', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 80);
INSERT INTO `molajo_extension_instances` VALUES(99, 81, 10, 'Doctrine', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 81);
INSERT INTO `molajo_extension_instances` VALUES(100, 82, 10, 'includes', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 82);
INSERT INTO `molajo_extension_instances` VALUES(101, 83, 10, 'jplatform', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 83);
INSERT INTO `molajo_extension_instances` VALUES(102, 84, 10, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 84);
INSERT INTO `molajo_extension_instances` VALUES(103, 85, 10, 'Twig', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 85);
INSERT INTO `molajo_extension_instances` VALUES(106, 86, 6, 'mod_assetwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 86);
INSERT INTO `molajo_extension_instances` VALUES(107, 87, 6, 'mod_aclwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 87);
INSERT INTO `molajo_extension_instances` VALUES(108, 88, 6, 'mod_breadcrumbs', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 88);
INSERT INTO `molajo_extension_instances` VALUES(109, 89, 6, 'mod_debug', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'debug', 'en-GB', 0, 89);
INSERT INTO `molajo_extension_instances` VALUES(110, 90, 6, 'mod_categorywidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 90);
INSERT INTO `molajo_extension_instances` VALUES(111, 91, 6, 'mod_content', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 91);
INSERT INTO `molajo_extension_instances` VALUES(112, 92, 6, 'mod_custom', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 92);
INSERT INTO `molajo_extension_instances` VALUES(113, 93, 6, 'mod_groupwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 93);
INSERT INTO `molajo_extension_instances` VALUES(114, 94, 6, 'mod_feed', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 94);
INSERT INTO `molajo_extension_instances` VALUES(115, 95, 6, 'mod_filters', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'filters', 'en-GB', 0, 95);
INSERT INTO `molajo_extension_instances` VALUES(116, 96, 6, 'mod_filebrowser', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 96);
INSERT INTO `molajo_extension_instances` VALUES(117, 97, 6, 'mod_footer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'footer', 'en-GB', 0, 97);
INSERT INTO `molajo_extension_instances` VALUES(118, 98, 6, 'mod_gallery', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 98);
INSERT INTO `molajo_extension_instances` VALUES(119, 99, 6, 'mod_grid', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'grid', 'en-GB', 0, 99);
INSERT INTO `molajo_extension_instances` VALUES(120, 100, 6, 'mod_gridbatch', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'gridbatch', 'en-GB', 0, 100);
INSERT INTO `molajo_extension_instances` VALUES(121, 101, 6, 'mod_header', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'header', 'en-GB', 0, 101);
INSERT INTO `molajo_extension_instances` VALUES(122, 102, 6, 'mod_iconbutton', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 102);
INSERT INTO `molajo_extension_instances` VALUES(123, 103, 6, 'mod_launchpad', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'launchpad', 'en-GB', 0, 103);
INSERT INTO `molajo_extension_instances` VALUES(124, 104, 6, 'mod_layout', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 104);
INSERT INTO `molajo_extension_instances` VALUES(125, 105, 6, 'mod_login', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 105);
INSERT INTO `molajo_extension_instances` VALUES(126, 106, 6, 'mod_logout', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 106);
INSERT INTO `molajo_extension_instances` VALUES(127, 107, 6, 'mod_members', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 107);
INSERT INTO `molajo_extension_instances` VALUES(128, 108, 6, 'mod_menu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 108);
INSERT INTO `molajo_extension_instances` VALUES(129, 109, 6, 'mod_pagination', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 109);
INSERT INTO `molajo_extension_instances` VALUES(130, 110, 6, 'mod_plugins', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 110);
INSERT INTO `molajo_extension_instances` VALUES(131, 111, 6, 'mod_quicklinks', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 111);
INSERT INTO `molajo_extension_instances` VALUES(132, 112, 6, 'mod_search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 112);
INSERT INTO `molajo_extension_instances` VALUES(133, 113, 6, 'mod_submenu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'submenu', 'en-GB', 0, 113);
INSERT INTO `molajo_extension_instances` VALUES(134, 114, 6, 'mod_textbox', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 114);
INSERT INTO `molajo_extension_instances` VALUES(135, 115, 6, 'mod_title', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'title', 'en-GB', 0, 115);
INSERT INTO `molajo_extension_instances` VALUES(136, 116, 6, 'mod_toolbar', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', 'toolbar', 'en-GB', 0, 116);
INSERT INTO `molajo_extension_instances` VALUES(137, 117, 6, 'mod_search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 117);
INSERT INTO `molajo_extension_instances` VALUES(138, 118, 6, 'mod_syndicate', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 118);
INSERT INTO `molajo_extension_instances` VALUES(169, 119, 8, 'example', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 119);
INSERT INTO `molajo_extension_instances` VALUES(170, 120, 8, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 120);
INSERT INTO `molajo_extension_instances` VALUES(171, 121, 8, 'broadcast', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 121);
INSERT INTO `molajo_extension_instances` VALUES(172, 122, 8, 'content', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 122);
INSERT INTO `molajo_extension_instances` VALUES(173, 123, 8, 'emailcloak', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 123);
INSERT INTO `molajo_extension_instances` VALUES(174, 124, 8, 'links', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 124);
INSERT INTO `molajo_extension_instances` VALUES(175, 125, 8, 'loadmodule', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 125);
INSERT INTO `molajo_extension_instances` VALUES(176, 126, 8, 'media', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 126);
INSERT INTO `molajo_extension_instances` VALUES(177, 127, 8, 'protect', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 127);
INSERT INTO `molajo_extension_instances` VALUES(178, 128, 8, 'responses', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 128);
INSERT INTO `molajo_extension_instances` VALUES(179, 129, 8, 'aloha', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 129);
INSERT INTO `molajo_extension_instances` VALUES(180, 130, 8, 'none', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 130);
INSERT INTO `molajo_extension_instances` VALUES(181, 131, 8, 'article', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 131);
INSERT INTO `molajo_extension_instances` VALUES(182, 132, 8, 'editor', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 132);
INSERT INTO `molajo_extension_instances` VALUES(183, 133, 8, 'image', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 133);
INSERT INTO `molajo_extension_instances` VALUES(184, 134, 8, 'pagebreak', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 134);
INSERT INTO `molajo_extension_instances` VALUES(185, 135, 8, 'readmore', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 135);
INSERT INTO `molajo_extension_instances` VALUES(186, 136, 8, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 136);
INSERT INTO `molajo_extension_instances` VALUES(187, 137, 8, 'extend', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 137);
INSERT INTO `molajo_extension_instances` VALUES(188, 138, 8, 'minifier', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 138);
INSERT INTO `molajo_extension_instances` VALUES(189, 139, 8, 'search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 139);
INSERT INTO `molajo_extension_instances` VALUES(190, 140, 8, 'tags', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 140);
INSERT INTO `molajo_extension_instances` VALUES(191, 141, 8, 'urls', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 141);
INSERT INTO `molajo_extension_instances` VALUES(192, 142, 8, 'molajosample', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 142);
INSERT INTO `molajo_extension_instances` VALUES(193, 143, 8, 'categories', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 143);
INSERT INTO `molajo_extension_instances` VALUES(194, 144, 8, 'articles', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 144);
INSERT INTO `molajo_extension_instances` VALUES(195, 145, 8, 'cache', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 145);
INSERT INTO `molajo_extension_instances` VALUES(196, 146, 8, 'compress', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 146);
INSERT INTO `molajo_extension_instances` VALUES(197, 147, 8, 'create', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 147);
INSERT INTO `molajo_extension_instances` VALUES(198, 148, 8, 'debug', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 148);
INSERT INTO `molajo_extension_instances` VALUES(199, 149, 8, 'languagefilter', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 149);
INSERT INTO `molajo_extension_instances` VALUES(200, 150, 8, 'log', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 150);
INSERT INTO `molajo_extension_instances` VALUES(201, 151, 8, 'logout', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 151);
INSERT INTO `molajo_extension_instances` VALUES(202, 152, 8, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 152);
INSERT INTO `molajo_extension_instances` VALUES(203, 153, 8, 'p3p', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 153);
INSERT INTO `molajo_extension_instances` VALUES(204, 154, 8, 'parameters', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 154);
INSERT INTO `molajo_extension_instances` VALUES(205, 155, 8, 'redirect', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 155);
INSERT INTO `molajo_extension_instances` VALUES(206, 156, 8, 'remember', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 156);
INSERT INTO `molajo_extension_instances` VALUES(207, 157, 8, 'system', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 157);
INSERT INTO `molajo_extension_instances` VALUES(208, 158, 8, 'webservices', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 158);
INSERT INTO `molajo_extension_instances` VALUES(209, 159, 8, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 159);
INSERT INTO `molajo_extension_instances` VALUES(210, 160, 8, 'profile', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 160);
INSERT INTO `molajo_extension_instances` VALUES(232, 161, 9, 'construct', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 161);
INSERT INTO `molajo_extension_instances` VALUES(233, 162, 9, 'install', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 162);
INSERT INTO `molajo_extension_instances` VALUES(234, 163, 9, 'molajito', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 163);
INSERT INTO `molajo_extension_instances` VALUES(235, 164, 9, 'system', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 164);
INSERT INTO `molajo_extension_instances` VALUES(239, 165, 5, 'Admin', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 165);
INSERT INTO `molajo_extension_instances` VALUES(240, 166, 5, 'Main Menu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '{}', '{}', '', 'en-GB', 0, 166);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extension_instance_options`
--

CREATE TABLE `molajo_extension_instance_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `extension_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key for Component Content',
  `extension_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext COMMENT 'Content Primary Text Field, can include break to designate Introductory and Full text',
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `image` varchar(255) NOT NULL,
  `option_id` int(11) unsigned NOT NULL DEFAULT '0',
  `option_value` varchar(80) NOT NULL DEFAULT '',
  `option_value_literal` varchar(255) NOT NULL DEFAULT '',
  `trigger_asset_id` int(11) unsigned NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT ' ' COMMENT 'User DEFAULT 1-DEFAULT 0-Not DEFAULT',
  `menu_item_type` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_extension_instance_options_extension_instances2` (`extension_instance_id`),
  KEY `fk_extension_instance_options_extensions2` (`extension_id`),
  KEY `fk_extension_instance_options_extension_types2` (`extension_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=683 ;

--
-- Dumping data for table `molajo_extension_instance_options`
--

INSERT INTO `molajo_extension_instance_options` VALUES(1, 239, 165, 5, 'Root', ' ', '', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 0, 0, 65, 0, '{}', '{}', 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(2, 239, 165, 5, 'Content', ' ', 'content', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 1, 1, 12, 1, '{}', '{}', 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(3, 239, 165, 5, 'Articles', ' ', 'articles', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 2, 2, 3, 2, '{}', '{}', 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(4, 239, 165, 5, 'Contacts', ' ', 'contacts', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 2, 4, 5, 2, '{}', '{}', 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(5, 239, 165, 5, 'Comments', ' ', 'comments', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 2, 6, 7, 2, '{}', '{}', 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(6, 239, 165, 5, 'Layouts', ' ', 'layouts', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 2, 8, 9, 2, '{}', '{}', 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(7, 239, 165, 5, 'Media', ' ', 'media', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 2, 10, 11, 2, '{}', '{}', 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(8, 239, 165, 5, 'Users', ' ', 'users', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 1, 13, 22, 1, '{}', '{}', 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(9, 239, 165, 5, 'Profile', ' ', 'profile', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 8, 14, 15, 2, '{}', '{}', 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(10, 239, 165, 5, 'Users', ' ', 'users', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 8, 16, 17, 2, '{}', '{}', 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(11, 239, 165, 5, 'Groups', ' ', 'groups', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 8, 18, 19, 2, '{}', '{}', 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(12, 239, 165, 5, 'Assets', ' ', 'assets', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 8, 20, 21, 2, '{}', '{}', 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(13, 239, 165, 5, 'Interface', ' ', 'interface', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 1, 23, 34, 1, '{}', '{}', 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(14, 239, 165, 5, 'Categories', ' ', 'categories', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 13, 24, 25, 2, '{}', '{}', 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(15, 239, 165, 5, 'Menus', ' ', 'menus', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 13, 26, 27, 2, '{}', '{}', 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(16, 239, 165, 5, 'Menu Items', ' ', 'menuitems', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 13, 28, 29, 2, '{}', '{}', 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(17, 239, 165, 5, 'Modules', ' ', 'modules', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 13, 30, 31, 2, '{}', '{}', 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(18, 239, 165, 5, 'Templates', ' ', 'templates', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 13, 32, 33, 2, '{}', '{}', 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(19, 239, 165, 5, 'Options', ' ', 'options', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 1, 35, 48, 1, '{}', '{}', 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(20, 239, 165, 5, 'Site', ' ', 'sites', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 19, 36, 37, 2, '{}', '{}', 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(21, 239, 165, 5, 'Applications', ' ', 'applications', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 19, 38, 39, 2, '{}', '{}', 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(22, 239, 165, 5, 'Checkin', ' ', 'checkin', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 19, 40, 41, 2, '{}', '{}', 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(23, 239, 165, 5, 'Clean Cache', ' ', 'cleancache', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 19, 42, 43, 2, '{}', '{}', 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(24, 239, 165, 5, 'Redirects', ' ', 'redirects', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 19, 44, 45, 2, '{}', '{}', 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(25, 239, 165, 5, 'Plugins', ' ', 'plugins', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 19, 46, 47, 2, '{}', '{}', 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(26, 239, 165, 5, 'Install', ' ', 'install', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 1, 49, 60, 1, '{}', '{}', 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(27, 239, 165, 5, 'Create', ' ', 'create', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 26, 50, 51, 2, '{}', '{}', 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(28, 239, 165, 5, 'Install', ' ', 'install', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 26, 52, 53, 2, '{}', '{}', 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(29, 239, 165, 5, 'Discover', ' ', 'discover', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 26, 54, 55, 2, '{}', '{}', 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(30, 239, 165, 5, 'Update', ' ', 'update', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 26, 56, 57, 2, '{}', '{}', 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instance_options` VALUES(31, 239, 165, 5, 'Uninstall', ' ', 'uninstall', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 26, 58, 59, 2, '{}', '{}', 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instance_options` VALUES(32, 239, 165, 5, 'Search', ' ', 'search', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 1, 61, 62, 1, '{}', '{}', 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instance_options` VALUES(33, 240, 166, 5, 'Home', ' ', 'home', NULL, 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', 0, '', '', 0, '', 1, 1, 63, 64, 1, '{}', '{}', 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instance_options` VALUES(204, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(205, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 100, '__common', '__common', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(206, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(207, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'access', 'MOLAJO_FIELD_ACCESS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(208, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'alias', 'MOLAJO_FIELD_ALIAS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(209, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'asset_id', 'MOLAJO_FIELD_ASSET_ID_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(210, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'attribs', 'MOLAJO_FIELD_ATTRIBS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(211, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'catid', 'MOLAJO_FIELD_CATID_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(212, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'checked_out', 'MOLAJO_FIELD_CHECKED_OUT_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(213, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'checked_out_time', 'MOLAJO_FIELD_CHECKED_OUT_TIME_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(214, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'component_id', 'MOLAJO_FIELD_COMPONENT_ID_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(215, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'content_table', 'MOLAJO_FIELD_CONTENT_TABLE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(216, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'content_email_address', 'MOLAJO_FIELD_CONTENT_EMAIL_ADDRESS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(217, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'content_file', 'MOLAJO_FIELD_CONTENT_FILE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(218, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'content_link', 'MOLAJO_FIELD_CONTENT_LINK_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(219, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'content_numeric_value', 'MOLAJO_FIELD_CONTENT_NUMERIC_VALUE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(220, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'content_text', 'MOLAJO_FIELD_CONTENT_TEXT_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(221, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'content_type', 'MOLAJO_FIELD_CONTENT_TYPE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(222, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'created', 'MOLAJO_FIELD_CREATED_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(223, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'created_by', 'MOLAJO_FIELD_CREATED_BY_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(224, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'created_by_alias', 'MOLAJO_FIELD_CREATED_BY_ALIAS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(225, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'created_by_email', 'MOLAJO_FIELD_CREATED_BY_EMAIL_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(226, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'created_by_ip_address', 'MOLAJO_FIELD_CREATED_BY_IP_ADDRESS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(227, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'created_by_referer', 'MOLAJO_FIELD_CREATED_BY_REFERER_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(228, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'created_by_website', 'MOLAJO_FIELD_CREATED_BY_WEBSITE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(229, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'featured', 'MOLAJO_FIELD_FEATURED_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(230, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'id', 'MOLAJO_FIELD_ID_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(231, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'language', 'MOLAJO_FIELD_LANGUAGE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(232, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'level', 'MOLAJO_FIELD_LEVEL_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(233, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'lft', 'MOLAJO_FIELD_LFT_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(234, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'metadata', 'MOLAJO_FIELD_METADATA_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(235, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'metadesc', 'MOLAJO_FIELD_METADESC_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(236, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'metakey', 'MOLAJO_FIELD_METAKEY_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instance_options` VALUES(237, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'meta_author', 'MOLAJO_FIELD_META_AUTHOR_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instance_options` VALUES(238, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'meta_rights', 'MOLAJO_FIELD_META_RIGHTS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instance_options` VALUES(239, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'meta_robots', 'MOLAJO_FIELD_META_ROBOTS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instance_options` VALUES(240, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'modified', 'MOLAJO_FIELD_MODIFIED_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 34);
INSERT INTO `molajo_extension_instance_options` VALUES(241, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'modified_by', 'MOLAJO_FIELD_MODIFIED_BY_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 35);
INSERT INTO `molajo_extension_instance_options` VALUES(242, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'ordering', 'MOLAJO_FIELD_ORDERING_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 36);
INSERT INTO `molajo_extension_instance_options` VALUES(243, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'stop_publishing_datetime', 'MOLAJO_FIELD_PUBLISH_DOWN_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 37);
INSERT INTO `molajo_extension_instance_options` VALUES(244, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'start_publishing_datetime', 'MOLAJO_FIELD_PUBLISH_UP_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 38);
INSERT INTO `molajo_extension_instance_options` VALUES(245, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'rgt', 'MOLAJO_FIELD_RGT_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 39);
INSERT INTO `molajo_extension_instance_options` VALUES(246, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'state', 'MOLAJO_FIELD_STATE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 40);
INSERT INTO `molajo_extension_instance_options` VALUES(247, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'state_prior_to_version', 'MOLAJO_FIELD_STATE_PRIOR_TO_VERSION_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 41);
INSERT INTO `molajo_extension_instance_options` VALUES(248, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'stickied', 'MOLAJO_FIELD_STICKIED_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 42);
INSERT INTO `molajo_extension_instance_options` VALUES(249, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'user_default', 'MOLAJO_FIELD_USER_DEFAULT_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 43);
INSERT INTO `molajo_extension_instance_options` VALUES(250, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'category_default', 'MOLAJO_FIELD_CATEGORY_DEFAULT_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 44);
INSERT INTO `molajo_extension_instance_options` VALUES(251, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'title', 'MOLAJO_FIELD_TITLE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 45);
INSERT INTO `molajo_extension_instance_options` VALUES(252, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'subtitle', 'MOLAJO_FIELD_SUBTITLE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 46);
INSERT INTO `molajo_extension_instance_options` VALUES(253, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'version', 'MOLAJO_FIELD_VERSION_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 47);
INSERT INTO `molajo_extension_instance_options` VALUES(254, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 200, 'version_of_id', 'MOLAJO_FIELD_VERSION_OF_ID_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 48);
INSERT INTO `molajo_extension_instance_options` VALUES(255, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(256, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, 'access', 'MOLAJO_FIELD_ACCESS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(257, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, 'featured', 'MOLAJO_FIELD_FEATURED_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(258, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, 'ordering', 'MOLAJO_FIELD_ORDERING_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(259, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, 'stop_publishing_datetime', 'MOLAJO_FIELD_PUBLISH_DOWN_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(260, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, 'start_publishing_datetime', 'MOLAJO_FIELD_PUBLISH_UP_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(261, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, 'state', 'MOLAJO_FIELD_STATE_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(262, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 210, 'stickied', 'MOLAJO_FIELD_STICKIED_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(263, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 220, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(264, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 220, 'attribs', 'MOLAJO_FIELD_ATTRIBS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(265, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 220, 'metadata', 'MOLAJO_FIELD_METADATA_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(266, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 220, 'parameters', 'MOLAJO_FIELD_PARAMETERS_LABEL', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(267, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 230, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(268, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 230, 'content_type', 'Content Type', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(269, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 250, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(270, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 250, '2', 'MOLAJO_OPTION_ARCHIVED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(271, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 250, '1', 'MOLAJO_OPTION_PUBLISHED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(272, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 250, '0', 'MOLAJO_OPTION_UNPUBLISHED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(273, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 250, '-1', 'MOLAJO_OPTION_TRASHED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(274, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 250, '-2', 'MOLAJO_OPTION_SPAMMED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(275, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 250, '-10', 'MOLAJO_OPTION_VERSION', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(276, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(277, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'archive', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_ARCHIVE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(278, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'checkin', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_CHECKIN', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(279, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'delete', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_DELETE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(280, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'edit', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_EDIT', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(281, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'feature', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_FEATURE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(282, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'help', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_HELP', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(283, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'new', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_NEW', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(284, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'options', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_OPTIONS', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(285, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'publish', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_PUBLISH', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(286, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'restore', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_RESTORE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(287, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'separator', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SEPARATOR', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(288, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'spam', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SPAM', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(289, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'sticky', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_STICKY', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(290, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'trash', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_TRASH', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(291, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 300, 'unpublish', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_UNPUBLISH', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(292, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(293, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'apply', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_APPLY', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(294, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'close', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_CLOSE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(295, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'help', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_HELP', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(296, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'restore', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_RESTORE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(297, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'save', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SAVE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(298, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'save2new', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SAVE_AND_NEW', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(299, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'save2copy', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SAVE_AS_COPY', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(300, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 310, 'separator', 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SEPARATOR', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(301, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 320, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(302, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 320, 'category', 'MOLAJO_CONFIG_MANAGER_SUB_MENU_CATEGORY', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(303, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 320, 'default', 'MOLAJO_CONFIG_MANAGER_SUB_MENU_DEFAULT', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(304, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 320, 'featured', 'MOLAJO_CONFIG_MANAGER_SUB_MENU_FEATURED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(305, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 320, 'revisions', 'MOLAJO_CONFIG_MANAGER_SUB_MENU_REVISIONS', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(306, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 320, 'stickied', 'MOLAJO_CONFIG_MANAGER_SUB_MENU_STICKIED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(307, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 320, 'unpublished', 'MOLAJO_CONFIG_MANAGER_SUB_MENU_UNPUBLISHED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(308, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(309, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'access', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_ACCESS', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(310, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'alias', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_ALIAS', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(311, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'created_by', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_AUTHOR', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(312, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'catid', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_CATEGORY', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(313, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'content_type', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_CONTENT_TYPE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(314, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'created', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_CREATE_DATE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(315, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'featured', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_FEATURED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(316, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'language', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_LANGUAGE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(317, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'modified', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_UPDATE_DATE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(318, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'start_publishing_datetime', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_PUBLISH_DATE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(319, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'state', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_STATE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(320, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'stickied', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_STICKIED', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(321, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'title', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_TITLE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(322, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 330, 'subtitle', 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_SUBTITLE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(323, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(324, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'article', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_ARTICLE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(325, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'audio', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_AUDIO', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(326, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'file', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_FILE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(327, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'gallery', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_GALLERY', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(328, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'image', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_IMAGE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(329, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'pagebreak', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_PAGEBREAK', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(330, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'readmore', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_READMORE', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(331, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 340, 'video', 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_VIDEO', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(332, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(333, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(334, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'sp-midi', 'sp-midi', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(335, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.3gpp.iufp', 'vnd.3gpp.iufp', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(336, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.4SB', 'vnd.4SB', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(337, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.CELP', 'vnd.CELP', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(338, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.audiokoz', 'vnd.audiokoz', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(339, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.cisco.nse', 'vnd.cisco.nse', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(340, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.cmles.radio-events', 'vnd.cmles.radio-events', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(341, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.cns.anp1', 'vnd.cns.anp1', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(342, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.cns.inf1', 'vnd.cns.inf1', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(343, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dece.audio', 'vnd.dece.audio', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(344, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.digital-winds', 'vnd.digital-winds', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(345, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dlna.adts', 'vnd.dlna.adts', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(346, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.heaac.1', 'vnd.dolby.heaac.1', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(347, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.heaac.2', 'vnd.dolby.heaac.2', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(348, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.mlp', 'vnd.dolby.mlp', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(349, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.mps', 'vnd.dolby.mps', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(350, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.pl2', 'vnd.dolby.pl2', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(351, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.pl2x', 'vnd.dolby.pl2x', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(352, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.pl2z', 'vnd.dolby.pl2z', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(353, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dolby.pulse.1', 'vnd.dolby.pulse.1', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(354, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dra', 'vnd.dra', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(355, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dts', 'vnd.dts', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(356, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dts.hd', 'vnd.dts.hd', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(357, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.dvb.file', 'vnd.dvb.file', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(358, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.everad.plj', 'vnd.everad.plj', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(359, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.hns.audio', 'vnd.hns.audio', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(360, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.lucent.voice', 'vnd.lucent.voice', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(361, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.ms-playready.media.pya', 'vnd.ms-playready.media.pya', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(362, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.nokia.mobile-xmf', 'vnd.nokia.mobile-xmf', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instance_options` VALUES(363, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.nortel.vbk', 'vnd.nortel.vbk', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instance_options` VALUES(364, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.nuera.ecelp4800', 'vnd.nuera.ecelp4800', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instance_options` VALUES(365, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.nuera.ecelp7470', 'vnd.nuera.ecelp7470', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instance_options` VALUES(366, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.nuera.ecelp9600', 'vnd.nuera.ecelp9600', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 34);
INSERT INTO `molajo_extension_instance_options` VALUES(367, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.octel.sbc', 'vnd.octel.sbc', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 35);
INSERT INTO `molajo_extension_instance_options` VALUES(368, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.qcelp', 'vnd.qcelp', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 36);
INSERT INTO `molajo_extension_instance_options` VALUES(369, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.rhetorex.32kadpcm', 'vnd.rhetorex.32kadpcm', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 37);
INSERT INTO `molajo_extension_instance_options` VALUES(370, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.rip', 'vnd.rip', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 38);
INSERT INTO `molajo_extension_instance_options` VALUES(371, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.sealedmedia.softseal-mpeg', 'vnd.sealedmedia.softseal-mpeg', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 39);
INSERT INTO `molajo_extension_instance_options` VALUES(372, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 400, 'vnd.vmx.cvsd', 'vnd.vmx.cvsd', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 40);
INSERT INTO `molajo_extension_instance_options` VALUES(373, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(374, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'cgm', 'cgm', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(375, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'jp2', 'jp2', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(376, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'jpm', 'jpm', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(377, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'jpx', 'jpx', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(378, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'naplps', 'naplps', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(379, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'png', 'png', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(380, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'prs.btif', 'prs.btif', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(381, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'prs.pti', 'prs.pti', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(382, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd-djvu', 'vnd-djvu', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(383, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd-svf', 'vnd-svf', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(384, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd-wap-wbmp', 'vnd-wap-wbmp', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(385, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.adobe.photoshop', 'vnd.adobe.photoshop', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(386, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.cns.inf2', 'vnd.cns.inf2', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(387, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.dece.graphic', 'vnd.dece.graphic', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(388, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.dvb.subtitle', 'vnd.dvb.subtitle', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(389, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.dwg', 'vnd.dwg', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(390, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.dxf', 'vnd.dxf', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(391, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.fastbidsheet', 'vnd.fastbidsheet', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(392, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.fpx', 'vnd.fpx', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(393, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.fst', 'vnd.fst', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(394, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.fujixerox.edmics-mmr', 'vnd.fujixerox.edmics-mmr', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(395, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.fujixerox.edmics-rlc', 'vnd.fujixerox.edmics-rlc', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(396, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.globalgraphics.pgb', 'vnd.globalgraphics.pgb', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(397, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.microsoft.icon', 'vnd.microsoft.icon', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(398, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.mix', 'vnd.mix', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(399, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.ms-modi', 'vnd.ms-modi', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(400, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.net-fpx', 'vnd.net-fpx', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(401, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.radiance', 'vnd.radiance', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(402, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.sealed-png', 'vnd.sealed-png', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(403, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.sealedmedia.softseal-gif', 'vnd.sealedmedia.softseal-gif', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instance_options` VALUES(404, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.sealedmedia.softseal-jpg', 'vnd.sealedmedia.softseal-jpg', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instance_options` VALUES(405, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 410, 'vnd.xiff', 'vnd.xiff', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instance_options` VALUES(406, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(407, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'n3', 'n3', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(408, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'prs.fallenstein.rst', 'prs.fallenstein.rst', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(409, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'prs.lines.tag', 'prs.lines.tag', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(410, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'rtf', 'rtf', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(411, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(412, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'tab-separated-values', 'tab-separated-values', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(413, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'turtle', 'turtle', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(414, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd-curl', 'vnd-curl', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(415, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.DMClientScript', 'vnd.DMClientScript', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(416, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.IPTC.NITF', 'vnd.IPTC.NITF', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(417, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.IPTC.NewsML', 'vnd.IPTC.NewsML', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(418, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.abc', 'vnd.abc', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(419, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.curl', 'vnd.curl', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(420, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.dvb.subtitle', 'vnd.dvb.subtitle', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(421, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.esmertec.theme-descriptor', 'vnd.esmertec.theme-descriptor', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(422, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.fly', 'vnd.fly', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(423, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.fmi.flexstor', 'vnd.fmi.flexstor', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(424, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.graphviz', 'vnd.graphviz', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(425, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.in3d.3dml', 'vnd.in3d.3dml', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(426, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.in3d.spot', 'vnd.in3d.spot', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(427, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.latex-z', 'vnd.latex-z', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(428, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.motorola.reflex', 'vnd.motorola.reflex', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(429, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.ms-mediapackage', 'vnd.ms-mediapackage', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(430, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.net2phone.commcenter.command', 'vnd.net2phone.commcenter.command', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(431, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.si.uricatalogue', 'vnd.si.uricatalogue', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(432, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.sun.j2me.app-descriptor', 'vnd.sun.j2me.app-descriptor', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(433, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.trolltech.linguist', 'vnd.trolltech.linguist', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(434, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.wap-wml', 'vnd.wap-wml', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(435, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.wap.si', 'vnd.wap.si', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(436, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 420, 'vnd.wap.wmlscript', 'vnd.wap.wmlscript', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instance_options` VALUES(437, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(438, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'jpm', 'jpm', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(439, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'mj2', 'mj2', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(440, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'quicktime', 'quicktime', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(441, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(442, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd-mpegurl', 'vnd-mpegurl', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(443, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd-vivo', 'vnd-vivo', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(444, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.CCTV', 'vnd.CCTV', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(445, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.dece-mp4', 'vnd.dece-mp4', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(446, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.dece.hd', 'vnd.dece.hd', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(447, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.dece.mobile', 'vnd.dece.mobile', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(448, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.dece.pd', 'vnd.dece.pd', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(449, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.dece.sd', 'vnd.dece.sd', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(450, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.dece.video', 'vnd.dece.video', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(451, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.directv-mpeg', 'vnd.directv-mpeg', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(452, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.directv.mpeg-tts', 'vnd.directv.mpeg-tts', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(453, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.dvb.file', 'vnd.dvb.file', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(454, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.fvt', 'vnd.fvt', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(455, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.hns.video', 'vnd.hns.video', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(456, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.iptvforum.1dparityfec-1010', 'vnd.iptvforum.1dparityfec-1010', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(457, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.iptvforum.1dparityfec-2005', 'vnd.iptvforum.1dparityfec-2005', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(458, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.iptvforum.2dparityfec-1010', 'vnd.iptvforum.2dparityfec-1010', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(459, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.iptvforum.2dparityfec-2005', 'vnd.iptvforum.2dparityfec-2005', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(460, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.iptvforum.ttsavc', 'vnd.iptvforum.ttsavc', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(461, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.iptvforum.ttsmpeg2', 'vnd.iptvforum.ttsmpeg2', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(462, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.motorola.video', 'vnd.motorola.video', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(463, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.motorola.videop', 'vnd.motorola.videop', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(464, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.mpegurl', 'vnd.mpegurl', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(465, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.ms-playready.media.pyv', 'vnd.ms-playready.media.pyv', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(466, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.nokia.interleaved-multimedia', 'vnd.nokia.interleaved-multimedia', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(467, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.nokia.videovoip', 'vnd.nokia.videovoip', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instance_options` VALUES(468, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.objectvideo', 'vnd.objectvideo', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instance_options` VALUES(469, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.sealed-swf', 'vnd.sealed-swf', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instance_options` VALUES(470, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.sealed.mpeg1', 'vnd.sealed.mpeg1', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instance_options` VALUES(471, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.sealed.mpeg4', 'vnd.sealed.mpeg4', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 34);
INSERT INTO `molajo_extension_instance_options` VALUES(472, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.sealed.swf', 'vnd.sealed.swf', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 35);
INSERT INTO `molajo_extension_instance_options` VALUES(473, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.sealedmedia.softseal-mov', 'vnd.sealedmedia.softseal-mov', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 36);
INSERT INTO `molajo_extension_instance_options` VALUES(474, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 430, 'vnd.uvvu.mp4', 'vnd.uvvu.mp4', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 37);
INSERT INTO `molajo_extension_instance_options` VALUES(475, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(476, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'add', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(477, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'edit', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(478, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(479, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'apply', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(480, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'cancel', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(481, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'create', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(482, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'save', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(483, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'save2copy', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(484, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'save2new', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(485, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'restore', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(486, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'archive', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(487, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'publish', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(488, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'unpublish', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(489, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'spam', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(490, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'trash', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(491, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'feature', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(492, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'unfeature', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(493, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'sticky', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(494, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'unsticky', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(495, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'checkin', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(496, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'reorder', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(497, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'orderup', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(498, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'orderdown', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(499, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'saveorder', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(500, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'delete', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(501, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'copy', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(502, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'move', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(503, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'login', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(504, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'logout', 'logout', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(505, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(506, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'add', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(507, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'edit', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(508, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(509, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'apply', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(510, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'cancel', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(511, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'create', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(512, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'save', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(513, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'save2copy', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(514, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'save2new', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(515, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'restore', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(516, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'archive', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(517, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'publish', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(518, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'unpublish', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(519, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'spam', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(520, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'trash', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(521, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'feature', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(522, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'unfeature', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(523, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'sticky', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(524, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'unsticky', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(525, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'checkin', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(526, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'reorder', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(527, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'orderup', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(528, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'orderdown', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(529, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'saveorder', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(530, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'delete', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(531, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'copy', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(532, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'move', 'multiple', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(533, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'login', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(534, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1101, 'logout', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(535, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1800, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(536, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1800, '2552', '2552', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(537, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1801, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(538, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1801, '2559', '2559', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(539, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(540, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2000, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(541, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2000, 'edit', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(542, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(543, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2100, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(544, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2001, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(545, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2001, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(546, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2001, 'edit', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(547, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2101, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(548, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2101, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(549, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(550, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3000, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(551, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3000, 'item', 'item', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(552, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3000, 'items', 'items', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(553, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3000, 'table', 'table', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(554, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(555, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3100, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(556, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3200, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(557, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3200, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(558, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3300, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(559, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3300, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(560, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3001, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(561, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3001, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(562, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3101, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(563, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3101, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(564, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3201, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(565, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3201, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(566, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3301, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(567, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3301, 'default', 'default', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(568, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(569, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4000, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(570, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(571, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4100, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(572, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(573, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'error', 'error', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(574, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'feed', 'feed', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(575, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(576, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'json', 'json', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(577, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'opensearch', 'opensearch', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(578, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'raw', 'raw', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(579, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'xls', 'xls', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(580, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'xml', 'xml', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(581, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4200, 'xmlrpc', 'xmlrpc', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(582, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4300, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(583, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4300, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(584, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4001, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(585, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4001, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(586, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4101, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(587, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4101, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(588, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(589, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'error', 'error', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(590, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'feed', 'feed', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(591, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(592, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'json', 'json', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(593, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'opensearch', 'opensearch', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(594, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'raw', 'raw', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(595, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'xls', 'xls', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(596, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'xml', 'xml', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(597, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4201, 'xmlrpc', 'xmlrpc', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(598, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4301, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(599, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4301, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(600, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(601, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5000, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(602, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5000, 'edit', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(603, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5001, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(604, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5001, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(605, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5001, 'edit', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(606, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 6000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(607, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 6000, 'content', 'content', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(608, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(609, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10000, '1', 'Core ACL Implementation', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(610, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(611, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, 'view', 'view', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(612, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, 'create', 'create', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(613, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, 'edit', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(614, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, 'publish', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(615, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, 'delete', 'delete', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(616, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, 'admin', 'admin', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(617, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(618, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'add', 'create', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(619, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'admin', 'admin', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instance_options` VALUES(620, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'apply', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(621, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'archive', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instance_options` VALUES(622, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'cancel', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instance_options` VALUES(623, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'checkin', 'admin', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instance_options` VALUES(624, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'close', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instance_options` VALUES(625, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'copy', 'create', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instance_options` VALUES(626, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'create', 'create', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instance_options` VALUES(627, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'delete', 'delete', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instance_options` VALUES(628, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'view', 'view', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instance_options` VALUES(629, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'edit', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instance_options` VALUES(630, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'editstate', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instance_options` VALUES(631, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'feature', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instance_options` VALUES(632, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'login', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(633, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'logout', 'logout', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(634, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'manage', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instance_options` VALUES(635, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'move', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instance_options` VALUES(636, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'orderdown', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instance_options` VALUES(637, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'orderup', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instance_options` VALUES(638, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'publish', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instance_options` VALUES(639, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'reorder', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instance_options` VALUES(640, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'restore', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instance_options` VALUES(641, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'save', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instance_options` VALUES(642, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'save2copy', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instance_options` VALUES(643, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'save2new', 'edit', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instance_options` VALUES(644, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'saveorder', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instance_options` VALUES(645, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'search', 'view', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(646, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'spam', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(647, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'state', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instance_options` VALUES(648, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'sticky', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instance_options` VALUES(649, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'trash', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instance_options` VALUES(650, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'unfeature', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instance_options` VALUES(651, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'unpublish', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 34);
INSERT INTO `molajo_extension_instance_options` VALUES(652, 1, 1, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'unsticky', 'publish', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 35);
INSERT INTO `molajo_extension_instance_options` VALUES(653, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(654, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 100, '__dummy', '__dummy', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(655, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(656, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instance_options` VALUES(657, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'login', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instance_options` VALUES(658, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 1100, 'logout', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instance_options` VALUES(659, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(660, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2000, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(661, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(662, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 2100, 'display', 'display', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(663, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(664, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3000, 'login', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(665, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(666, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 3100, 'login', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(667, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(668, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4000, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(669, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 4001, 'html', 'html', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(670, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(671, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 5000, 'dummy', 'dummy', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(672, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 6000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(673, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 6000, 'user', 'user', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(674, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10000, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(675, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10000, '1', 'Core ACL Implementation', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(676, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(677, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10100, 'view', 'view', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instance_options` VALUES(678, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(679, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'login', 'login', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instance_options` VALUES(680, 13, 13, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 10200, 'logout', 'logout', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instance_options` VALUES(681, 2, 2, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 100, '', '', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instance_options` VALUES(682, 2, 2, 0, ' ', ' ', ' ', NULL, 0, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '', 100, '__content', '__content', 0, ' ', 0, 0, 0, 0, 0, NULL, NULL, 'en-GB', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extension_types`
--

CREATE TABLE `molajo_extension_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `extension_type` varchar(255) NOT NULL DEFAULT ' ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_actions_table_title_index` (`extension_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=100 ;

--
-- Dumping data for table `molajo_extension_types`
--

INSERT INTO `molajo_extension_types` VALUES(1, 'components');
INSERT INTO `molajo_extension_types` VALUES(0, 'core');
INSERT INTO `molajo_extension_types` VALUES(2, 'languages');
INSERT INTO `molajo_extension_types` VALUES(3, 'layouts');
INSERT INTO `molajo_extension_types` VALUES(10, 'libraries');
INSERT INTO `molajo_extension_types` VALUES(4, 'manifests');
INSERT INTO `molajo_extension_types` VALUES(5, 'menus');
INSERT INTO `molajo_extension_types` VALUES(6, 'modules');
INSERT INTO `molajo_extension_types` VALUES(7, 'parameters');
INSERT INTO `molajo_extension_types` VALUES(8, 'plugins');
INSERT INTO `molajo_extension_types` VALUES(9, 'templates');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_groups`
--

CREATE TABLE `molajo_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Group Primary Key',
  `title` varchar(255) NOT NULL DEFAULT '  ',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ',
  `description` mediumtext NOT NULL,
  `type` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `protected` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'If true, protects group from system removal via the interface.',
  `custom_fields` mediumtext,
  `parameters` mediumtext,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Parent ID',
  `lft` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `molajo_groups`
--

INSERT INTO `molajo_groups` VALUES(1, 'Public', '', 'All visitors regardless of authentication status', 0, 1, NULL, NULL, 0, 0, 1, 1);
INSERT INTO `molajo_groups` VALUES(2, 'Guest', '', 'Visitors not authenticated', 0, 1, NULL, NULL, 0, 2, 3, 2);
INSERT INTO `molajo_groups` VALUES(3, 'Registered', '', 'Authentication visitors', 0, 1, NULL, NULL, 0, 4, 5, 3);
INSERT INTO `molajo_groups` VALUES(4, 'Administrator', '', 'System Administrator', 0, 1, NULL, NULL, 0, 6, 7, 4);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_group_permissions`
--

CREATE TABLE `molajo_group_permissions` (
  `group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #_groups.id',
  `asset_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__assets.id',
  `action_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__actions.id',
  PRIMARY KEY (`action_id`,`asset_id`,`group_id`),
  KEY `fk_group_permissions_groups2` (`group_id`),
  KEY `fk_group_permissions_assets2` (`asset_id`),
  KEY `fk_group_permissions_actions2` (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_group_permissions`
--

INSERT INTO `molajo_group_permissions` VALUES(1, 1, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 2, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 4, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 5, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 6, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 7, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 11, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 12, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 13, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 14, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 15, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 16, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 17, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 18, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 19, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 20, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 21, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 22, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 23, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 24, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 25, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 26, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 27, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 28, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 29, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 30, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 31, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 46, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 47, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 49, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 50, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 51, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 52, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 53, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 54, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 55, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 56, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 57, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 58, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 59, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 60, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 61, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 62, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 63, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 64, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 65, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 66, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 67, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 68, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 69, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 70, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 71, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 72, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 73, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 74, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 75, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 76, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 77, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 78, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 79, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 80, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 81, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 82, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 83, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 84, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 85, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 86, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 87, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 88, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 89, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 90, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 91, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 92, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 93, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 94, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 95, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 96, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 97, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 98, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 99, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 100, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 101, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 102, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 103, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 104, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 105, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 106, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 107, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 108, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 112, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 113, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 114, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 115, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 116, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 119, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 120, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 121, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 122, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 123, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 124, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 125, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 126, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 127, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 128, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 129, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 130, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 131, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 132, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 133, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 134, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 135, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 136, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 137, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 138, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 139, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 140, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 141, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 142, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 143, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 144, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 145, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 146, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 147, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 148, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 149, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 150, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 151, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 182, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 183, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 184, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 185, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 186, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 187, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 188, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 189, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 190, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 191, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 192, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 193, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 194, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 195, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 196, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 197, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 198, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 199, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 200, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 201, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 202, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 203, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 204, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 205, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 206, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 207, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 208, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 209, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 210, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 211, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 212, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 213, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 214, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 215, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 216, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 217, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 218, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 219, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 220, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 221, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 222, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 223, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 245, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 246, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 247, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 248, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 252, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 253, 3);
INSERT INTO `molajo_group_permissions` VALUES(1, 286, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 255, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 256, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 257, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 258, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 259, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 260, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 261, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 262, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 263, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 264, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 265, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 266, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 267, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 268, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 269, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 270, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 271, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 272, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 273, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 274, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 275, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 276, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 277, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 278, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 279, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 280, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 281, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 282, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 283, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 284, 3);
INSERT INTO `molajo_group_permissions` VALUES(2, 285, 3);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_group_view_groups`
--

CREATE TABLE `molajo_group_view_groups` (
  `group_id` int(11) unsigned NOT NULL COMMENT 'FK to the #__group table.',
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'FK to the #__groupings table.',
  PRIMARY KEY (`view_group_id`,`group_id`),
  KEY `fk_group_view_groups_groups2` (`group_id`),
  KEY `fk_group_view_groups_view_groups2` (`view_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_group_view_groups`
--

INSERT INTO `molajo_group_view_groups` VALUES(1, 1);
INSERT INTO `molajo_group_view_groups` VALUES(2, 2);
INSERT INTO `molajo_group_view_groups` VALUES(3, 3);
INSERT INTO `molajo_group_view_groups` VALUES(3, 5);
INSERT INTO `molajo_group_view_groups` VALUES(4, 4);
INSERT INTO `molajo_group_view_groups` VALUES(4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_sessions`
--

CREATE TABLE `molajo_sessions` (
  `session_id` varchar(32) NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  `session_time` varchar(14) DEFAULT ' ',
  `data` longtext,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`),
  KEY `fk_sessions_applications2` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_sites`
--

CREATE TABLE `molajo_sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Application Primary Key',
  `name` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `path` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL Alias',
  `base_url` varchar(2048) NOT NULL DEFAULT ' ',
  `description` mediumtext,
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `custom_fields` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `molajo_sites`
--

INSERT INTO `molajo_sites` VALUES(1, 'Molajo', '1', '', 'Primary Site', '{}', '{}');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_site_applications`
--

CREATE TABLE `molajo_site_applications` (
  `site_id` int(11) unsigned NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`site_id`,`application_id`),
  KEY `fk_site_applications_sites2` (`site_id`),
  KEY `fk_site_applications_applications2` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_site_applications`
--

INSERT INTO `molajo_site_applications` VALUES(1, 1);
INSERT INTO `molajo_site_applications` VALUES(1, 2);
INSERT INTO `molajo_site_applications` VALUES(1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_site_extension_instances`
--

CREATE TABLE `molajo_site_extension_instances` (
  `site_id` int(11) unsigned NOT NULL,
  `extension_instance_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`site_id`,`extension_instance_id`),
  KEY `fk_site_extension_instances_sites2` (`site_id`),
  KEY `fk_site_extension_instances_extension_instances2` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_site_extension_instances`
--

INSERT INTO `molajo_site_extension_instances` VALUES(1, 1);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 2);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 3);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 4);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 5);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 6);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 7);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 8);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 9);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 10);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 11);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 12);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 13);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 14);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 15);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 16);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 17);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 18);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 33);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 34);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 36);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 37);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 38);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 39);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 40);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 41);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 42);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 43);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 44);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 45);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 46);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 47);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 48);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 49);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 50);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 51);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 52);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 53);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 54);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 55);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 56);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 57);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 58);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 59);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 60);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 61);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 62);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 63);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 64);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 65);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 66);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 67);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 68);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 69);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 70);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 71);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 72);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 73);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 74);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 75);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 76);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 77);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 78);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 79);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 80);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 81);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 82);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 83);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 84);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 85);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 86);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 87);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 88);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 89);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 90);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 91);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 92);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 93);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 94);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 95);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 99);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 100);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 101);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 102);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 103);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 106);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 107);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 108);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 109);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 110);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 111);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 112);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 113);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 114);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 115);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 116);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 117);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 118);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 119);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 120);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 121);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 122);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 123);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 124);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 125);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 126);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 127);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 128);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 129);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 130);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 131);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 132);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 133);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 134);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 135);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 136);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 137);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 138);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 169);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 170);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 171);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 172);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 173);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 174);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 175);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 176);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 177);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 178);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 179);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 180);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 181);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 182);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 183);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 184);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 185);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 186);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 187);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 188);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 189);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 190);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 191);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 192);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 193);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 194);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 195);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 196);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 197);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 198);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 199);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 200);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 201);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 202);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 203);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 204);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 205);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 206);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 207);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 208);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 209);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 210);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 232);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 233);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 234);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 235);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 239);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 240);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_source_tables`
--

CREATE TABLE `molajo_source_tables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `source_table` varchar(255) NOT NULL DEFAULT ' ',
  `option` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `molajo_source_tables`
--

INSERT INTO `molajo_source_tables` VALUES(1, '__applications', 'com_applications');
INSERT INTO `molajo_source_tables` VALUES(2, '__categories', 'com_categories');
INSERT INTO `molajo_source_tables` VALUES(3, '__content', 'com_articles');
INSERT INTO `molajo_source_tables` VALUES(4, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_source_tables` VALUES(5, '__users', 'com_users');
INSERT INTO `molajo_source_tables` VALUES(6, '__groups', 'com_groups');
INSERT INTO `molajo_source_tables` VALUES(7, '__content', 'com_contacts');
INSERT INTO `molajo_source_tables` VALUES(8, '__content', 'com_comments');
INSERT INTO `molajo_source_tables` VALUES(9, '__content', 'com_media');
INSERT INTO `molajo_source_tables` VALUES(10, '__extension_instance_options', 'com_extensions');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_update_sites`
--

CREATE TABLE `molajo_update_sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT ' ',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `location` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `molajo_update_sites`
--

INSERT INTO `molajo_update_sites` VALUES(1, 'Molajo Core', 1, 'http://update.molajo.org/core/list.xml');
INSERT INTO `molajo_update_sites` VALUES(2, 'Molajo Directory', 1, 'http://update.molajo.org/directory/list.xml');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_users`
--

CREATE TABLE `molajo_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `content_text` mediumtext,
  `email` varchar(255) DEFAULT '  ',
  `password` varchar(100) NOT NULL DEFAULT '  ',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `send_email` tinyint(4) NOT NULL DEFAULT '0',
  `register_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_visit_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `custom_fields` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `molajo_users`
--

INSERT INTO `molajo_users` VALUES(42, 'admin', 'Administrator', '', '', 'admin@example.com', 'admin', 0, '1', 0, '2011-11-11 11:11:11', '0000-00-00 00:00:00', NULL, '');
INSERT INTO `molajo_users` VALUES(100, 'mark', 'Mark', 'Robinson', '<p>Great guy who sells insurance and coaches Little League.</p>', 'mark.robinson@example.com', 'mark', 0, '1', 0, '2011-11-02 17:45:17', '0000-00-00 00:00:00', NULL, '{"favorite_color":"red","nickname":"Fred","claim_to_fame":"No search results for Mark on Google."}');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_applications`
--

CREATE TABLE `molajo_user_applications` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__users.id',
  `application_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__applications.id',
  PRIMARY KEY (`application_id`,`user_id`),
  KEY `fk_user_applications_users` (`user_id`),
  KEY `fk_user_applications_applications` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_applications`
--

INSERT INTO `molajo_user_applications` VALUES(42, 1);
INSERT INTO `molajo_user_applications` VALUES(42, 2);
INSERT INTO `molajo_user_applications` VALUES(42, 3);
INSERT INTO `molajo_user_applications` VALUES(100, 1);
INSERT INTO `molajo_user_applications` VALUES(100, 3);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_groups`
--

CREATE TABLE `molajo_user_groups` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__users.id',
  `group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__groups.id',
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `fk_molajo_user_groups_molajo_users2` (`user_id`),
  KEY `fk_molajo_user_groups_molajo_groups2` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_groups`
--

INSERT INTO `molajo_user_groups` VALUES(42, 3);
INSERT INTO `molajo_user_groups` VALUES(42, 4);
INSERT INTO `molajo_user_groups` VALUES(100, 3);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_view_groups`
--

CREATE TABLE `molajo_user_view_groups` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__users.id',
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__groupings.id',
  PRIMARY KEY (`user_id`,`view_group_id`),
  KEY `fk_user_view_groups_users2` (`user_id`),
  KEY `fk_user_view_groups_view_groups2` (`view_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_view_groups`
--

INSERT INTO `molajo_user_view_groups` VALUES(42, 3);
INSERT INTO `molajo_user_view_groups` VALUES(42, 4);
INSERT INTO `molajo_user_view_groups` VALUES(100, 3);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_view_groups`
--

CREATE TABLE `molajo_view_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `view_group_name_list` text NOT NULL,
  `view_group_id_list` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `molajo_view_groups`
--

INSERT INTO `molajo_view_groups` VALUES(1, 'Public', '1');
INSERT INTO `molajo_view_groups` VALUES(2, 'Guest', '2');
INSERT INTO `molajo_view_groups` VALUES(3, 'Registered', '3');
INSERT INTO `molajo_view_groups` VALUES(4, 'Administrator', '4');
INSERT INTO `molajo_view_groups` VALUES(5, 'Registered, Administrator', '4,5');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_view_group_permissions`
--

CREATE TABLE `molajo_view_group_permissions` (
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__groups.id',
  `asset_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__assets.id',
  `action_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #__actions.id',
  PRIMARY KEY (`view_group_id`,`asset_id`,`action_id`),
  KEY `fk_view_group_permissions_view_groups2` (`view_group_id`),
  KEY `fk_view_group_permissions_actions2` (`action_id`),
  KEY `fk_view_group_permissions_assets2` (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_view_group_permissions`
--

INSERT INTO `molajo_view_group_permissions` VALUES(1, 1, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 2, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 4, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 5, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 6, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 7, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 11, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 12, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 13, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 14, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 15, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 16, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 17, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 18, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 19, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 20, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 21, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 22, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 23, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 24, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 25, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 26, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 27, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 28, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 29, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 30, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 31, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 46, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 47, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 49, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 50, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 51, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 52, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 53, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 54, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 55, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 56, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 57, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 58, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 59, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 60, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 61, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 62, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 63, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 64, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 65, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 66, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 67, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 68, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 69, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 70, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 71, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 72, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 73, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 74, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 75, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 76, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 77, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 78, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 79, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 80, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 81, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 82, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 83, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 84, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 85, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 86, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 87, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 88, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 89, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 90, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 91, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 92, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 93, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 94, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 95, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 96, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 97, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 98, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 99, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 100, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 101, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 102, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 103, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 104, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 105, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 106, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 107, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 108, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 112, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 113, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 114, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 115, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 116, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 119, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 120, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 121, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 122, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 123, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 124, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 125, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 126, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 127, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 128, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 129, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 130, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 131, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 132, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 133, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 134, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 135, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 136, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 137, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 138, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 139, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 140, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 141, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 142, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 143, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 144, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 145, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 146, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 147, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 148, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 149, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 150, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 151, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 182, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 183, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 184, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 185, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 186, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 187, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 188, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 189, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 190, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 191, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 192, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 193, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 194, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 195, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 196, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 197, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 198, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 199, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 200, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 201, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 202, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 203, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 204, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 205, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 206, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 207, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 208, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 209, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 210, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 211, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 212, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 213, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 214, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 215, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 216, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 217, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 218, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 219, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 220, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 221, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 222, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 223, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 245, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 246, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 247, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 248, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 252, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 253, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(1, 286, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 255, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 256, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 257, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 258, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 259, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 260, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 261, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 262, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 263, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 264, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 265, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 266, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 267, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 268, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 269, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 270, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 271, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 272, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 273, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 274, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 275, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 276, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 277, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 278, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 279, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 280, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 281, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 282, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 283, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 284, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 285, 3);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `molajo_application_extension_instances`
--
ALTER TABLE `molajo_application_extension_instances`
  ADD CONSTRAINT `fk_application_extensions_applications1` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_application_extensions_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_assets`
--
ALTER TABLE `molajo_assets`
  ADD CONSTRAINT `fk_assets_source_tables1` FOREIGN KEY (`source_table_id`) REFERENCES `molajo_source_tables` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_asset_categories`
--
ALTER TABLE `molajo_asset_categories`
  ADD CONSTRAINT `fk_content_categories_categories1` FOREIGN KEY (`category_id`) REFERENCES `molajo_categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asset_categories_assets1` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_content`
--
ALTER TABLE `molajo_content`
  ADD CONSTRAINT `fk_content_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extensions`
--
ALTER TABLE `molajo_extensions`
  ADD CONSTRAINT `fk_extensions_extension_types1` FOREIGN KEY (`extension_type_id`) REFERENCES `molajo_extension_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_extensions_update_sites1` FOREIGN KEY (`update_site_id`) REFERENCES `molajo_update_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extension_instances`
--
ALTER TABLE `molajo_extension_instances`
  ADD CONSTRAINT `fk_extension_instances_extensions1` FOREIGN KEY (`extension_id`) REFERENCES `molajo_extensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_extension_instances_extension_types1` FOREIGN KEY (`extension_type_id`) REFERENCES `molajo_extension_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extension_instance_options`
--
ALTER TABLE `molajo_extension_instance_options`
  ADD CONSTRAINT `fk_extension_instance_options_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_extension_instance_options_extensions1` FOREIGN KEY (`extension_id`) REFERENCES `molajo_extensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_extension_instance_options_extension_types1` FOREIGN KEY (`extension_type_id`) REFERENCES `molajo_extension_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_group_permissions`
--
ALTER TABLE `molajo_group_permissions`
  ADD CONSTRAINT `fk_group_permissions_groups1` FOREIGN KEY (`group_id`) REFERENCES `molajo_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_permissions_assets1` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_permissions_actions1` FOREIGN KEY (`action_id`) REFERENCES `molajo_actions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_group_view_groups`
--
ALTER TABLE `molajo_group_view_groups`
  ADD CONSTRAINT `fk_group_view_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `molajo_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_view_groups_view_groups1` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_sessions`
--
ALTER TABLE `molajo_sessions`
  ADD CONSTRAINT `fk_sessions_applications1` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_site_applications`
--
ALTER TABLE `molajo_site_applications`
  ADD CONSTRAINT `fk_site_applications_sites` FOREIGN KEY (`site_id`) REFERENCES `molajo_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_site_applications_applications` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_site_extension_instances`
--
ALTER TABLE `molajo_site_extension_instances`
  ADD CONSTRAINT `fk_site_extension_instances_sites1` FOREIGN KEY (`site_id`) REFERENCES `molajo_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_site_extension_instances_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_applications`
--
ALTER TABLE `molajo_user_applications`
  ADD CONSTRAINT `fk_user_applications_users1` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_applications_applications1` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_groups`
--
ALTER TABLE `molajo_user_groups`
  ADD CONSTRAINT `fk_user_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `molajo_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_view_groups`
--
ALTER TABLE `molajo_user_view_groups`
  ADD CONSTRAINT `fk_user_view_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_view_groups_view_groups1` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_view_group_permissions`
--
ALTER TABLE `molajo_view_group_permissions`
  ADD CONSTRAINT `fk_view_group_permissions_view_groups1` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_view_group_permissions_actions1` FOREIGN KEY (`action_id`) REFERENCES `molajo_actions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_view_group_permissions_assets1` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
