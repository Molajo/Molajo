-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 20, 2011 at 10:00 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `molajo`
--

-- --------------------------------------------------------

--
-- Table structure for table `molajo_actions`
--

CREATE TABLE `molajo_actions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `title` varchar(255) NOT NULL DEFAULT ' ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_actions_table_title` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `molajo_actions`
--

INSERT INTO `molajo_actions` VALUES(7, 'admin');
INSERT INTO `molajo_actions` VALUES(2, 'create');
INSERT INTO `molajo_actions` VALUES(6, 'delete');
INSERT INTO `molajo_actions` VALUES(4, 'edit');
INSERT INTO `molajo_actions` VALUES(1, 'login');
INSERT INTO `molajo_actions` VALUES(5, 'publish');
INSERT INTO `molajo_actions` VALUES(3, 'view');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_applications`
--

CREATE TABLE `molajo_applications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Application Primary Key',
  `name` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `path` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL Alias',
  `description` mediumtext,
  `home` int(11) unsigned NOT NULL DEFAULT '0',
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `custom_fields` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `molajo_applications`
--

INSERT INTO `molajo_applications` VALUES(1, 'site', '', 'Primary application for site visitors', 31, '{}', '{}');
INSERT INTO `molajo_applications` VALUES(2, 'administrator', 'administrator', 'Administrative site area for site construction', 2, '{}', '{}');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_application_extension_instances`
--

CREATE TABLE `molajo_application_extension_instances` (
  `application_id` int(11) unsigned NOT NULL,
  `extension_instance_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`application_id`,`extension_instance_id`),
  KEY `fk_application_extensions_applications2` (`application_id`),
  KEY `fk_application_extension_instances_extension_instances2` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_application_extension_instances`
--

INSERT INTO `molajo_application_extension_instances` VALUES(1, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 5);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 7);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 12);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 13);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 15);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 16);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 18);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 36);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 37);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 38);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 39);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 40);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 41);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 42);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 43);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 44);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 45);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 46);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 47);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 48);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 49);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 50);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 51);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 52);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 53);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 54);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 55);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 56);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 57);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 58);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 59);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 60);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 61);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 62);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 63);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 64);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 65);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 66);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 67);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 68);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 69);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 70);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 71);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 72);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 73);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 74);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 75);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 76);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 77);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 78);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 79);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 80);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 81);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 82);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 83);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 84);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 85);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 86);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 87);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 88);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 89);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 90);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 91);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 92);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 93);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 94);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 95);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 106);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 107);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 108);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 109);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 110);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 111);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 112);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 113);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 114);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 115);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 116);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 117);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 118);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 119);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 120);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 121);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 122);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 123);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 124);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 125);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 126);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 127);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 128);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 129);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 130);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 131);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 132);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 133);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 134);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 135);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 136);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 137);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 138);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 139);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 140);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 141);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 142);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 143);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 144);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 145);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 146);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 147);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 169);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 172);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 173);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 176);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 177);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 181);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 184);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 185);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 187);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 190);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 194);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 196);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 198);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 200);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 203);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 205);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 3);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 4);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 5);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 6);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 7);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 8);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 9);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 10);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 11);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 12);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 13);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 14);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 15);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 16);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 17);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 18);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 19);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 36);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 37);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 38);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 39);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 40);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 41);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 42);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 43);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 44);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 45);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 46);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 47);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 48);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 49);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 50);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 51);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 52);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 53);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 54);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 55);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 56);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 57);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 58);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 59);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 60);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 61);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 62);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 63);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 64);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 65);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 66);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 67);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 68);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 69);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 70);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 71);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 72);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 73);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 74);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 75);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 76);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 77);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 78);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 79);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 80);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 81);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 82);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 83);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 84);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 85);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 86);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 87);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 88);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 89);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 90);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 91);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 92);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 93);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 94);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 95);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 106);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 107);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 108);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 109);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 110);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 111);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 112);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 113);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 114);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 115);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 116);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 117);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 118);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 119);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 120);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 121);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 122);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 123);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 124);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 125);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 126);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 127);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 128);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 129);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 130);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 131);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 132);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 133);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 134);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 135);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 136);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 137);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 138);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 139);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 140);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 141);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 142);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 143);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 144);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 145);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 146);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 147);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 171);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 172);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 173);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 182);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 184);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 185);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 187);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 190);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 194);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 196);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 197);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 198);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 199);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 200);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 203);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 208);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_assets`
--

CREATE TABLE `molajo_assets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Assets Primary Key',
  `content_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `source_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Content Primary Key',
  `title` varchar(255) NOT NULL DEFAULT ' ',
  `sef_request` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL',
  `request` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'The actually link the menu item refers to.',
  `primary_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  `template_id` int(11) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `redirect_to_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_group_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__groupings table',
  PRIMARY KEY (`id`),
  KEY `sef_request` (`sef_request`(255)),
  KEY `request` (`request`(255)),
  KEY `fk_assets_content_type_ids2` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=281 ;

--
-- Dumping data for table `molajo_assets`
--

INSERT INTO `molajo_assets` VALUES(1, 15, 1, 'site', '', '', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(2, 15, 2, 'administrator', 'administrator', '', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(4, 1050, 2, 'com_articles', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(5, 1050, 3, 'com_assets', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(6, 1050, 4, 'com_categories', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(7, 1050, 5, 'com_comments', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(8, 1050, 6, 'com_configuration', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(9, 1050, 7, 'com_contacts', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(10, 1050, 8, 'com_dashboard', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(11, 1050, 9, 'com_extensions', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(12, 1050, 10, 'com_groups', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(13, 1050, 11, 'com_installer', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(14, 1050, 12, 'com_layouts', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(15, 1050, 13, 'com_login', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(16, 1050, 14, 'com_maintain', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(17, 1050, 15, 'com_menus', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(18, 1050, 16, 'com_media', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(19, 1050, 17, 'com_profile', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(20, 1050, 18, 'com_search', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(21, 1050, 19, 'com_users', 'extensions/components/1', 'index.php?option=com_extensions&view=component&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(35, 40, 33, 'English (UK)', 'extensions/languages/33', 'index.php?option=com_extensions&view=languages&id=33', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(36, 40, 34, 'English (US)', 'extensions/languages/34', 'index.php?option=com_extensions&view=languages&id=34', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(38, 1150, 36, 'head', 'extensions/layouts/36', 'index.php?option=com_extensions&view=layouts&id=36', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(39, 1150, 37, 'messages', 'extensions/layouts/37', 'index.php?option=com_extensions&view=layouts&id=37', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(40, 1150, 38, 'errors', 'extensions/layouts/38', 'index.php?option=com_extensions&view=layouts&id=38', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(41, 1150, 39, 'atom', 'extensions/layouts/39', 'index.php?option=com_extensions&view=layouts&id=39', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(42, 1150, 40, 'rss', 'extensions/layouts/40', 'index.php?option=com_extensions&view=layouts&id=40', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(43, 1150, 41, 'admin_acl_panel', 'extensions/layouts/41', 'index.php?option=com_extensions&view=layouts&id=41', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(44, 1150, 42, 'admin_activity', 'extensions/layouts/42', 'index.php?option=com_extensions&view=layouts&id=42', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(45, 1150, 43, 'admin_dashboard', 'extensions/layouts/43', 'index.php?option=com_extensions&view=layouts&id=43', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(46, 1150, 44, 'admin_edit', 'extensions/layouts/44', 'index.php?option=com_extensions&view=layouts&id=44', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(47, 1150, 45, 'admin_favorites', 'extensions/layouts/45', 'index.php?option=com_extensions&view=layouts&id=45', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(48, 1150, 46, 'admin_feed', 'extensions/layouts/46', 'index.php?option=com_extensions&view=layouts&id=46', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(49, 1150, 47, 'admin_footer', 'extensions/layouts/47', 'index.php?option=com_extensions&view=layouts&id=47', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(50, 1150, 48, 'admin_header', 'extensions/layouts/48', 'index.php?option=com_extensions&view=layouts&id=48', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(51, 1150, 49, 'admin_inbox', 'extensions/layouts/49', 'index.php?option=com_extensions&view=layouts&id=49', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(52, 1150, 50, 'admin_launchpad', 'extensions/layouts/50', 'index.php?option=com_extensions&view=layouts&id=50', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(53, 1150, 51, 'admin_list', 'extensions/layouts/51', 'index.php?option=com_extensions&view=layouts&id=51', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(54, 1150, 52, 'admin_login', 'extensions/layouts/52', 'index.php?option=com_extensions&view=layouts&id=52', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(55, 1150, 53, 'admin_modal', 'extensions/layouts/53', 'index.php?option=com_extensions&view=layouts&id=53', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(56, 1150, 54, 'admin_pagination', 'extensions/layouts/54', 'index.php?option=com_extensions&view=layouts&id=54', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(57, 1150, 55, 'admin_toolbar', 'extensions/layouts/55', 'index.php?option=com_extensions&view=layouts&id=55', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(58, 1150, 56, 'audio', 'extensions/layouts/56', 'index.php?option=com_extensions&view=layouts&id=56', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(59, 1150, 57, 'contact_form', 'extensions/layouts/57', 'index.php?option=com_extensions&view=layouts&id=57', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(60, 1150, 58, 'default', 'extensions/layouts/58', 'index.php?option=com_extensions&view=layouts&id=58', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(61, 1150, 59, 'dummy', 'extensions/layouts/59', 'index.php?option=com_extensions&view=layouts&id=59', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(62, 1150, 60, 'faq', 'extensions/layouts/60', 'index.php?option=com_extensions&view=layouts&id=60', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(63, 1150, 61, 'item', 'extensions/layouts/61', 'index.php?option=com_extensions&view=layouts&id=61', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(64, 1150, 62, 'list', 'extensions/layouts/62', 'index.php?option=com_extensions&view=layouts&id=62', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(65, 1150, 63, 'items', 'extensions/layouts/63', 'index.php?option=com_extensions&view=layouts&id=63', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(66, 1150, 64, 'list', 'extensions/layouts/64', 'index.php?option=com_extensions&view=layouts&id=64', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(67, 1150, 65, 'pagination', 'extensions/layouts/65', 'index.php?option=com_extensions&view=layouts&id=65', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(68, 1150, 66, 'social_bookmarks', 'extensions/layouts/66', 'index.php?option=com_extensions&view=layouts&id=66', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(69, 1150, 67, 'syntaxhighlighter', 'extensions/layouts/67', 'index.php?option=com_extensions&view=layouts&id=67', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(70, 1150, 68, 'table', 'extensions/layouts/68', 'index.php?option=com_extensions&view=layouts&id=68', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(71, 1150, 69, 'tree', 'extensions/layouts/69', 'index.php?option=com_extensions&view=layouts&id=69', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(72, 1150, 70, 'twig_example', 'extensions/layouts/70', 'index.php?option=com_extensions&view=layouts&id=70', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(73, 1150, 71, 'video', 'extensions/layouts/71', 'index.php?option=com_extensions&view=layouts&id=71', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(74, 1150, 72, 'button', 'extensions/layouts/72', 'index.php?option=com_extensions&view=layouts&id=72', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(75, 1150, 73, 'colorpicker', 'extensions/layouts/73', 'index.php?option=com_extensions&view=layouts&id=73', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(76, 1150, 74, 'datepicker', 'extensions/layouts/74', 'index.php?option=com_extensions&view=layouts&id=74', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(77, 1150, 75, 'list', 'extensions/layouts/75', 'index.php?option=com_extensions&view=layouts&id=75', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(78, 1150, 76, 'media', 'extensions/layouts/76', 'index.php?option=com_extensions&view=layouts&id=76', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(79, 1150, 77, 'number', 'extensions/layouts/77', 'index.php?option=com_extensions&view=layouts&id=77', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(80, 1150, 78, 'option', 'extensions/layouts/78', 'index.php?option=com_extensions&view=layouts&id=78', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(81, 1150, 79, 'rules', 'extensions/layouts/79', 'index.php?option=com_extensions&view=layouts&id=79', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(82, 1150, 80, 'spacer', 'extensions/layouts/80', 'index.php?option=com_extensions&view=layouts&id=80', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(83, 1150, 81, 'text', 'extensions/layouts/81', 'index.php?option=com_extensions&view=layouts&id=81', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(84, 1150, 82, 'textarea', 'extensions/layouts/82', 'index.php?option=com_extensions&view=layouts&id=82', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(85, 1150, 83, 'user', 'extensions/layouts/83', 'index.php?option=com_extensions&view=layouts&id=83', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(86, 1150, 84, 'article', 'extensions/layouts/84', 'index.php?option=com_extensions&view=layouts&id=84', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(87, 1150, 85, 'aside', 'extensions/layouts/85', 'index.php?option=com_extensions&view=layouts&id=85', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(88, 1150, 86, 'div', 'extensions/layouts/86', 'index.php?option=com_extensions&view=layouts&id=86', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(89, 1150, 87, 'footer', 'extensions/layouts/87', 'index.php?option=com_extensions&view=layouts&id=87', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(90, 1150, 88, 'header', 'extensions/layouts/88', 'index.php?option=com_extensions&view=layouts&id=88', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(91, 1150, 89, 'horizontal', 'extensions/layouts/89', 'index.php?option=com_extensions&view=layouts&id=89', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(92, 1150, 90, 'nav', 'extensions/layouts/90', 'index.php?option=com_extensions&view=layouts&id=90', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(93, 1150, 91, 'none', 'extensions/layouts/91', 'index.php?option=com_extensions&view=layouts&id=91', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(94, 1150, 92, 'outline', 'extensions/layouts/92', 'index.php?option=com_extensions&view=layouts&id=92', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(95, 1150, 93, 'section', 'extensions/layouts/93', 'index.php?option=com_extensions&view=layouts&id=93', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(96, 1150, 94, 'table', 'extensions/layouts/94', 'index.php?option=com_extensions&view=layouts&id=94', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(97, 1150, 95, 'tabs', 'extensions/layouts/95', 'index.php?option=com_extensions&view=layouts&id=95', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(101, 1200, 99, 'Doctrine', 'extensions/libraries/99', 'index.php?option=com_extensions&view=libraries&id=99', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(102, 1200, 100, 'includes', 'extensions/libraries/100', 'index.php?option=com_extensions&view=libraries&id=100', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(103, 1200, 101, 'jplatform', 'extensions/libraries/101', 'index.php?option=com_extensions&view=libraries&id=101', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(104, 1200, 102, 'molajo', 'extensions/libraries/102', 'index.php?option=com_extensions&view=libraries&id=102', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(105, 1200, 103, 'Twig', 'extensions/libraries/103', 'index.php?option=com_extensions&view=libraries&id=103', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(108, 1450, 106, 'example', 'extensions/plugins/106', 'index.php?option=com_extensions&view=plugins&id=106', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(109, 1450, 107, 'molajo', 'extensions/plugins/107', 'index.php?option=com_extensions&view=plugins&id=107', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(110, 1450, 108, 'broadcast', 'extensions/plugins/108', 'index.php?option=com_extensions&view=plugins&id=108', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(111, 1450, 109, 'content', 'extensions/plugins/109', 'index.php?option=com_extensions&view=plugins&id=109', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(112, 1450, 110, 'emailcloak', 'extensions/plugins/110', 'index.php?option=com_extensions&view=plugins&id=110', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(113, 1450, 111, 'links', 'extensions/plugins/111', 'index.php?option=com_extensions&view=plugins&id=111', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(114, 1450, 112, 'loadmodule', 'extensions/plugins/112', 'index.php?option=com_extensions&view=plugins&id=112', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(115, 1450, 113, 'media', 'extensions/plugins/113', 'index.php?option=com_extensions&view=plugins&id=113', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(116, 1450, 114, 'protect', 'extensions/plugins/114', 'index.php?option=com_extensions&view=plugins&id=114', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(117, 1450, 115, 'responses', 'extensions/plugins/115', 'index.php?option=com_extensions&view=plugins&id=115', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(118, 1450, 116, 'aloha', 'extensions/plugins/116', 'index.php?option=com_extensions&view=plugins&id=116', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(119, 1450, 117, 'none', 'extensions/plugins/117', 'index.php?option=com_extensions&view=plugins&id=117', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(120, 1450, 118, 'article', 'extensions/plugins/118', 'index.php?option=com_extensions&view=plugins&id=118', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(121, 1450, 119, 'editor', 'extensions/plugins/119', 'index.php?option=com_extensions&view=plugins&id=119', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(122, 1450, 120, 'image', 'extensions/plugins/120', 'index.php?option=com_extensions&view=plugins&id=120', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(123, 1450, 121, 'pagebreak', 'extensions/plugins/121', 'index.php?option=com_extensions&view=plugins&id=121', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(124, 1450, 122, 'readmore', 'extensions/plugins/122', 'index.php?option=com_extensions&view=plugins&id=122', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(125, 1450, 123, 'molajo', 'extensions/plugins/123', 'index.php?option=com_extensions&view=plugins&id=123', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(126, 1450, 124, 'extend', 'extensions/plugins/124', 'index.php?option=com_extensions&view=plugins&id=124', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(127, 1450, 125, 'minifier', 'extensions/plugins/125', 'index.php?option=com_extensions&view=plugins&id=125', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(128, 1450, 126, 'search', 'extensions/plugins/126', 'index.php?option=com_extensions&view=plugins&id=126', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(129, 1450, 127, 'tags', 'extensions/plugins/127', 'index.php?option=com_extensions&view=plugins&id=127', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(130, 1450, 128, 'urls', 'extensions/plugins/128', 'index.php?option=com_extensions&view=plugins&id=128', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(131, 1450, 129, 'molajosample', 'extensions/plugins/129', 'index.php?option=com_extensions&view=plugins&id=129', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(132, 1450, 130, 'categories', 'extensions/plugins/130', 'index.php?option=com_extensions&view=plugins&id=130', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(133, 1450, 131, 'articles', 'extensions/plugins/131', 'index.php?option=com_extensions&view=plugins&id=131', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(134, 1450, 132, 'cache', 'extensions/plugins/132', 'index.php?option=com_extensions&view=plugins&id=132', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(135, 1450, 133, 'compress', 'extensions/plugins/133', 'index.php?option=com_extensions&view=plugins&id=133', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(136, 1450, 134, 'create', 'extensions/plugins/134', 'index.php?option=com_extensions&view=plugins&id=134', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(137, 1450, 135, 'debug', 'extensions/plugins/135', 'index.php?option=com_extensions&view=plugins&id=135', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(138, 1450, 136, 'languagefilter', 'extensions/plugins/136', 'index.php?option=com_extensions&view=plugins&id=136', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(139, 1450, 137, 'log', 'extensions/plugins/137', 'index.php?option=com_extensions&view=plugins&id=137', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(140, 1450, 138, 'logout', 'extensions/plugins/138', 'index.php?option=com_extensions&view=plugins&id=138', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(141, 1450, 139, 'molajo', 'extensions/plugins/139', 'index.php?option=com_extensions&view=plugins&id=139', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(142, 1450, 140, 'p3p', 'extensions/plugins/140', 'index.php?option=com_extensions&view=plugins&id=140', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(143, 1450, 141, 'parameters', 'extensions/plugins/141', 'index.php?option=com_extensions&view=plugins&id=141', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(144, 1450, 142, 'redirect', 'extensions/plugins/142', 'index.php?option=com_extensions&view=plugins&id=142', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(145, 1450, 143, 'remember', 'extensions/plugins/143', 'index.php?option=com_extensions&view=plugins&id=143', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(146, 1450, 144, 'system', 'extensions/plugins/144', 'index.php?option=com_extensions&view=plugins&id=144', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(147, 1450, 145, 'webservices', 'extensions/plugins/145', 'index.php?option=com_extensions&view=plugins&id=145', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(148, 1450, 146, 'molajo', 'extensions/plugins/146', 'index.php?option=com_extensions&view=plugins&id=146', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(149, 1450, 147, 'profile', 'extensions/plugins/147', 'index.php?option=com_extensions&view=plugins&id=147', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(171, 1500, 169, 'construct', 'extensions/templates/169', 'index.php?option=com_extensions&view=templates&id=169', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(172, 1500, 170, 'install', 'extensions/templates/170', 'index.php?option=com_extensions&view=templates&id=170', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(173, 1500, 171, 'molajito', 'extensions/templates/171', 'index.php?option=com_extensions&view=templates&id=171', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(174, 1500, 172, 'sample', 'extensions/templates/172', 'index.php?option=com_extensions&view=templates&id=172', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(175, 1500, 173, 'system', 'extensions/templates/173', 'index.php?option=com_extensions&view=templates&id=173', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(178, 1300, 176, 'Administrator Menu', 'extensions/menus/176', 'index.php?option=com_menus&view=menus&id=176', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(179, 1300, 177, 'Main Menu', 'extensions/menus/177', 'index.php?option=com_menus&view=menus&id=177', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(181, 2000, 2, 'Create', 'create', 'index.php?option=com_dashboard&view=create', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(182, 2000, 3, 'Articles', 'create/articles', 'index.php?option=com_articles', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(183, 2000, 4, 'Contacts', 'create/contacts', 'index.php?option=com_contacts', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(184, 2000, 5, 'Comments', 'create/comments', 'index.php?option=com_comments', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(185, 2000, 6, 'Layouts', 'create/layouts', 'index.php?option=com_layouts', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(186, 2000, 7, 'Media', 'create/media', 'index.php?option=com_media', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(187, 2000, 8, 'Access', 'access', 'index.php?option=com_dashboard&view=users', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(188, 2000, 9, 'Profile', 'access/profiles', 'index.php?option=com_profile', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(189, 2000, 10, 'Users', 'access/users', 'index.php?option=com_users', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(190, 2000, 11, 'Groups', 'access/groups', 'index.php?option=com_groups', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(191, 2000, 12, 'Assets', 'access/assets', 'index.php?option=com_assets&view=users', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(192, 2000, 13, 'Build', 'build', 'index.php?option=com_dashboard&view=build', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(193, 2000, 14, 'Categories', 'build/categories', 'index.php?option=com_categories', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(194, 2000, 15, 'Menus', 'build/menus', 'index.php?option=com_extensions&view=menus', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(195, 2000, 16, 'Menu Items', 'build/menuitems', 'index.php?option=com_extensions&view=menuitems', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(196, 2000, 17, 'Modules', 'build/modules', 'index.php?option=com_extensions&view=modules', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(197, 2000, 18, 'Templates', 'build/templates', 'index.php?option=com_extensions&view=templates', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(198, 2000, 19, 'Configure', 'configure', 'index.php?option=com_dashboard&view=options', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(199, 2000, 20, 'Site', 'configure/sites', 'index.php?option=com_extensions&view=sites', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(200, 2000, 21, 'Applications', 'configure/applications', 'index.php?option=com_extensions&view=applications', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(201, 2000, 22, 'Checkin', 'configure/checkin', 'index.php?option=com_maintain&view=checkin', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(202, 2000, 23, 'Clean Cache', 'configure/cleancache', 'index.php?option=com_maintain&view=cleancache', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(203, 2000, 24, 'Redirects', 'configure/redirects', 'index.php?option=com_maintain&view=redirects', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(204, 2000, 25, 'Plugins', 'configure/plugins', 'index.php?option=com_extensions&view=plugins', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(205, 2000, 26, 'Extend', 'extend', 'index.php?option=com_dashboard&view=install', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(206, 2000, 27, 'Create', 'extend/install', 'index.php?option=com_installer&view=create', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(207, 2000, 28, 'Update', 'install/update', 'index.php?option=com_installer&view=update', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(208, 2000, 29, 'Uninstall', 'install/uninstall', 'index.php?option=com_installer&view=uninstall', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(209, 2000, 30, 'Search', 'search', 'index.php?option=com_search', 1, 0, 'en-GB', 0, 0, 3);
INSERT INTO `molajo_assets` VALUES(210, 2000, 31, 'Home', 'home', 'index.php?option=com_layouts', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(211, 1350, 179, 'mod_assetwidget', 'extensions/modules/179', 'index.php?option=com_extensions&view=modules&id=179', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(212, 1350, 180, 'mod_aclwidget', 'extensions/modules/180', 'index.php?option=com_extensions&view=modules&id=180', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(213, 1350, 181, 'mod_breadcrumbs', 'extensions/modules/181', 'index.php?option=com_extensions&view=modules&id=181', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(214, 1350, 182, 'mod_debug', 'extensions/modules/182', 'index.php?option=com_extensions&view=modules&id=182', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(215, 1350, 183, 'mod_categorywidget', 'extensions/modules/183', 'index.php?option=com_extensions&view=modules&id=183', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(216, 1350, 184, 'mod_content', 'extensions/modules/184', 'index.php?option=com_extensions&view=modules&id=184', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(217, 1350, 185, 'mod_custom', 'extensions/modules/185', 'index.php?option=com_extensions&view=modules&id=185', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(218, 1350, 186, 'mod_groupwidget', 'extensions/modules/186', 'index.php?option=com_extensions&view=modules&id=186', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(219, 1350, 187, 'mod_feed', 'extensions/modules/187', 'index.php?option=com_extensions&view=modules&id=187', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(220, 1350, 188, 'mod_filters', 'extensions/modules/188', 'index.php?option=com_extensions&view=modules&id=188', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(221, 1350, 189, 'mod_filebrowser', 'extensions/modules/189', 'index.php?option=com_extensions&view=modules&id=189', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(222, 1350, 190, 'mod_footer', 'extensions/modules/190', 'index.php?option=com_extensions&view=modules&id=190', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(223, 1350, 191, 'mod_gallery', 'extensions/modules/191', 'index.php?option=com_extensions&view=modules&id=191', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(224, 1350, 192, 'mod_grid', 'extensions/modules/192', 'index.php?option=com_extensions&view=modules&id=192', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(225, 1350, 193, 'mod_gridbatch', 'extensions/modules/193', 'index.php?option=com_extensions&view=modules&id=193', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(226, 1350, 194, 'mod_header', 'extensions/modules/194', 'index.php?option=com_extensions&view=modules&id=194', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(227, 1350, 195, 'mod_iconbutton', 'extensions/modules/195', 'index.php?option=com_extensions&view=modules&id=195', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(228, 1350, 196, 'mod_layout', 'extensions/modules/196', 'index.php?option=com_extensions&view=modules&id=196', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(229, 1350, 197, 'mod_login', 'extensions/modules/197', 'index.php?option=com_extensions&view=modules&id=197', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(230, 1350, 198, 'mod_logout', 'extensions/modules/198', 'index.php?option=com_extensions&view=modules&id=198', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(231, 1350, 199, 'mod_members', 'extensions/modules/199', 'index.php?option=com_extensions&view=modules&id=199', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(232, 1350, 200, 'mod_pagination', 'extensions/modules/200', 'index.php?option=com_extensions&view=modules&id=200', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(233, 1350, 201, 'mod_plugins', 'extensions/modules/201', 'index.php?option=com_extensions&view=modules&id=201', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(234, 1350, 202, 'mod_quicklinks', 'extensions/modules/202', 'index.php?option=com_extensions&view=modules&id=202', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(235, 1350, 203, 'mod_search', 'extensions/modules/203', 'index.php?option=com_extensions&view=modules&id=203', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(236, 1350, 204, 'mod_submenu', 'extensions/modules/204', 'index.php?option=com_extensions&view=modules&id=204', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(237, 1350, 205, 'mod_syndicate', 'extensions/modules/205', 'index.php?option=com_extensions&view=modules&id=205', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(238, 1350, 206, 'mod_textbox', 'extensions/modules/206', 'index.php?option=com_extensions&view=modules&id=206', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(239, 1350, 207, 'mod_title', 'extensions/modules/207', 'index.php?option=com_extensions&view=modules&id=207', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(240, 1350, 208, 'mod_toolbar', 'extensions/modules/208', 'index.php?option=com_extensions&view=modules&id=208', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(241, 1350, 210, 'Administrator Menu Module', 'extensions/modules/210', 'index.php?option=com_extensions&view=modules&id=210', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(242, 1350, 211, 'Main Menu Module', 'extensions/modules/211', 'index.php?option=com_extensions&view=modules&id=211', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(274, 100, 1, 'Public', 'groups/1', 'index.php?option=com_groups&id=1', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(275, 100, 2, 'Guest', 'groups/2', 'index.php?option=com_groups&id=2', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(276, 100, 3, 'Registered', 'groups/3', 'index.php?option=com_groups&id=3', 1, 0, 'en-GB', 0, 0, 1);
INSERT INTO `molajo_assets` VALUES(277, 100, 4, 'Administrator', 'groups/4', 'index.php?option=com_groups&id=4', 1, 0, 'en-GB', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_asset_categories`
--

CREATE TABLE `molajo_asset_categories` (
  `asset_id` int(11) unsigned NOT NULL DEFAULT '0',
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`asset_id`,`category_id`),
  KEY `fk_asset_categories_assets2` (`asset_id`),
  KEY `fk_asset_categories_categories2` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_asset_categories`
--

INSERT INTO `molajo_asset_categories` VALUES(1, 1);
INSERT INTO `molajo_asset_categories` VALUES(2, 1);
INSERT INTO `molajo_asset_categories` VALUES(4, 1);
INSERT INTO `molajo_asset_categories` VALUES(5, 1);
INSERT INTO `molajo_asset_categories` VALUES(6, 1);
INSERT INTO `molajo_asset_categories` VALUES(7, 1);
INSERT INTO `molajo_asset_categories` VALUES(8, 1);
INSERT INTO `molajo_asset_categories` VALUES(9, 1);
INSERT INTO `molajo_asset_categories` VALUES(10, 1);
INSERT INTO `molajo_asset_categories` VALUES(11, 1);
INSERT INTO `molajo_asset_categories` VALUES(12, 1);
INSERT INTO `molajo_asset_categories` VALUES(13, 1);
INSERT INTO `molajo_asset_categories` VALUES(14, 1);
INSERT INTO `molajo_asset_categories` VALUES(15, 1);
INSERT INTO `molajo_asset_categories` VALUES(16, 1);
INSERT INTO `molajo_asset_categories` VALUES(17, 1);
INSERT INTO `molajo_asset_categories` VALUES(18, 1);
INSERT INTO `molajo_asset_categories` VALUES(19, 1);
INSERT INTO `molajo_asset_categories` VALUES(20, 1);
INSERT INTO `molajo_asset_categories` VALUES(21, 1);
INSERT INTO `molajo_asset_categories` VALUES(35, 1);
INSERT INTO `molajo_asset_categories` VALUES(36, 1);
INSERT INTO `molajo_asset_categories` VALUES(38, 1);
INSERT INTO `molajo_asset_categories` VALUES(39, 1);
INSERT INTO `molajo_asset_categories` VALUES(40, 1);
INSERT INTO `molajo_asset_categories` VALUES(41, 1);
INSERT INTO `molajo_asset_categories` VALUES(42, 1);
INSERT INTO `molajo_asset_categories` VALUES(43, 1);
INSERT INTO `molajo_asset_categories` VALUES(44, 1);
INSERT INTO `molajo_asset_categories` VALUES(45, 1);
INSERT INTO `molajo_asset_categories` VALUES(46, 1);
INSERT INTO `molajo_asset_categories` VALUES(47, 1);
INSERT INTO `molajo_asset_categories` VALUES(48, 1);
INSERT INTO `molajo_asset_categories` VALUES(49, 1);
INSERT INTO `molajo_asset_categories` VALUES(50, 1);
INSERT INTO `molajo_asset_categories` VALUES(51, 1);
INSERT INTO `molajo_asset_categories` VALUES(52, 1);
INSERT INTO `molajo_asset_categories` VALUES(53, 1);
INSERT INTO `molajo_asset_categories` VALUES(54, 1);
INSERT INTO `molajo_asset_categories` VALUES(55, 1);
INSERT INTO `molajo_asset_categories` VALUES(56, 1);
INSERT INTO `molajo_asset_categories` VALUES(57, 1);
INSERT INTO `molajo_asset_categories` VALUES(58, 1);
INSERT INTO `molajo_asset_categories` VALUES(59, 1);
INSERT INTO `molajo_asset_categories` VALUES(60, 1);
INSERT INTO `molajo_asset_categories` VALUES(61, 1);
INSERT INTO `molajo_asset_categories` VALUES(62, 1);
INSERT INTO `molajo_asset_categories` VALUES(63, 1);
INSERT INTO `molajo_asset_categories` VALUES(64, 1);
INSERT INTO `molajo_asset_categories` VALUES(65, 1);
INSERT INTO `molajo_asset_categories` VALUES(66, 1);
INSERT INTO `molajo_asset_categories` VALUES(67, 1);
INSERT INTO `molajo_asset_categories` VALUES(68, 1);
INSERT INTO `molajo_asset_categories` VALUES(69, 1);
INSERT INTO `molajo_asset_categories` VALUES(70, 1);
INSERT INTO `molajo_asset_categories` VALUES(71, 1);
INSERT INTO `molajo_asset_categories` VALUES(72, 1);
INSERT INTO `molajo_asset_categories` VALUES(73, 1);
INSERT INTO `molajo_asset_categories` VALUES(74, 1);
INSERT INTO `molajo_asset_categories` VALUES(75, 1);
INSERT INTO `molajo_asset_categories` VALUES(76, 1);
INSERT INTO `molajo_asset_categories` VALUES(77, 1);
INSERT INTO `molajo_asset_categories` VALUES(78, 1);
INSERT INTO `molajo_asset_categories` VALUES(79, 1);
INSERT INTO `molajo_asset_categories` VALUES(80, 1);
INSERT INTO `molajo_asset_categories` VALUES(81, 1);
INSERT INTO `molajo_asset_categories` VALUES(82, 1);
INSERT INTO `molajo_asset_categories` VALUES(83, 1);
INSERT INTO `molajo_asset_categories` VALUES(84, 1);
INSERT INTO `molajo_asset_categories` VALUES(85, 1);
INSERT INTO `molajo_asset_categories` VALUES(86, 1);
INSERT INTO `molajo_asset_categories` VALUES(87, 1);
INSERT INTO `molajo_asset_categories` VALUES(88, 1);
INSERT INTO `molajo_asset_categories` VALUES(89, 1);
INSERT INTO `molajo_asset_categories` VALUES(90, 1);
INSERT INTO `molajo_asset_categories` VALUES(91, 1);
INSERT INTO `molajo_asset_categories` VALUES(92, 1);
INSERT INTO `molajo_asset_categories` VALUES(93, 1);
INSERT INTO `molajo_asset_categories` VALUES(94, 1);
INSERT INTO `molajo_asset_categories` VALUES(95, 1);
INSERT INTO `molajo_asset_categories` VALUES(96, 1);
INSERT INTO `molajo_asset_categories` VALUES(97, 1);
INSERT INTO `molajo_asset_categories` VALUES(101, 1);
INSERT INTO `molajo_asset_categories` VALUES(102, 1);
INSERT INTO `molajo_asset_categories` VALUES(103, 1);
INSERT INTO `molajo_asset_categories` VALUES(104, 1);
INSERT INTO `molajo_asset_categories` VALUES(105, 1);
INSERT INTO `molajo_asset_categories` VALUES(108, 1);
INSERT INTO `molajo_asset_categories` VALUES(109, 1);
INSERT INTO `molajo_asset_categories` VALUES(110, 1);
INSERT INTO `molajo_asset_categories` VALUES(111, 1);
INSERT INTO `molajo_asset_categories` VALUES(112, 1);
INSERT INTO `molajo_asset_categories` VALUES(113, 1);
INSERT INTO `molajo_asset_categories` VALUES(114, 1);
INSERT INTO `molajo_asset_categories` VALUES(115, 1);
INSERT INTO `molajo_asset_categories` VALUES(116, 1);
INSERT INTO `molajo_asset_categories` VALUES(117, 1);
INSERT INTO `molajo_asset_categories` VALUES(118, 1);
INSERT INTO `molajo_asset_categories` VALUES(119, 1);
INSERT INTO `molajo_asset_categories` VALUES(120, 1);
INSERT INTO `molajo_asset_categories` VALUES(121, 1);
INSERT INTO `molajo_asset_categories` VALUES(122, 1);
INSERT INTO `molajo_asset_categories` VALUES(123, 1);
INSERT INTO `molajo_asset_categories` VALUES(124, 1);
INSERT INTO `molajo_asset_categories` VALUES(125, 1);
INSERT INTO `molajo_asset_categories` VALUES(126, 1);
INSERT INTO `molajo_asset_categories` VALUES(127, 1);
INSERT INTO `molajo_asset_categories` VALUES(128, 1);
INSERT INTO `molajo_asset_categories` VALUES(129, 1);
INSERT INTO `molajo_asset_categories` VALUES(130, 1);
INSERT INTO `molajo_asset_categories` VALUES(131, 1);
INSERT INTO `molajo_asset_categories` VALUES(132, 1);
INSERT INTO `molajo_asset_categories` VALUES(133, 1);
INSERT INTO `molajo_asset_categories` VALUES(134, 1);
INSERT INTO `molajo_asset_categories` VALUES(135, 1);
INSERT INTO `molajo_asset_categories` VALUES(136, 1);
INSERT INTO `molajo_asset_categories` VALUES(137, 1);
INSERT INTO `molajo_asset_categories` VALUES(138, 1);
INSERT INTO `molajo_asset_categories` VALUES(139, 1);
INSERT INTO `molajo_asset_categories` VALUES(140, 1);
INSERT INTO `molajo_asset_categories` VALUES(141, 1);
INSERT INTO `molajo_asset_categories` VALUES(142, 1);
INSERT INTO `molajo_asset_categories` VALUES(143, 1);
INSERT INTO `molajo_asset_categories` VALUES(144, 1);
INSERT INTO `molajo_asset_categories` VALUES(145, 1);
INSERT INTO `molajo_asset_categories` VALUES(146, 1);
INSERT INTO `molajo_asset_categories` VALUES(147, 1);
INSERT INTO `molajo_asset_categories` VALUES(148, 1);
INSERT INTO `molajo_asset_categories` VALUES(149, 1);
INSERT INTO `molajo_asset_categories` VALUES(171, 1);
INSERT INTO `molajo_asset_categories` VALUES(172, 1);
INSERT INTO `molajo_asset_categories` VALUES(173, 1);
INSERT INTO `molajo_asset_categories` VALUES(174, 1);
INSERT INTO `molajo_asset_categories` VALUES(175, 1);
INSERT INTO `molajo_asset_categories` VALUES(178, 1);
INSERT INTO `molajo_asset_categories` VALUES(179, 1);
INSERT INTO `molajo_asset_categories` VALUES(181, 1);
INSERT INTO `molajo_asset_categories` VALUES(182, 1);
INSERT INTO `molajo_asset_categories` VALUES(183, 1);
INSERT INTO `molajo_asset_categories` VALUES(184, 1);
INSERT INTO `molajo_asset_categories` VALUES(185, 1);
INSERT INTO `molajo_asset_categories` VALUES(186, 1);
INSERT INTO `molajo_asset_categories` VALUES(187, 1);
INSERT INTO `molajo_asset_categories` VALUES(188, 1);
INSERT INTO `molajo_asset_categories` VALUES(189, 1);
INSERT INTO `molajo_asset_categories` VALUES(190, 1);
INSERT INTO `molajo_asset_categories` VALUES(191, 1);
INSERT INTO `molajo_asset_categories` VALUES(192, 1);
INSERT INTO `molajo_asset_categories` VALUES(193, 1);
INSERT INTO `molajo_asset_categories` VALUES(194, 1);
INSERT INTO `molajo_asset_categories` VALUES(195, 1);
INSERT INTO `molajo_asset_categories` VALUES(196, 1);
INSERT INTO `molajo_asset_categories` VALUES(197, 1);
INSERT INTO `molajo_asset_categories` VALUES(198, 1);
INSERT INTO `molajo_asset_categories` VALUES(199, 1);
INSERT INTO `molajo_asset_categories` VALUES(200, 1);
INSERT INTO `molajo_asset_categories` VALUES(201, 1);
INSERT INTO `molajo_asset_categories` VALUES(202, 1);
INSERT INTO `molajo_asset_categories` VALUES(203, 1);
INSERT INTO `molajo_asset_categories` VALUES(204, 1);
INSERT INTO `molajo_asset_categories` VALUES(205, 1);
INSERT INTO `molajo_asset_categories` VALUES(206, 1);
INSERT INTO `molajo_asset_categories` VALUES(207, 1);
INSERT INTO `molajo_asset_categories` VALUES(208, 1);
INSERT INTO `molajo_asset_categories` VALUES(209, 1);
INSERT INTO `molajo_asset_categories` VALUES(210, 1);
INSERT INTO `molajo_asset_categories` VALUES(211, 1);
INSERT INTO `molajo_asset_categories` VALUES(212, 1);
INSERT INTO `molajo_asset_categories` VALUES(213, 1);
INSERT INTO `molajo_asset_categories` VALUES(214, 1);
INSERT INTO `molajo_asset_categories` VALUES(215, 1);
INSERT INTO `molajo_asset_categories` VALUES(216, 1);
INSERT INTO `molajo_asset_categories` VALUES(217, 1);
INSERT INTO `molajo_asset_categories` VALUES(218, 1);
INSERT INTO `molajo_asset_categories` VALUES(219, 1);
INSERT INTO `molajo_asset_categories` VALUES(220, 1);
INSERT INTO `molajo_asset_categories` VALUES(221, 1);
INSERT INTO `molajo_asset_categories` VALUES(222, 1);
INSERT INTO `molajo_asset_categories` VALUES(223, 1);
INSERT INTO `molajo_asset_categories` VALUES(224, 1);
INSERT INTO `molajo_asset_categories` VALUES(225, 1);
INSERT INTO `molajo_asset_categories` VALUES(226, 1);
INSERT INTO `molajo_asset_categories` VALUES(227, 1);
INSERT INTO `molajo_asset_categories` VALUES(228, 1);
INSERT INTO `molajo_asset_categories` VALUES(229, 1);
INSERT INTO `molajo_asset_categories` VALUES(230, 1);
INSERT INTO `molajo_asset_categories` VALUES(231, 1);
INSERT INTO `molajo_asset_categories` VALUES(232, 1);
INSERT INTO `molajo_asset_categories` VALUES(233, 1);
INSERT INTO `molajo_asset_categories` VALUES(234, 1);
INSERT INTO `molajo_asset_categories` VALUES(235, 1);
INSERT INTO `molajo_asset_categories` VALUES(236, 1);
INSERT INTO `molajo_asset_categories` VALUES(237, 1);
INSERT INTO `molajo_asset_categories` VALUES(238, 1);
INSERT INTO `molajo_asset_categories` VALUES(239, 1);
INSERT INTO `molajo_asset_categories` VALUES(240, 1);
INSERT INTO `molajo_asset_categories` VALUES(241, 1);
INSERT INTO `molajo_asset_categories` VALUES(242, 1);
INSERT INTO `molajo_asset_categories` VALUES(274, 1);
INSERT INTO `molajo_asset_categories` VALUES(275, 1);
INSERT INTO `molajo_asset_categories` VALUES(276, 1);
INSERT INTO `molajo_asset_categories` VALUES(277, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_asset_modules`
--

CREATE TABLE `molajo_asset_modules` (
  `asset_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Actions Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`asset_id`,`extension_instance_id`),
  KEY `fk_asset_modules_assets` (`asset_id`),
  KEY `fk_asset_modules_extension_instances` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_asset_modules`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_categories`
--

CREATE TABLE `molajo_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `content_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext,
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `position` varchar(45) NOT NULL DEFAULT ' ',
  `metadata` mediumtext,
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_categories_extension_instances2` (`extension_instance_id`),
  KEY `fk_categories_content_type_ids2` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `molajo_categories`
--

INSERT INTO `molajo_categories` VALUES(0, 4, 10, 'ROOT', '', 'root', '<p>Root category</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_categories` VALUES(1, 4, 3000, 'System', '', 'system', '<p>System category</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_component_options`
--

CREATE TABLE `molajo_component_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `option_id` int(11) unsigned NOT NULL DEFAULT '0',
  `option_value_literal` varchar(255) NOT NULL DEFAULT '',
  `option_value` varchar(80) NOT NULL DEFAULT '',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_component_options_extension_instances2` (`extension_instance_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=443 ;

--
-- Dumping data for table `molajo_component_options`
--

INSERT INTO `molajo_component_options` VALUES(1, 1, 0, 100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(2, 1, 0, 100, '__common', '__common', 1);
INSERT INTO `molajo_component_options` VALUES(3, 1, 0, 200, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(4, 1, 0, 200, 'MOLAJO_FIELD_ACCESS_LABEL', 'access', 1);
INSERT INTO `molajo_component_options` VALUES(5, 1, 0, 200, 'MOLAJO_FIELD_ALIAS_LABEL', 'alias', 2);
INSERT INTO `molajo_component_options` VALUES(6, 1, 0, 200, 'MOLAJO_FIELD_ASSET_ID_LABEL', 'asset_id', 3);
INSERT INTO `molajo_component_options` VALUES(7, 1, 0, 200, 'MOLAJO_FIELD_ATTRIBS_LABEL', 'attribs', 4);
INSERT INTO `molajo_component_options` VALUES(8, 1, 0, 200, 'MOLAJO_FIELD_CATID_LABEL', 'catid', 5);
INSERT INTO `molajo_component_options` VALUES(9, 1, 0, 200, 'MOLAJO_FIELD_CHECKED_OUT_LABEL', 'checked_out', 6);
INSERT INTO `molajo_component_options` VALUES(10, 1, 0, 200, 'MOLAJO_FIELD_CHECKED_OUT_TIME_LABEL', 'checked_out_time', 7);
INSERT INTO `molajo_component_options` VALUES(11, 1, 0, 200, 'MOLAJO_FIELD_COMPONENT_ID_LABEL', 'component_id', 8);
INSERT INTO `molajo_component_options` VALUES(12, 1, 0, 200, 'MOLAJO_FIELD_CONTENT_TABLE_LABEL', 'content_table', 9);
INSERT INTO `molajo_component_options` VALUES(13, 1, 0, 200, 'MOLAJO_FIELD_CONTENT_EMAIL_ADDRESS_LABEL', 'content_email_address', 10);
INSERT INTO `molajo_component_options` VALUES(14, 1, 0, 200, 'MOLAJO_FIELD_CONTENT_FILE_LABEL', 'content_file', 11);
INSERT INTO `molajo_component_options` VALUES(15, 1, 0, 200, 'MOLAJO_FIELD_CONTENT_LINK_LABEL', 'content_link', 12);
INSERT INTO `molajo_component_options` VALUES(16, 1, 0, 200, 'MOLAJO_FIELD_CONTENT_NUMERIC_VALUE_LABEL', 'content_numeric_value', 13);
INSERT INTO `molajo_component_options` VALUES(17, 1, 0, 200, 'MOLAJO_FIELD_CONTENT_TEXT_LABEL', 'content_text', 14);
INSERT INTO `molajo_component_options` VALUES(18, 1, 0, 200, 'MOLAJO_FIELD_CONTENT_TYPE_LABEL', 'content_type_id', 15);
INSERT INTO `molajo_component_options` VALUES(19, 1, 0, 200, 'MOLAJO_FIELD_CREATED_LABEL', 'created', 16);
INSERT INTO `molajo_component_options` VALUES(20, 1, 0, 200, 'MOLAJO_FIELD_CREATED_BY_LABEL', 'created_by', 17);
INSERT INTO `molajo_component_options` VALUES(21, 1, 0, 200, 'MOLAJO_FIELD_CREATED_BY_ALIAS_LABEL', 'created_by_alias', 18);
INSERT INTO `molajo_component_options` VALUES(22, 1, 0, 200, 'MOLAJO_FIELD_CREATED_BY_EMAIL_LABEL', 'created_by_email', 19);
INSERT INTO `molajo_component_options` VALUES(23, 1, 0, 200, 'MOLAJO_FIELD_CREATED_BY_IP_ADDRESS_LABEL', 'created_by_ip_address', 20);
INSERT INTO `molajo_component_options` VALUES(24, 1, 0, 200, 'MOLAJO_FIELD_CREATED_BY_REFERER_LABEL', 'created_by_referer', 21);
INSERT INTO `molajo_component_options` VALUES(25, 1, 0, 200, 'MOLAJO_FIELD_CREATED_BY_WEBSITE_LABEL', 'created_by_website', 22);
INSERT INTO `molajo_component_options` VALUES(26, 1, 0, 200, 'MOLAJO_FIELD_FEATURED_LABEL', 'featured', 23);
INSERT INTO `molajo_component_options` VALUES(27, 1, 0, 200, 'MOLAJO_FIELD_ID_LABEL', 'id', 24);
INSERT INTO `molajo_component_options` VALUES(28, 1, 0, 200, 'MOLAJO_FIELD_LANGUAGE_LABEL', 'language', 25);
INSERT INTO `molajo_component_options` VALUES(29, 1, 0, 200, 'MOLAJO_FIELD_LEVEL_LABEL', 'level', 26);
INSERT INTO `molajo_component_options` VALUES(30, 1, 0, 200, 'MOLAJO_FIELD_LFT_LABEL', 'lft', 27);
INSERT INTO `molajo_component_options` VALUES(31, 1, 0, 200, 'MOLAJO_FIELD_METADATA_LABEL', 'metadata', 28);
INSERT INTO `molajo_component_options` VALUES(32, 1, 0, 200, 'MOLAJO_FIELD_METADESC_LABEL', 'metadesc', 29);
INSERT INTO `molajo_component_options` VALUES(33, 1, 0, 200, 'MOLAJO_FIELD_METAKEY_LABEL', 'metakey', 30);
INSERT INTO `molajo_component_options` VALUES(34, 1, 0, 200, 'MOLAJO_FIELD_META_AUTHOR_LABEL', 'meta_author', 31);
INSERT INTO `molajo_component_options` VALUES(35, 1, 0, 200, 'MOLAJO_FIELD_META_RIGHTS_LABEL', 'meta_rights', 32);
INSERT INTO `molajo_component_options` VALUES(36, 1, 0, 200, 'MOLAJO_FIELD_META_ROBOTS_LABEL', 'meta_robots', 33);
INSERT INTO `molajo_component_options` VALUES(37, 1, 0, 200, 'MOLAJO_FIELD_MODIFIED_LABEL', 'modified', 34);
INSERT INTO `molajo_component_options` VALUES(38, 1, 0, 200, 'MOLAJO_FIELD_MODIFIED_BY_LABEL', 'modified_by', 35);
INSERT INTO `molajo_component_options` VALUES(39, 1, 0, 200, 'MOLAJO_FIELD_ORDERING_LABEL', 'ordering', 36);
INSERT INTO `molajo_component_options` VALUES(40, 1, 0, 200, 'MOLAJO_FIELD_PUBLISH_DOWN_LABEL', 'stop_publishing_datetime', 37);
INSERT INTO `molajo_component_options` VALUES(41, 1, 0, 200, 'MOLAJO_FIELD_PUBLISH_UP_LABEL', 'start_publishing_datetime', 38);
INSERT INTO `molajo_component_options` VALUES(42, 1, 0, 200, 'MOLAJO_FIELD_RGT_LABEL', 'rgt', 39);
INSERT INTO `molajo_component_options` VALUES(43, 1, 0, 200, 'MOLAJO_FIELD_STATE_LABEL', 'state', 40);
INSERT INTO `molajo_component_options` VALUES(44, 1, 0, 200, 'MOLAJO_FIELD_STATE_PRIOR_TO_VERSION_LABEL', 'state_prior_to_version', 41);
INSERT INTO `molajo_component_options` VALUES(45, 1, 0, 200, 'MOLAJO_FIELD_STICKIED_LABEL', 'stickied', 42);
INSERT INTO `molajo_component_options` VALUES(46, 1, 0, 200, 'MOLAJO_FIELD_USER_DEFAULT_LABEL', 'user_default', 43);
INSERT INTO `molajo_component_options` VALUES(47, 1, 0, 200, 'MOLAJO_FIELD_CATEGORY_DEFAULT_LABEL', 'category_default', 44);
INSERT INTO `molajo_component_options` VALUES(48, 1, 0, 200, 'MOLAJO_FIELD_TITLE_LABEL', 'title', 45);
INSERT INTO `molajo_component_options` VALUES(49, 1, 0, 200, 'MOLAJO_FIELD_SUBTITLE_LABEL', 'subtitle', 46);
INSERT INTO `molajo_component_options` VALUES(50, 1, 0, 200, 'MOLAJO_FIELD_VERSION_LABEL', 'version', 47);
INSERT INTO `molajo_component_options` VALUES(51, 1, 0, 200, 'MOLAJO_FIELD_VERSION_OF_ID_LABEL', 'version_of_id', 48);
INSERT INTO `molajo_component_options` VALUES(52, 1, 0, 210, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(53, 1, 0, 210, 'MOLAJO_FIELD_ACCESS_LABEL', 'access', 1);
INSERT INTO `molajo_component_options` VALUES(54, 1, 0, 210, 'MOLAJO_FIELD_FEATURED_LABEL', 'featured', 2);
INSERT INTO `molajo_component_options` VALUES(55, 1, 0, 210, 'MOLAJO_FIELD_ORDERING_LABEL', 'ordering', 3);
INSERT INTO `molajo_component_options` VALUES(56, 1, 0, 210, 'MOLAJO_FIELD_PUBLISH_DOWN_LABEL', 'stop_publishing_datetime', 4);
INSERT INTO `molajo_component_options` VALUES(57, 1, 0, 210, 'MOLAJO_FIELD_PUBLISH_UP_LABEL', 'start_publishing_datetime', 5);
INSERT INTO `molajo_component_options` VALUES(58, 1, 0, 210, 'MOLAJO_FIELD_STATE_LABEL', 'state', 6);
INSERT INTO `molajo_component_options` VALUES(59, 1, 0, 210, 'MOLAJO_FIELD_STICKIED_LABEL', 'stickied', 7);
INSERT INTO `molajo_component_options` VALUES(60, 1, 0, 220, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(61, 1, 0, 220, 'MOLAJO_FIELD_ATTRIBS_LABEL', 'attribs', 1);
INSERT INTO `molajo_component_options` VALUES(62, 1, 0, 220, 'MOLAJO_FIELD_METADATA_LABEL', 'metadata', 2);
INSERT INTO `molajo_component_options` VALUES(63, 1, 0, 220, 'MOLAJO_FIELD_PARAMETERS_LABEL', 'parameters', 3);
INSERT INTO `molajo_component_options` VALUES(64, 1, 0, 230, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(65, 1, 0, 230, 'Content Type', 'content_type_id', 1);
INSERT INTO `molajo_component_options` VALUES(66, 1, 0, 250, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(67, 1, 0, 250, 'MOLAJO_OPTION_ARCHIVED', '2', 1);
INSERT INTO `molajo_component_options` VALUES(68, 1, 0, 250, 'MOLAJO_OPTION_PUBLISHED', '1', 2);
INSERT INTO `molajo_component_options` VALUES(69, 1, 0, 250, 'MOLAJO_OPTION_UNPUBLISHED', '0', 3);
INSERT INTO `molajo_component_options` VALUES(70, 1, 0, 250, 'MOLAJO_OPTION_TRASHED', '-1', 4);
INSERT INTO `molajo_component_options` VALUES(71, 1, 0, 250, 'MOLAJO_OPTION_SPAMMED', '-2', 5);
INSERT INTO `molajo_component_options` VALUES(72, 1, 0, 250, 'MOLAJO_OPTION_VERSION', '-10', 6);
INSERT INTO `molajo_component_options` VALUES(73, 1, 0, 300, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(74, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_ARCHIVE', 'archive', 1);
INSERT INTO `molajo_component_options` VALUES(75, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_CHECKIN', 'checkin', 2);
INSERT INTO `molajo_component_options` VALUES(76, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_DELETE', 'delete', 3);
INSERT INTO `molajo_component_options` VALUES(77, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_EDIT', 'edit', 4);
INSERT INTO `molajo_component_options` VALUES(78, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_FEATURE', 'feature', 5);
INSERT INTO `molajo_component_options` VALUES(79, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_HELP', 'help', 6);
INSERT INTO `molajo_component_options` VALUES(80, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_NEW', 'new', 7);
INSERT INTO `molajo_component_options` VALUES(81, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_OPTIONS', 'options', 8);
INSERT INTO `molajo_component_options` VALUES(82, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_PUBLISH', 'publish', 9);
INSERT INTO `molajo_component_options` VALUES(83, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_RESTORE', 'restore', 10);
INSERT INTO `molajo_component_options` VALUES(84, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SEPARATOR', 'separator', 11);
INSERT INTO `molajo_component_options` VALUES(85, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SPAM', 'spam', 12);
INSERT INTO `molajo_component_options` VALUES(86, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_STICKY', 'sticky', 13);
INSERT INTO `molajo_component_options` VALUES(87, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_TRASH', 'trash', 14);
INSERT INTO `molajo_component_options` VALUES(88, 1, 0, 300, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_UNPUBLISH', 'unpublish', 15);
INSERT INTO `molajo_component_options` VALUES(89, 1, 0, 310, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(90, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_APPLY', 'apply', 1);
INSERT INTO `molajo_component_options` VALUES(91, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_CLOSE', 'close', 2);
INSERT INTO `molajo_component_options` VALUES(92, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_HELP', 'help', 3);
INSERT INTO `molajo_component_options` VALUES(93, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_RESTORE', 'restore', 4);
INSERT INTO `molajo_component_options` VALUES(94, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SAVE', 'save', 5);
INSERT INTO `molajo_component_options` VALUES(95, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SAVE_AND_NEW', 'save2new', 6);
INSERT INTO `molajo_component_options` VALUES(96, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SAVE_AS_COPY', 'save2copy', 7);
INSERT INTO `molajo_component_options` VALUES(97, 1, 0, 310, 'MOLAJO_CONFIG_MANAGER_OPTION_BUTTON_SEPARATOR', 'separator', 8);
INSERT INTO `molajo_component_options` VALUES(98, 1, 0, 320, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(99, 1, 0, 320, 'MOLAJO_CONFIG_MANAGER_SUB_MENU_CATEGORY', 'category', 1);
INSERT INTO `molajo_component_options` VALUES(100, 1, 0, 320, 'MOLAJO_CONFIG_MANAGER_SUB_MENU_DEFAULT', 'default', 2);
INSERT INTO `molajo_component_options` VALUES(101, 1, 0, 320, 'MOLAJO_CONFIG_MANAGER_SUB_MENU_FEATURED', 'featured', 3);
INSERT INTO `molajo_component_options` VALUES(102, 1, 0, 320, 'MOLAJO_CONFIG_MANAGER_SUB_MENU_REVISIONS', 'revisions', 4);
INSERT INTO `molajo_component_options` VALUES(103, 1, 0, 320, 'MOLAJO_CONFIG_MANAGER_SUB_MENU_STICKIED', 'stickied', 5);
INSERT INTO `molajo_component_options` VALUES(104, 1, 0, 320, 'MOLAJO_CONFIG_MANAGER_SUB_MENU_UNPUBLISHED', 'unpublished', 6);
INSERT INTO `molajo_component_options` VALUES(105, 1, 0, 330, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(106, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_ACCESS', 'access', 1);
INSERT INTO `molajo_component_options` VALUES(107, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_ALIAS', 'alias', 2);
INSERT INTO `molajo_component_options` VALUES(108, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_AUTHOR', 'created_by', 3);
INSERT INTO `molajo_component_options` VALUES(109, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_CATEGORY', 'catid', 4);
INSERT INTO `molajo_component_options` VALUES(110, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_CONTENT_TYPE', 'content_type_id', 5);
INSERT INTO `molajo_component_options` VALUES(111, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_CREATE_DATE', 'created', 6);
INSERT INTO `molajo_component_options` VALUES(112, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_FEATURED', 'featured', 7);
INSERT INTO `molajo_component_options` VALUES(113, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_LANGUAGE', 'language', 9);
INSERT INTO `molajo_component_options` VALUES(114, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_UPDATE_DATE', 'modified', 10);
INSERT INTO `molajo_component_options` VALUES(115, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_PUBLISH_DATE', 'start_publishing_datetime', 11);
INSERT INTO `molajo_component_options` VALUES(116, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_STATE', 'state', 12);
INSERT INTO `molajo_component_options` VALUES(117, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_STICKIED', 'stickied', 13);
INSERT INTO `molajo_component_options` VALUES(118, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_TITLE', 'title', 14);
INSERT INTO `molajo_component_options` VALUES(119, 1, 0, 330, 'MOLAJO_CONFIG_MANAGER_OPTION_FILTER_SUBTITLE', 'subtitle', 15);
INSERT INTO `molajo_component_options` VALUES(120, 1, 0, 340, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(121, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_ARTICLE', 'article', 1);
INSERT INTO `molajo_component_options` VALUES(122, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_AUDIO', 'audio', 2);
INSERT INTO `molajo_component_options` VALUES(123, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_FILE', 'file', 3);
INSERT INTO `molajo_component_options` VALUES(124, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_GALLERY', 'gallery', 4);
INSERT INTO `molajo_component_options` VALUES(125, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_IMAGE', 'image', 5);
INSERT INTO `molajo_component_options` VALUES(126, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_PAGEBREAK', 'pagebreak', 6);
INSERT INTO `molajo_component_options` VALUES(127, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_READMORE', 'readmore', 7);
INSERT INTO `molajo_component_options` VALUES(128, 1, 0, 340, 'MOLAJO_CONFIG_MANAGER_EDITOR_BUTTON_VIDEO', 'video', 8);
INSERT INTO `molajo_component_options` VALUES(129, 1, 0, 400, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(130, 1, 0, 400, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 1);
INSERT INTO `molajo_component_options` VALUES(131, 1, 0, 400, 'sp-midi', 'sp-midi', 2);
INSERT INTO `molajo_component_options` VALUES(132, 1, 0, 400, 'vnd.3gpp.iufp', 'vnd.3gpp.iufp', 3);
INSERT INTO `molajo_component_options` VALUES(133, 1, 0, 400, 'vnd.4SB', 'vnd.4SB', 4);
INSERT INTO `molajo_component_options` VALUES(134, 1, 0, 400, 'vnd.CELP', 'vnd.CELP', 5);
INSERT INTO `molajo_component_options` VALUES(135, 1, 0, 400, 'vnd.audiokoz', 'vnd.audiokoz', 6);
INSERT INTO `molajo_component_options` VALUES(136, 1, 0, 400, 'vnd.cisco.nse', 'vnd.cisco.nse', 7);
INSERT INTO `molajo_component_options` VALUES(137, 1, 0, 400, 'vnd.cmles.radio-events', 'vnd.cmles.radio-events', 8);
INSERT INTO `molajo_component_options` VALUES(138, 1, 0, 400, 'vnd.cns.anp1', 'vnd.cns.anp1', 9);
INSERT INTO `molajo_component_options` VALUES(139, 1, 0, 400, 'vnd.cns.inf1', 'vnd.cns.inf1', 10);
INSERT INTO `molajo_component_options` VALUES(140, 1, 0, 400, 'vnd.dece.audio', 'vnd.dece.audio', 11);
INSERT INTO `molajo_component_options` VALUES(141, 1, 0, 400, 'vnd.digital-winds', 'vnd.digital-winds', 12);
INSERT INTO `molajo_component_options` VALUES(142, 1, 0, 400, 'vnd.dlna.adts', 'vnd.dlna.adts', 13);
INSERT INTO `molajo_component_options` VALUES(143, 1, 0, 400, 'vnd.dolby.heaac.1', 'vnd.dolby.heaac.1', 14);
INSERT INTO `molajo_component_options` VALUES(144, 1, 0, 400, 'vnd.dolby.heaac.2', 'vnd.dolby.heaac.2', 15);
INSERT INTO `molajo_component_options` VALUES(145, 1, 0, 400, 'vnd.dolby.mlp', 'vnd.dolby.mlp', 16);
INSERT INTO `molajo_component_options` VALUES(146, 1, 0, 400, 'vnd.dolby.mps', 'vnd.dolby.mps', 17);
INSERT INTO `molajo_component_options` VALUES(147, 1, 0, 400, 'vnd.dolby.pl2', 'vnd.dolby.pl2', 18);
INSERT INTO `molajo_component_options` VALUES(148, 1, 0, 400, 'vnd.dolby.pl2x', 'vnd.dolby.pl2x', 19);
INSERT INTO `molajo_component_options` VALUES(149, 1, 0, 400, 'vnd.dolby.pl2z', 'vnd.dolby.pl2z', 20);
INSERT INTO `molajo_component_options` VALUES(150, 1, 0, 400, 'vnd.dolby.pulse.1', 'vnd.dolby.pulse.1', 21);
INSERT INTO `molajo_component_options` VALUES(151, 1, 0, 400, 'vnd.dra', 'vnd.dra', 22);
INSERT INTO `molajo_component_options` VALUES(152, 1, 0, 400, 'vnd.dts', 'vnd.dts', 23);
INSERT INTO `molajo_component_options` VALUES(153, 1, 0, 400, 'vnd.dts.hd', 'vnd.dts.hd', 24);
INSERT INTO `molajo_component_options` VALUES(154, 1, 0, 400, 'vnd.dvb.file', 'vnd.dvb.file', 25);
INSERT INTO `molajo_component_options` VALUES(155, 1, 0, 400, 'vnd.everad.plj', 'vnd.everad.plj', 26);
INSERT INTO `molajo_component_options` VALUES(156, 1, 0, 400, 'vnd.hns.audio', 'vnd.hns.audio', 27);
INSERT INTO `molajo_component_options` VALUES(157, 1, 0, 400, 'vnd.lucent.voice', 'vnd.lucent.voice', 28);
INSERT INTO `molajo_component_options` VALUES(158, 1, 0, 400, 'vnd.ms-playready.media.pya', 'vnd.ms-playready.media.pya', 29);
INSERT INTO `molajo_component_options` VALUES(159, 1, 0, 400, 'vnd.nokia.mobile-xmf', 'vnd.nokia.mobile-xmf', 30);
INSERT INTO `molajo_component_options` VALUES(160, 1, 0, 400, 'vnd.nortel.vbk', 'vnd.nortel.vbk', 31);
INSERT INTO `molajo_component_options` VALUES(161, 1, 0, 400, 'vnd.nuera.ecelp4800', 'vnd.nuera.ecelp4800', 32);
INSERT INTO `molajo_component_options` VALUES(162, 1, 0, 400, 'vnd.nuera.ecelp7470', 'vnd.nuera.ecelp7470', 33);
INSERT INTO `molajo_component_options` VALUES(163, 1, 0, 400, 'vnd.nuera.ecelp9600', 'vnd.nuera.ecelp9600', 34);
INSERT INTO `molajo_component_options` VALUES(164, 1, 0, 400, 'vnd.octel.sbc', 'vnd.octel.sbc', 35);
INSERT INTO `molajo_component_options` VALUES(165, 1, 0, 400, 'vnd.qcelp', 'vnd.qcelp', 36);
INSERT INTO `molajo_component_options` VALUES(166, 1, 0, 400, 'vnd.rhetorex.32kadpcm', 'vnd.rhetorex.32kadpcm', 37);
INSERT INTO `molajo_component_options` VALUES(167, 1, 0, 400, 'vnd.rip', 'vnd.rip', 38);
INSERT INTO `molajo_component_options` VALUES(168, 1, 0, 400, 'vnd.sealedmedia.softseal-mpeg', 'vnd.sealedmedia.softseal-mpeg', 39);
INSERT INTO `molajo_component_options` VALUES(169, 1, 0, 400, 'vnd.vmx.cvsd', 'vnd.vmx.cvsd', 40);
INSERT INTO `molajo_component_options` VALUES(170, 1, 0, 410, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(171, 1, 0, 410, 'cgm', 'cgm', 1);
INSERT INTO `molajo_component_options` VALUES(172, 1, 0, 410, 'jp2', 'jp2', 2);
INSERT INTO `molajo_component_options` VALUES(173, 1, 0, 410, 'jpm', 'jpm', 3);
INSERT INTO `molajo_component_options` VALUES(174, 1, 0, 410, 'jpx', 'jpx', 4);
INSERT INTO `molajo_component_options` VALUES(175, 1, 0, 410, 'naplps', 'naplps', 5);
INSERT INTO `molajo_component_options` VALUES(176, 1, 0, 410, 'png', 'png', 6);
INSERT INTO `molajo_component_options` VALUES(177, 1, 0, 410, 'prs.btif', 'prs.btif', 7);
INSERT INTO `molajo_component_options` VALUES(178, 1, 0, 410, 'prs.pti', 'prs.pti', 8);
INSERT INTO `molajo_component_options` VALUES(179, 1, 0, 410, 'vnd-djvu', 'vnd-djvu', 9);
INSERT INTO `molajo_component_options` VALUES(180, 1, 0, 410, 'vnd-svf', 'vnd-svf', 10);
INSERT INTO `molajo_component_options` VALUES(181, 1, 0, 410, 'vnd-wap-wbmp', 'vnd-wap-wbmp', 11);
INSERT INTO `molajo_component_options` VALUES(182, 1, 0, 410, 'vnd.adobe.photoshop', 'vnd.adobe.photoshop', 12);
INSERT INTO `molajo_component_options` VALUES(183, 1, 0, 410, 'vnd.cns.inf2', 'vnd.cns.inf2', 13);
INSERT INTO `molajo_component_options` VALUES(184, 1, 0, 410, 'vnd.dece.graphic', 'vnd.dece.graphic', 14);
INSERT INTO `molajo_component_options` VALUES(185, 1, 0, 410, 'vnd.dvb.subtitle', 'vnd.dvb.subtitle', 15);
INSERT INTO `molajo_component_options` VALUES(186, 1, 0, 410, 'vnd.dwg', 'vnd.dwg', 16);
INSERT INTO `molajo_component_options` VALUES(187, 1, 0, 410, 'vnd.dxf', 'vnd.dxf', 17);
INSERT INTO `molajo_component_options` VALUES(188, 1, 0, 410, 'vnd.fastbidsheet', 'vnd.fastbidsheet', 18);
INSERT INTO `molajo_component_options` VALUES(189, 1, 0, 410, 'vnd.fpx', 'vnd.fpx', 19);
INSERT INTO `molajo_component_options` VALUES(190, 1, 0, 410, 'vnd.fst', 'vnd.fst', 20);
INSERT INTO `molajo_component_options` VALUES(191, 1, 0, 410, 'vnd.fujixerox.edmics-mmr', 'vnd.fujixerox.edmics-mmr', 21);
INSERT INTO `molajo_component_options` VALUES(192, 1, 0, 410, 'vnd.fujixerox.edmics-rlc', 'vnd.fujixerox.edmics-rlc', 22);
INSERT INTO `molajo_component_options` VALUES(193, 1, 0, 410, 'vnd.globalgraphics.pgb', 'vnd.globalgraphics.pgb', 23);
INSERT INTO `molajo_component_options` VALUES(194, 1, 0, 410, 'vnd.microsoft.icon', 'vnd.microsoft.icon', 24);
INSERT INTO `molajo_component_options` VALUES(195, 1, 0, 410, 'vnd.mix', 'vnd.mix', 25);
INSERT INTO `molajo_component_options` VALUES(196, 1, 0, 410, 'vnd.ms-modi', 'vnd.ms-modi', 26);
INSERT INTO `molajo_component_options` VALUES(197, 1, 0, 410, 'vnd.net-fpx', 'vnd.net-fpx', 27);
INSERT INTO `molajo_component_options` VALUES(198, 1, 0, 410, 'vnd.radiance', 'vnd.radiance', 28);
INSERT INTO `molajo_component_options` VALUES(199, 1, 0, 410, 'vnd.sealed-png', 'vnd.sealed-png', 29);
INSERT INTO `molajo_component_options` VALUES(200, 1, 0, 410, 'vnd.sealedmedia.softseal-gif', 'vnd.sealedmedia.softseal-gif', 30);
INSERT INTO `molajo_component_options` VALUES(201, 1, 0, 410, 'vnd.sealedmedia.softseal-jpg', 'vnd.sealedmedia.softseal-jpg', 31);
INSERT INTO `molajo_component_options` VALUES(202, 1, 0, 410, 'vnd.xiff', 'vnd.xiff', 32);
INSERT INTO `molajo_component_options` VALUES(203, 1, 0, 420, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(204, 1, 0, 420, 'n3', 'n3', 1);
INSERT INTO `molajo_component_options` VALUES(205, 1, 0, 420, 'prs.fallenstein.rst', 'prs.fallenstein.rst', 2);
INSERT INTO `molajo_component_options` VALUES(206, 1, 0, 420, 'prs.lines.tag', 'prs.lines.tag', 3);
INSERT INTO `molajo_component_options` VALUES(207, 1, 0, 420, 'rtf', 'rtf', 4);
INSERT INTO `molajo_component_options` VALUES(208, 1, 0, 420, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 5);
INSERT INTO `molajo_component_options` VALUES(209, 1, 0, 420, 'tab-separated-values', 'tab-separated-values', 6);
INSERT INTO `molajo_component_options` VALUES(210, 1, 0, 420, 'turtle', 'turtle', 7);
INSERT INTO `molajo_component_options` VALUES(211, 1, 0, 420, 'vnd-curl', 'vnd-curl', 8);
INSERT INTO `molajo_component_options` VALUES(212, 1, 0, 420, 'vnd.DMClientScript', 'vnd.DMClientScript', 9);
INSERT INTO `molajo_component_options` VALUES(213, 1, 0, 420, 'vnd.IPTC.NITF', 'vnd.IPTC.NITF', 10);
INSERT INTO `molajo_component_options` VALUES(214, 1, 0, 420, 'vnd.IPTC.NewsML', 'vnd.IPTC.NewsML', 11);
INSERT INTO `molajo_component_options` VALUES(215, 1, 0, 420, 'vnd.abc', 'vnd.abc', 12);
INSERT INTO `molajo_component_options` VALUES(216, 1, 0, 420, 'vnd.curl', 'vnd.curl', 13);
INSERT INTO `molajo_component_options` VALUES(217, 1, 0, 420, 'vnd.dvb.subtitle', 'vnd.dvb.subtitle', 14);
INSERT INTO `molajo_component_options` VALUES(218, 1, 0, 420, 'vnd.esmertec.theme-descriptor', 'vnd.esmertec.theme-descriptor', 15);
INSERT INTO `molajo_component_options` VALUES(219, 1, 0, 420, 'vnd.fly', 'vnd.fly', 16);
INSERT INTO `molajo_component_options` VALUES(220, 1, 0, 420, 'vnd.fmi.flexstor', 'vnd.fmi.flexstor', 17);
INSERT INTO `molajo_component_options` VALUES(221, 1, 0, 420, 'vnd.graphviz', 'vnd.graphviz', 18);
INSERT INTO `molajo_component_options` VALUES(222, 1, 0, 420, 'vnd.in3d.3dml', 'vnd.in3d.3dml', 19);
INSERT INTO `molajo_component_options` VALUES(223, 1, 0, 420, 'vnd.in3d.spot', 'vnd.in3d.spot', 20);
INSERT INTO `molajo_component_options` VALUES(224, 1, 0, 420, 'vnd.latex-z', 'vnd.latex-z', 21);
INSERT INTO `molajo_component_options` VALUES(225, 1, 0, 420, 'vnd.motorola.reflex', 'vnd.motorola.reflex', 22);
INSERT INTO `molajo_component_options` VALUES(226, 1, 0, 420, 'vnd.ms-mediapackage', 'vnd.ms-mediapackage', 23);
INSERT INTO `molajo_component_options` VALUES(227, 1, 0, 420, 'vnd.net2phone.commcenter.command', 'vnd.net2phone.commcenter.command', 24);
INSERT INTO `molajo_component_options` VALUES(228, 1, 0, 420, 'vnd.si.uricatalogue', 'vnd.si.uricatalogue', 25);
INSERT INTO `molajo_component_options` VALUES(229, 1, 0, 420, 'vnd.sun.j2me.app-descriptor', 'vnd.sun.j2me.app-descriptor', 26);
INSERT INTO `molajo_component_options` VALUES(230, 1, 0, 420, 'vnd.trolltech.linguist', 'vnd.trolltech.linguist', 27);
INSERT INTO `molajo_component_options` VALUES(231, 1, 0, 420, 'vnd.wap-wml', 'vnd.wap-wml', 28);
INSERT INTO `molajo_component_options` VALUES(232, 1, 0, 420, 'vnd.wap.si', 'vnd.wap.si', 29);
INSERT INTO `molajo_component_options` VALUES(233, 1, 0, 420, 'vnd.wap.wmlscript', 'vnd.wap.wmlscript', 30);
INSERT INTO `molajo_component_options` VALUES(234, 1, 0, 430, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(235, 1, 0, 430, 'jpm', 'jpm', 1);
INSERT INTO `molajo_component_options` VALUES(236, 1, 0, 430, 'mj2', 'mj2', 2);
INSERT INTO `molajo_component_options` VALUES(237, 1, 0, 430, 'quicktime', 'quicktime', 3);
INSERT INTO `molajo_component_options` VALUES(238, 1, 0, 430, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 4);
INSERT INTO `molajo_component_options` VALUES(239, 1, 0, 430, 'vnd-mpegurl', 'vnd-mpegurl', 5);
INSERT INTO `molajo_component_options` VALUES(240, 1, 0, 430, 'vnd-vivo', 'vnd-vivo', 6);
INSERT INTO `molajo_component_options` VALUES(241, 1, 0, 430, 'vnd.CCTV', 'vnd.CCTV', 7);
INSERT INTO `molajo_component_options` VALUES(242, 1, 0, 430, 'vnd.dece-mp4', 'vnd.dece-mp4', 8);
INSERT INTO `molajo_component_options` VALUES(243, 1, 0, 430, 'vnd.dece.hd', 'vnd.dece.hd', 9);
INSERT INTO `molajo_component_options` VALUES(244, 1, 0, 430, 'vnd.dece.mobile', 'vnd.dece.mobile', 10);
INSERT INTO `molajo_component_options` VALUES(245, 1, 0, 430, 'vnd.dece.pd', 'vnd.dece.pd', 11);
INSERT INTO `molajo_component_options` VALUES(246, 1, 0, 430, 'vnd.dece.sd', 'vnd.dece.sd', 12);
INSERT INTO `molajo_component_options` VALUES(247, 1, 0, 430, 'vnd.dece.video', 'vnd.dece.video', 13);
INSERT INTO `molajo_component_options` VALUES(248, 1, 0, 430, 'vnd.directv-mpeg', 'vnd.directv-mpeg', 14);
INSERT INTO `molajo_component_options` VALUES(249, 1, 0, 430, 'vnd.directv.mpeg-tts', 'vnd.directv.mpeg-tts', 15);
INSERT INTO `molajo_component_options` VALUES(250, 1, 0, 430, 'vnd.dvb.file', 'vnd.dvb.file', 16);
INSERT INTO `molajo_component_options` VALUES(251, 1, 0, 430, 'vnd.fvt', 'vnd.fvt', 17);
INSERT INTO `molajo_component_options` VALUES(252, 1, 0, 430, 'vnd.hns.video', 'vnd.hns.video', 18);
INSERT INTO `molajo_component_options` VALUES(253, 1, 0, 430, 'vnd.iptvforum.1dparityfec-1010', 'vnd.iptvforum.1dparityfec-1010', 19);
INSERT INTO `molajo_component_options` VALUES(254, 1, 0, 430, 'vnd.iptvforum.1dparityfec-2005', 'vnd.iptvforum.1dparityfec-2005', 20);
INSERT INTO `molajo_component_options` VALUES(255, 1, 0, 430, 'vnd.iptvforum.2dparityfec-1010', 'vnd.iptvforum.2dparityfec-1010', 21);
INSERT INTO `molajo_component_options` VALUES(256, 1, 0, 430, 'vnd.iptvforum.2dparityfec-2005', 'vnd.iptvforum.2dparityfec-2005', 22);
INSERT INTO `molajo_component_options` VALUES(257, 1, 0, 430, 'vnd.iptvforum.ttsavc', 'vnd.iptvforum.ttsavc', 23);
INSERT INTO `molajo_component_options` VALUES(258, 1, 0, 430, 'vnd.iptvforum.ttsmpeg2', 'vnd.iptvforum.ttsmpeg2', 24);
INSERT INTO `molajo_component_options` VALUES(259, 1, 0, 430, 'vnd.motorola.video', 'vnd.motorola.video', 25);
INSERT INTO `molajo_component_options` VALUES(260, 1, 0, 430, 'vnd.motorola.videop', 'vnd.motorola.videop', 26);
INSERT INTO `molajo_component_options` VALUES(261, 1, 0, 430, 'vnd.mpegurl', 'vnd.mpegurl', 27);
INSERT INTO `molajo_component_options` VALUES(262, 1, 0, 430, 'vnd.ms-playready.media.pyv', 'vnd.ms-playready.media.pyv', 28);
INSERT INTO `molajo_component_options` VALUES(263, 1, 0, 430, 'vnd.nokia.interleaved-multimedia', 'vnd.nokia.interleaved-multimedia', 29);
INSERT INTO `molajo_component_options` VALUES(264, 1, 0, 430, 'vnd.nokia.videovoip', 'vnd.nokia.videovoip', 30);
INSERT INTO `molajo_component_options` VALUES(265, 1, 0, 430, 'vnd.objectvideo', 'vnd.objectvideo', 31);
INSERT INTO `molajo_component_options` VALUES(266, 1, 0, 430, 'vnd.sealed-swf', 'vnd.sealed-swf', 32);
INSERT INTO `molajo_component_options` VALUES(267, 1, 0, 430, 'vnd.sealed.mpeg1', 'vnd.sealed.mpeg1', 33);
INSERT INTO `molajo_component_options` VALUES(268, 1, 0, 430, 'vnd.sealed.mpeg4', 'vnd.sealed.mpeg4', 34);
INSERT INTO `molajo_component_options` VALUES(269, 1, 0, 430, 'vnd.sealed.swf', 'vnd.sealed.swf', 35);
INSERT INTO `molajo_component_options` VALUES(270, 1, 0, 430, 'vnd.sealedmedia.softseal-mov', 'vnd.sealedmedia.softseal-mov', 36);
INSERT INTO `molajo_component_options` VALUES(271, 1, 0, 430, 'vnd.uvvu.mp4', 'vnd.uvvu.mp4', 37);
INSERT INTO `molajo_component_options` VALUES(272, 1, 0, 1100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(273, 1, 0, 1100, 'display', 'add', 1);
INSERT INTO `molajo_component_options` VALUES(274, 1, 0, 1100, 'display', 'edit', 2);
INSERT INTO `molajo_component_options` VALUES(275, 1, 0, 1100, 'display', 'display', 3);
INSERT INTO `molajo_component_options` VALUES(276, 1, 0, 1100, 'edit', 'apply', 4);
INSERT INTO `molajo_component_options` VALUES(277, 1, 0, 1100, 'edit', 'cancel', 5);
INSERT INTO `molajo_component_options` VALUES(278, 1, 0, 1100, 'edit', 'create', 6);
INSERT INTO `molajo_component_options` VALUES(279, 1, 0, 1100, 'edit', 'save', 7);
INSERT INTO `molajo_component_options` VALUES(280, 1, 0, 1100, 'edit', 'save2copy', 8);
INSERT INTO `molajo_component_options` VALUES(281, 1, 0, 1100, 'edit', 'save2new', 9);
INSERT INTO `molajo_component_options` VALUES(282, 1, 0, 1100, 'edit', 'restore', 10);
INSERT INTO `molajo_component_options` VALUES(283, 1, 0, 1100, 'multiple', 'archive', 11);
INSERT INTO `molajo_component_options` VALUES(284, 1, 0, 1100, 'multiple', 'publish', 12);
INSERT INTO `molajo_component_options` VALUES(285, 1, 0, 1100, 'multiple', 'unpublish', 13);
INSERT INTO `molajo_component_options` VALUES(286, 1, 0, 1100, 'multiple', 'spam', 14);
INSERT INTO `molajo_component_options` VALUES(287, 1, 0, 1100, 'multiple', 'trash', 15);
INSERT INTO `molajo_component_options` VALUES(288, 1, 0, 1100, 'multiple', 'feature', 16);
INSERT INTO `molajo_component_options` VALUES(289, 1, 0, 1100, 'multiple', 'unfeature', 17);
INSERT INTO `molajo_component_options` VALUES(290, 1, 0, 1100, 'multiple', 'sticky', 18);
INSERT INTO `molajo_component_options` VALUES(291, 1, 0, 1100, 'multiple', 'unsticky', 19);
INSERT INTO `molajo_component_options` VALUES(292, 1, 0, 1100, 'multiple', 'checkin', 20);
INSERT INTO `molajo_component_options` VALUES(293, 1, 0, 1100, 'multiple', 'reorder', 21);
INSERT INTO `molajo_component_options` VALUES(294, 1, 0, 1100, 'multiple', 'orderup', 22);
INSERT INTO `molajo_component_options` VALUES(295, 1, 0, 1100, 'multiple', 'orderdown', 23);
INSERT INTO `molajo_component_options` VALUES(296, 1, 0, 1100, 'multiple', 'saveorder', 24);
INSERT INTO `molajo_component_options` VALUES(297, 1, 0, 1100, 'multiple', 'delete', 25);
INSERT INTO `molajo_component_options` VALUES(298, 1, 0, 1100, 'multiple', 'copy', 26);
INSERT INTO `molajo_component_options` VALUES(299, 1, 0, 1100, 'multiple', 'move', 27);
INSERT INTO `molajo_component_options` VALUES(300, 1, 0, 1100, 'login', 'login', 28);
INSERT INTO `molajo_component_options` VALUES(301, 1, 0, 1100, 'logout', 'logout', 29);
INSERT INTO `molajo_component_options` VALUES(302, 1, 0, 1101, 'edit', 'apply', 4);
INSERT INTO `molajo_component_options` VALUES(303, 1, 0, 1101, 'edit', 'cancel', 5);
INSERT INTO `molajo_component_options` VALUES(304, 1, 0, 1101, 'edit', 'create', 6);
INSERT INTO `molajo_component_options` VALUES(305, 1, 0, 1101, 'edit', 'save', 7);
INSERT INTO `molajo_component_options` VALUES(306, 1, 0, 1101, 'edit', 'save2copy', 8);
INSERT INTO `molajo_component_options` VALUES(307, 1, 0, 1101, 'edit', 'save2new', 9);
INSERT INTO `molajo_component_options` VALUES(308, 1, 0, 1101, 'edit', 'restore', 10);
INSERT INTO `molajo_component_options` VALUES(309, 1, 0, 1101, 'multiple', 'archive', 11);
INSERT INTO `molajo_component_options` VALUES(310, 1, 0, 1101, 'multiple', 'publish', 12);
INSERT INTO `molajo_component_options` VALUES(311, 1, 0, 1101, 'multiple', 'unpublish', 13);
INSERT INTO `molajo_component_options` VALUES(312, 1, 0, 1101, 'multiple', 'spam', 14);
INSERT INTO `molajo_component_options` VALUES(313, 1, 0, 1101, 'multiple', 'trash', 15);
INSERT INTO `molajo_component_options` VALUES(314, 1, 0, 1101, 'multiple', 'feature', 16);
INSERT INTO `molajo_component_options` VALUES(315, 1, 0, 1101, 'multiple', 'unfeature', 17);
INSERT INTO `molajo_component_options` VALUES(316, 1, 0, 1101, 'multiple', 'sticky', 18);
INSERT INTO `molajo_component_options` VALUES(317, 1, 0, 1101, 'multiple', 'unsticky', 19);
INSERT INTO `molajo_component_options` VALUES(318, 1, 0, 1101, 'multiple', 'checkin', 20);
INSERT INTO `molajo_component_options` VALUES(319, 1, 0, 1101, 'multiple', 'reorder', 21);
INSERT INTO `molajo_component_options` VALUES(320, 1, 0, 1101, 'multiple', 'orderup', 22);
INSERT INTO `molajo_component_options` VALUES(321, 1, 0, 1101, 'multiple', 'orderdown', 23);
INSERT INTO `molajo_component_options` VALUES(322, 1, 0, 1101, 'multiple', 'saveorder', 24);
INSERT INTO `molajo_component_options` VALUES(323, 1, 0, 1101, 'multiple', 'delete', 25);
INSERT INTO `molajo_component_options` VALUES(324, 1, 0, 1101, 'multiple', 'copy', 26);
INSERT INTO `molajo_component_options` VALUES(325, 1, 0, 1101, 'multiple', 'move', 27);
INSERT INTO `molajo_component_options` VALUES(326, 1, 0, 1101, 'login', 'login', 28);
INSERT INTO `molajo_component_options` VALUES(327, 1, 0, 1101, 'login', 'logout', 29);
INSERT INTO `molajo_component_options` VALUES(328, 1, 0, 1800, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(329, 1, 0, 1800, '2552', '2552', 1);
INSERT INTO `molajo_component_options` VALUES(330, 1, 0, 1801, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(331, 1, 0, 1801, '2559', '2559', 1);
INSERT INTO `molajo_component_options` VALUES(332, 1, 0, 2000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(333, 1, 0, 2000, 'display', 'display', 1);
INSERT INTO `molajo_component_options` VALUES(334, 1, 0, 2000, 'edit', 'edit', 2);
INSERT INTO `molajo_component_options` VALUES(335, 1, 0, 2100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(336, 1, 0, 2100, 'display', 'display', 1);
INSERT INTO `molajo_component_options` VALUES(337, 1, 0, 3000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(338, 1, 0, 3000, 'default', 'default', 1);
INSERT INTO `molajo_component_options` VALUES(339, 1, 0, 3000, 'item', 'item', 1);
INSERT INTO `molajo_component_options` VALUES(340, 1, 0, 3000, 'items', 'items', 1);
INSERT INTO `molajo_component_options` VALUES(341, 1, 0, 3000, 'table', 'table', 1);
INSERT INTO `molajo_component_options` VALUES(342, 1, 0, 3100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(343, 1, 0, 3100, 'default', 'default', 1);
INSERT INTO `molajo_component_options` VALUES(344, 1, 0, 3200, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(345, 1, 0, 3200, 'default', 'default', 1);
INSERT INTO `molajo_component_options` VALUES(346, 1, 0, 3300, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(347, 1, 0, 3300, 'default', 'default', 1);
INSERT INTO `molajo_component_options` VALUES(348, 1, 0, 4000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(349, 1, 0, 4000, 'html', 'html', 1);
INSERT INTO `molajo_component_options` VALUES(350, 1, 0, 4100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(351, 1, 0, 4100, 'html', 'html', 1);
INSERT INTO `molajo_component_options` VALUES(352, 1, 0, 4200, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(353, 1, 0, 4200, 'error', 'error', 1);
INSERT INTO `molajo_component_options` VALUES(354, 1, 0, 4200, 'feed', 'feed', 2);
INSERT INTO `molajo_component_options` VALUES(355, 1, 0, 4200, 'html', 'html', 3);
INSERT INTO `molajo_component_options` VALUES(356, 1, 0, 4200, 'json', 'json', 4);
INSERT INTO `molajo_component_options` VALUES(357, 1, 0, 4200, 'opensearch', 'opensearch', 5);
INSERT INTO `molajo_component_options` VALUES(358, 1, 0, 4200, 'raw', 'raw', 6);
INSERT INTO `molajo_component_options` VALUES(359, 1, 0, 4200, 'xls', 'xls', 7);
INSERT INTO `molajo_component_options` VALUES(360, 1, 0, 4200, 'xml', 'xml', 8);
INSERT INTO `molajo_component_options` VALUES(361, 1, 0, 4200, 'xmlrpc', 'xmlrpc', 9);
INSERT INTO `molajo_component_options` VALUES(362, 1, 0, 4300, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(363, 1, 0, 4300, 'html', 'html', 1);
INSERT INTO `molajo_component_options` VALUES(364, 1, 0, 6000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(365, 1, 0, 6000, 'content', 'content', 1);
INSERT INTO `molajo_component_options` VALUES(366, 1, 0, 10000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(367, 1, 0, 10000, 'Core ACL Implementation', '1', 1);
INSERT INTO `molajo_component_options` VALUES(368, 1, 0, 10100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(369, 1, 0, 10100, 'view', 'view', 1);
INSERT INTO `molajo_component_options` VALUES(370, 1, 0, 10100, 'create', 'create', 2);
INSERT INTO `molajo_component_options` VALUES(371, 1, 0, 10100, 'edit', 'edit', 3);
INSERT INTO `molajo_component_options` VALUES(372, 1, 0, 10100, 'publish', 'publish', 4);
INSERT INTO `molajo_component_options` VALUES(373, 1, 0, 10100, 'delete', 'delete', 5);
INSERT INTO `molajo_component_options` VALUES(374, 1, 0, 10100, 'admin', 'admin', 6);
INSERT INTO `molajo_component_options` VALUES(375, 1, 0, 10200, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(376, 1, 0, 10200, 'create', 'add', 1);
INSERT INTO `molajo_component_options` VALUES(377, 1, 0, 10200, 'admin', 'admin', 2);
INSERT INTO `molajo_component_options` VALUES(378, 1, 0, 10200, 'edit', 'apply', 3);
INSERT INTO `molajo_component_options` VALUES(379, 1, 0, 10200, 'publish', 'archive', 4);
INSERT INTO `molajo_component_options` VALUES(380, 1, 0, 10200, '', 'cancel', 5);
INSERT INTO `molajo_component_options` VALUES(381, 1, 0, 10200, 'admin', 'checkin', 6);
INSERT INTO `molajo_component_options` VALUES(382, 1, 0, 10200, '', 'close', 7);
INSERT INTO `molajo_component_options` VALUES(383, 1, 0, 10200, 'create', 'copy', 8);
INSERT INTO `molajo_component_options` VALUES(384, 1, 0, 10200, 'create', 'create', 9);
INSERT INTO `molajo_component_options` VALUES(385, 1, 0, 10200, 'delete', 'delete', 10);
INSERT INTO `molajo_component_options` VALUES(386, 1, 0, 10200, 'view', 'view', 11);
INSERT INTO `molajo_component_options` VALUES(387, 1, 0, 10200, 'edit', 'edit', 12);
INSERT INTO `molajo_component_options` VALUES(388, 1, 0, 10200, 'publish', 'editstate', 13);
INSERT INTO `molajo_component_options` VALUES(389, 1, 0, 10200, 'publish', 'feature', 14);
INSERT INTO `molajo_component_options` VALUES(390, 1, 0, 10200, 'login', 'login', 15);
INSERT INTO `molajo_component_options` VALUES(391, 1, 0, 10200, 'logout', 'logout', 16);
INSERT INTO `molajo_component_options` VALUES(392, 1, 0, 10200, 'edit', 'manage', 17);
INSERT INTO `molajo_component_options` VALUES(393, 1, 0, 10200, 'edit', 'move', 18);
INSERT INTO `molajo_component_options` VALUES(394, 1, 0, 10200, 'publish', 'orderdown', 19);
INSERT INTO `molajo_component_options` VALUES(395, 1, 0, 10200, 'publish', 'orderup', 20);
INSERT INTO `molajo_component_options` VALUES(396, 1, 0, 10200, 'publish', 'publish', 21);
INSERT INTO `molajo_component_options` VALUES(397, 1, 0, 10200, 'publish', 'reorder', 22);
INSERT INTO `molajo_component_options` VALUES(398, 1, 0, 10200, 'publish', 'restore', 23);
INSERT INTO `molajo_component_options` VALUES(399, 1, 0, 10200, 'edit', 'save', 24);
INSERT INTO `molajo_component_options` VALUES(400, 1, 0, 10200, 'edit', 'save2copy', 25);
INSERT INTO `molajo_component_options` VALUES(401, 1, 0, 10200, 'edit', 'save2new', 26);
INSERT INTO `molajo_component_options` VALUES(402, 1, 0, 10200, 'publish', 'saveorder', 27);
INSERT INTO `molajo_component_options` VALUES(403, 1, 0, 10200, 'view', 'search', 28);
INSERT INTO `molajo_component_options` VALUES(404, 1, 0, 10200, 'publish', 'spam', 29);
INSERT INTO `molajo_component_options` VALUES(405, 1, 0, 10200, 'publish', 'state', 30);
INSERT INTO `molajo_component_options` VALUES(406, 1, 0, 10200, 'publish', 'sticky', 31);
INSERT INTO `molajo_component_options` VALUES(407, 1, 0, 10200, 'publish', 'trash', 32);
INSERT INTO `molajo_component_options` VALUES(408, 1, 0, 10200, 'publish', 'unfeature', 33);
INSERT INTO `molajo_component_options` VALUES(409, 1, 0, 10200, 'publish', 'unpublish', 34);
INSERT INTO `molajo_component_options` VALUES(410, 1, 0, 10200, 'publish', 'unsticky', 35);
INSERT INTO `molajo_component_options` VALUES(411, 13, 0, 100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(412, 13, 0, 100, '__dummy', '__dummy', 1);
INSERT INTO `molajo_component_options` VALUES(413, 13, 0, 1100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(414, 13, 0, 1100, 'display', 'display', 3);
INSERT INTO `molajo_component_options` VALUES(415, 13, 0, 1100, 'login', 'login', 28);
INSERT INTO `molajo_component_options` VALUES(416, 13, 0, 1100, 'login', 'logout', 29);
INSERT INTO `molajo_component_options` VALUES(417, 13, 0, 2000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(418, 13, 0, 2000, 'display', 'display', 1);
INSERT INTO `molajo_component_options` VALUES(419, 13, 0, 2100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(420, 13, 0, 2100, 'display', 'display', 1);
INSERT INTO `molajo_component_options` VALUES(421, 13, 0, 3000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(422, 13, 0, 3000, 'login', 'login', 1);
INSERT INTO `molajo_component_options` VALUES(423, 13, 0, 3100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(424, 13, 0, 3100, 'login', 'login', 1);
INSERT INTO `molajo_component_options` VALUES(425, 13, 0, 4000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(426, 13, 0, 4000, 'html', 'html', 1);
INSERT INTO `molajo_component_options` VALUES(427, 13, 0, 4001, 'html', 'html', 1);
INSERT INTO `molajo_component_options` VALUES(428, 13, 0, 6000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(429, 13, 0, 6000, 'user', 'user', 1);
INSERT INTO `molajo_component_options` VALUES(430, 13, 0, 10000, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(431, 13, 0, 10000, 'Core ACL Implementation', '1', 1);
INSERT INTO `molajo_component_options` VALUES(432, 13, 0, 10100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(433, 13, 0, 10100, 'view', 'view', 1);
INSERT INTO `molajo_component_options` VALUES(434, 13, 0, 10200, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(435, 13, 0, 10200, 'login', 'login', 15);
INSERT INTO `molajo_component_options` VALUES(436, 13, 0, 10200, 'logout', 'logout', 16);
INSERT INTO `molajo_component_options` VALUES(437, 2, 0, 100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(438, 2, 0, 100, '__content', '__content', 1);
INSERT INTO `molajo_component_options` VALUES(439, 8, 0, 100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(440, 8, 0, 100, '__dummy', '__dummy', 1);
INSERT INTO `molajo_component_options` VALUES(441, 8, 0, 3100, '', '', 0);
INSERT INTO `molajo_component_options` VALUES(442, 8, 0, 3100, 'admin_dashboard', 'admin_dashboard', 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_content`
--

CREATE TABLE `molajo_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `content_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext,
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `position` varchar(45) NOT NULL DEFAULT ' ',
  `metadata` mediumtext,
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_content_extension_instances2` (`extension_instance_id`),
  KEY `fk_content_content_type_ids2` (`content_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `molajo_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_content_types`
--

CREATE TABLE `molajo_content_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `content_type_id` varchar(255) NOT NULL DEFAULT '',
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `source_table` varchar(255) NOT NULL DEFAULT '',
  `component_option` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50001 ;

--
-- Dumping data for table `molajo_content_types`
--

INSERT INTO `molajo_content_types` VALUES(10, 'System', 1, '', '');
INSERT INTO `molajo_content_types` VALUES(15, 'Applications', 1, '__applications', 'com_applications');
INSERT INTO `molajo_content_types` VALUES(20, 'Dashboard', 1, '__dummy', 'com_dashboard');
INSERT INTO `molajo_content_types` VALUES(25, 'Maintain', 1, '__dummy', 'com_maintain');
INSERT INTO `molajo_content_types` VALUES(30, 'Installer', 1, '__dummy', 'com_installer');
INSERT INTO `molajo_content_types` VALUES(35, 'Search', 1, '__dummy', 'com_search');
INSERT INTO `molajo_content_types` VALUES(40, 'Language', 1, '__dummy', 'com_language');
INSERT INTO `molajo_content_types` VALUES(100, 'Group System', 1, '__groups', 'com_groups');
INSERT INTO `molajo_content_types` VALUES(110, 'Group Normal', 1, '__groups', 'com_groups');
INSERT INTO `molajo_content_types` VALUES(120, 'Group User', 1, '__groups', 'com_groups');
INSERT INTO `molajo_content_types` VALUES(500, 'Users', 1, '__users', 'com_users');
INSERT INTO `molajo_content_types` VALUES(1000, 'Extension Core', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1050, 'Extension Component', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1100, 'Extension Language', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1150, 'Extension Layout', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1200, 'Extension Library', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1250, 'Extension Manifest', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1300, 'Extension Menu', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1350, 'Extension Module', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1400, 'Extension Parameter', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1450, 'Extension Plugin', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(1500, 'Extension Template', 1, '__extension_instances', 'com_extensions');
INSERT INTO `molajo_content_types` VALUES(2000, 'Menu Item Component', 1, '__menu_items', 'com_menus');
INSERT INTO `molajo_content_types` VALUES(2100, 'Menu Item Link', 1, '__menu_items', 'com_menus');
INSERT INTO `molajo_content_types` VALUES(2200, 'Menu Item Module', 1, '__menu_items', 'com_menus');
INSERT INTO `molajo_content_types` VALUES(2300, 'Menu Item Separator', 1, '__menu_items', 'com_menus');
INSERT INTO `molajo_content_types` VALUES(3000, 'Category System', 1, '__categories', 'com_categories');
INSERT INTO `molajo_content_types` VALUES(3250, 'Category Content', 0, '__categories', 'com_categories');
INSERT INTO `molajo_content_types` VALUES(3500, 'Category Tags', 0, '__categories', 'com_categories');
INSERT INTO `molajo_content_types` VALUES(10000, 'Content Articles', 0, '__content', 'com_articles');
INSERT INTO `molajo_content_types` VALUES(20000, 'Content Contacts', 0, '__content', 'com_contacts');
INSERT INTO `molajo_content_types` VALUES(30000, 'Content Comments', 0, '__content', 'com_comments');
INSERT INTO `molajo_content_types` VALUES(40000, 'Content Media', 0, '__content', 'com_media');
INSERT INTO `molajo_content_types` VALUES(50000, 'Content Layouts', 0, '__content', 'com_layouts');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extensions`
--

CREATE TABLE `molajo_extensions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `update_site_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `folder` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `fk_extensions_extension_types2` (`content_type_id`),
  KEY `fk_extensions_update_sites2` (`update_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=167 ;

--
-- Dumping data for table `molajo_extensions`
--

INSERT INTO `molajo_extensions` VALUES(1, 10, 1, 'Core', '', '');
INSERT INTO `molajo_extensions` VALUES(2, 1050, 1, 'com_articles', '', '');
INSERT INTO `molajo_extensions` VALUES(3, 1050, 1, 'com_assets', '', '');
INSERT INTO `molajo_extensions` VALUES(4, 1050, 1, 'com_categories', '', '');
INSERT INTO `molajo_extensions` VALUES(5, 1050, 1, 'com_comments', '', '');
INSERT INTO `molajo_extensions` VALUES(6, 1050, 1, 'com_configuration', '', '');
INSERT INTO `molajo_extensions` VALUES(7, 1050, 1, 'com_contacts', '', '');
INSERT INTO `molajo_extensions` VALUES(8, 1050, 1, 'com_dashboard', '', '');
INSERT INTO `molajo_extensions` VALUES(9, 1050, 1, 'com_extensions', '', '');
INSERT INTO `molajo_extensions` VALUES(10, 1050, 1, 'com_groups', '', '');
INSERT INTO `molajo_extensions` VALUES(11, 1050, 1, 'com_installer', '', '');
INSERT INTO `molajo_extensions` VALUES(12, 1050, 1, 'com_layouts', '', '');
INSERT INTO `molajo_extensions` VALUES(13, 1050, 1, 'com_login', '', '');
INSERT INTO `molajo_extensions` VALUES(14, 1050, 1, 'com_maintain', '', '');
INSERT INTO `molajo_extensions` VALUES(15, 1050, 1, 'com_menus', '', '');
INSERT INTO `molajo_extensions` VALUES(16, 1050, 1, 'com_media', '', '');
INSERT INTO `molajo_extensions` VALUES(17, 1050, 1, 'com_profile', '', '');
INSERT INTO `molajo_extensions` VALUES(18, 1050, 1, 'com_search', '', '');
INSERT INTO `molajo_extensions` VALUES(19, 1050, 1, 'com_users', '', '');
INSERT INTO `molajo_extensions` VALUES(20, 40, 1, 'English (UK)', 'en-UK', '');
INSERT INTO `molajo_extensions` VALUES(21, 40, 1, 'English (US)', 'en-US', '');
INSERT INTO `molajo_extensions` VALUES(22, 1150, 1, 'head', '', 'document');
INSERT INTO `molajo_extensions` VALUES(23, 1150, 1, 'messages', '', 'document');
INSERT INTO `molajo_extensions` VALUES(24, 1150, 1, 'errors', '', 'document');
INSERT INTO `molajo_extensions` VALUES(25, 1150, 1, 'atom', '', 'document');
INSERT INTO `molajo_extensions` VALUES(26, 1150, 1, 'rss', '', 'document');
INSERT INTO `molajo_extensions` VALUES(27, 1150, 1, 'admin_acl_panel', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(28, 1150, 1, 'admin_activity', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(29, 1150, 1, 'admin_dashboard', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(30, 1150, 1, 'admin_edit', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(31, 1150, 1, 'admin_favorites', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(32, 1150, 1, 'admin_feed', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(33, 1150, 1, 'admin_footer', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(34, 1150, 1, 'admin_header', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(35, 1150, 1, 'admin_inbox', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(36, 1150, 1, 'admin_launchpad', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(37, 1150, 1, 'admin_list', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(38, 1150, 1, 'admin_login', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(39, 1150, 1, 'admin_modal', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(40, 1150, 1, 'admin_pagination', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(41, 1150, 1, 'admin_toolbar', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(42, 1150, 1, 'audio', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(43, 1150, 1, 'contact_form', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(44, 1150, 1, 'default', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(45, 1150, 1, 'dummy', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(46, 1150, 1, 'faq', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(47, 1150, 1, 'item', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(48, 1150, 1, 'list', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(49, 1150, 1, 'items', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(50, 1150, 1, 'list', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(51, 1150, 1, 'pagination', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(52, 1150, 1, 'social_bookmarks', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(53, 1150, 1, 'syntaxhighlighter', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(54, 1150, 1, 'table', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(55, 1150, 1, 'tree', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(56, 1150, 1, 'twig_example', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(57, 1150, 1, 'video', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(58, 1150, 1, 'button', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(59, 1150, 1, 'colorpicker', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(60, 1150, 1, 'datepicker', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(61, 1150, 1, 'list', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(62, 1150, 1, 'media', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(63, 1150, 1, 'number', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(64, 1150, 1, 'option', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(65, 1150, 1, 'rules', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(66, 1150, 1, 'spacer', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(67, 1150, 1, 'text', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(68, 1150, 1, 'textarea', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(69, 1150, 1, 'user', '', 'formfields');
INSERT INTO `molajo_extensions` VALUES(70, 1150, 1, 'article', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(71, 1150, 1, 'aside', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(72, 1150, 1, 'div', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(73, 1150, 1, 'footer', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(74, 1150, 1, 'header', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(75, 1150, 1, 'horizontal', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(76, 1150, 1, 'nav', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(77, 1150, 1, 'none', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(78, 1150, 1, 'outline', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(79, 1150, 1, 'section', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(80, 1150, 1, 'table', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(81, 1150, 1, 'tabs', '', 'wrap');
INSERT INTO `molajo_extensions` VALUES(82, 1200, 1, 'Doctrine', '', '');
INSERT INTO `molajo_extensions` VALUES(83, 1200, 1, 'includes', '', '');
INSERT INTO `molajo_extensions` VALUES(84, 1200, 1, 'jplatform', '', '');
INSERT INTO `molajo_extensions` VALUES(85, 1200, 1, 'molajo', '', '');
INSERT INTO `molajo_extensions` VALUES(86, 1200, 1, 'Twig', '', '');
INSERT INTO `molajo_extensions` VALUES(87, 1450, 1, 'example', '', 'acl');
INSERT INTO `molajo_extensions` VALUES(88, 1450, 1, 'molajo', '', 'authentication');
INSERT INTO `molajo_extensions` VALUES(89, 1450, 1, 'broadcast', '', 'content');
INSERT INTO `molajo_extensions` VALUES(90, 1450, 1, 'content', '', 'content');
INSERT INTO `molajo_extensions` VALUES(91, 1450, 1, 'emailcloak', '', 'content');
INSERT INTO `molajo_extensions` VALUES(92, 1450, 1, 'links', '', 'content');
INSERT INTO `molajo_extensions` VALUES(93, 1450, 1, 'loadmodule', '', 'content');
INSERT INTO `molajo_extensions` VALUES(94, 1450, 1, 'media', '', 'content');
INSERT INTO `molajo_extensions` VALUES(95, 1450, 1, 'protect', '', 'content');
INSERT INTO `molajo_extensions` VALUES(96, 1450, 1, 'responses', '', 'content');
INSERT INTO `molajo_extensions` VALUES(97, 1450, 1, 'aloha', '', 'editors');
INSERT INTO `molajo_extensions` VALUES(98, 1450, 1, 'none', '', 'editors');
INSERT INTO `molajo_extensions` VALUES(99, 1450, 1, 'article', '', 'editor-buttons');
INSERT INTO `molajo_extensions` VALUES(100, 1450, 1, 'editor', '', 'editor-buttons');
INSERT INTO `molajo_extensions` VALUES(101, 1450, 1, 'image', '', 'editor-buttons');
INSERT INTO `molajo_extensions` VALUES(102, 1450, 1, 'pagebreak', '', 'editor-buttons');
INSERT INTO `molajo_extensions` VALUES(103, 1450, 1, 'readmore', '', 'editor-buttons');
INSERT INTO `molajo_extensions` VALUES(104, 1450, 1, 'molajo', '', 'extension');
INSERT INTO `molajo_extensions` VALUES(105, 1450, 1, 'extend', '', 'molajo');
INSERT INTO `molajo_extensions` VALUES(106, 1450, 1, 'minifier', '', 'molajo');
INSERT INTO `molajo_extensions` VALUES(107, 1450, 1, 'search', '', 'molajo');
INSERT INTO `molajo_extensions` VALUES(108, 1450, 1, 'tags', '', 'molajo');
INSERT INTO `molajo_extensions` VALUES(109, 1450, 1, 'urls', '', 'molajo');
INSERT INTO `molajo_extensions` VALUES(110, 1450, 1, 'molajosample', '', 'query');
INSERT INTO `molajo_extensions` VALUES(111, 1450, 1, 'categories', '', 'search');
INSERT INTO `molajo_extensions` VALUES(112, 1450, 1, 'articles', '', 'search');
INSERT INTO `molajo_extensions` VALUES(113, 1450, 1, 'cache', '', 'system');
INSERT INTO `molajo_extensions` VALUES(114, 1450, 1, 'compress', '', 'system');
INSERT INTO `molajo_extensions` VALUES(115, 1450, 1, 'create', '', 'system');
INSERT INTO `molajo_extensions` VALUES(116, 1450, 1, 'debug', '', 'system');
INSERT INTO `molajo_extensions` VALUES(117, 1450, 1, 'languagefilter', '', 'system');
INSERT INTO `molajo_extensions` VALUES(118, 1450, 1, 'log', '', 'system');
INSERT INTO `molajo_extensions` VALUES(119, 1450, 1, 'logout', '', 'system');
INSERT INTO `molajo_extensions` VALUES(120, 1450, 1, 'molajo', '', 'system');
INSERT INTO `molajo_extensions` VALUES(121, 1450, 1, 'p3p', '', 'system');
INSERT INTO `molajo_extensions` VALUES(122, 1450, 1, 'parameters', '', 'system');
INSERT INTO `molajo_extensions` VALUES(123, 1450, 1, 'redirect', '', 'system');
INSERT INTO `molajo_extensions` VALUES(124, 1450, 1, 'remember', '', 'system');
INSERT INTO `molajo_extensions` VALUES(125, 1450, 1, 'system', '', 'system');
INSERT INTO `molajo_extensions` VALUES(126, 1450, 1, 'webservices', '', 'system');
INSERT INTO `molajo_extensions` VALUES(127, 1450, 1, 'molajo', '', 'user');
INSERT INTO `molajo_extensions` VALUES(128, 1450, 1, 'profile', '', 'user');
INSERT INTO `molajo_extensions` VALUES(129, 1500, 1, 'construct', '', '');
INSERT INTO `molajo_extensions` VALUES(130, 1500, 1, 'install', '', '');
INSERT INTO `molajo_extensions` VALUES(131, 1500, 1, 'molajito', '', '');
INSERT INTO `molajo_extensions` VALUES(132, 1500, 1, 'sample', '', '');
INSERT INTO `molajo_extensions` VALUES(133, 1500, 1, 'system', '', '');
INSERT INTO `molajo_extensions` VALUES(134, 1300, 1, 'Administrator Menu', '', '');
INSERT INTO `molajo_extensions` VALUES(135, 1300, 1, 'Main Menu', '', '');
INSERT INTO `molajo_extensions` VALUES(136, 1350, 1, 'mod_assetwidget', '', '');
INSERT INTO `molajo_extensions` VALUES(137, 1350, 1, 'mod_aclwidget', '', '');
INSERT INTO `molajo_extensions` VALUES(138, 1350, 1, 'mod_breadcrumbs', '', '');
INSERT INTO `molajo_extensions` VALUES(139, 1350, 1, 'mod_debug', '', '');
INSERT INTO `molajo_extensions` VALUES(140, 1350, 1, 'mod_categorywidget', '', '');
INSERT INTO `molajo_extensions` VALUES(141, 1350, 1, 'mod_content', '', '');
INSERT INTO `molajo_extensions` VALUES(142, 1350, 1, 'mod_custom', '', '');
INSERT INTO `molajo_extensions` VALUES(143, 1350, 1, 'mod_groupwidget', '', '');
INSERT INTO `molajo_extensions` VALUES(144, 1350, 1, 'mod_feed', '', '');
INSERT INTO `molajo_extensions` VALUES(145, 1350, 1, 'mod_filters', '', '');
INSERT INTO `molajo_extensions` VALUES(146, 1350, 1, 'mod_filebrowser', '', '');
INSERT INTO `molajo_extensions` VALUES(147, 1350, 1, 'mod_footer', '', '');
INSERT INTO `molajo_extensions` VALUES(148, 1350, 1, 'mod_gallery', '', '');
INSERT INTO `molajo_extensions` VALUES(149, 1350, 1, 'mod_grid', '', '');
INSERT INTO `molajo_extensions` VALUES(150, 1350, 1, 'mod_gridbatch', '', '');
INSERT INTO `molajo_extensions` VALUES(151, 1350, 1, 'mod_header', '', '');
INSERT INTO `molajo_extensions` VALUES(152, 1350, 1, 'mod_iconbutton', '', '');
INSERT INTO `molajo_extensions` VALUES(153, 1350, 1, 'mod_layout', '', '');
INSERT INTO `molajo_extensions` VALUES(154, 1350, 1, 'mod_login', '', '');
INSERT INTO `molajo_extensions` VALUES(155, 1350, 1, 'mod_logout', '', '');
INSERT INTO `molajo_extensions` VALUES(156, 1350, 1, 'mod_members', '', '');
INSERT INTO `molajo_extensions` VALUES(157, 1350, 1, 'mod_menu', '', '');
INSERT INTO `molajo_extensions` VALUES(158, 1350, 1, 'mod_pagination', '', '');
INSERT INTO `molajo_extensions` VALUES(159, 1350, 1, 'mod_plugins', '', '');
INSERT INTO `molajo_extensions` VALUES(160, 1350, 1, 'mod_quicklinks', '', '');
INSERT INTO `molajo_extensions` VALUES(161, 1350, 1, 'mod_search', '', '');
INSERT INTO `molajo_extensions` VALUES(162, 1350, 1, 'mod_submenu', '', '');
INSERT INTO `molajo_extensions` VALUES(163, 1350, 1, 'mod_syndicate', '', '');
INSERT INTO `molajo_extensions` VALUES(164, 1350, 1, 'mod_textbox', '', '');
INSERT INTO `molajo_extensions` VALUES(165, 1350, 1, 'mod_title', '', '');
INSERT INTO `molajo_extensions` VALUES(166, 1350, 1, 'mod_toolbar', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extension_instances`
--

CREATE TABLE `molajo_extension_instances` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_id` int(11) unsigned NOT NULL DEFAULT '0',
  `content_type_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext,
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `position` varchar(45) NOT NULL DEFAULT ' ',
  `metadata` mediumtext,
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_extension_instances_content_type_ids2` (`content_type_id`),
  KEY `fk_extension_instances_extensions2` (`extension_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=212 ;

--
-- Dumping data for table `molajo_extension_instances`
--

INSERT INTO `molajo_extension_instances` VALUES(1, 1, 10, 'Core', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instances` VALUES(2, 2, 1050, 'com_articles', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instances` VALUES(3, 3, 1050, 'com_assets', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instances` VALUES(4, 4, 1050, 'com_categories', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instances` VALUES(5, 5, 1050, 'com_comments', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instances` VALUES(6, 6, 1050, 'com_configuration', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instances` VALUES(7, 7, 1050, 'com_contacts', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instances` VALUES(8, 8, 1050, 'com_dashboard', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instances` VALUES(9, 9, 1050, 'com_extensions', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instances` VALUES(10, 10, 1050, 'com_groups', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instances` VALUES(11, 11, 1050, 'com_installer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instances` VALUES(12, 12, 1050, 'com_layouts', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instances` VALUES(13, 13, 1050, 'com_login', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instances` VALUES(14, 14, 1050, 'com_maintain', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instances` VALUES(15, 15, 1050, 'com_menus', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instances` VALUES(16, 16, 1050, 'com_media', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instances` VALUES(17, 17, 1050, 'com_profile', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instances` VALUES(18, 18, 1050, 'com_search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instances` VALUES(19, 19, 1050, 'com_users', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instances` VALUES(33, 20, 40, 'English (UK)', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instances` VALUES(34, 21, 40, 'English (US)', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instances` VALUES(36, 22, 1150, 'head', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instances` VALUES(37, 23, 1150, 'messages', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instances` VALUES(38, 24, 1150, 'errors', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instances` VALUES(39, 25, 1150, 'atom', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instances` VALUES(40, 26, 1150, 'rss', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instances` VALUES(41, 27, 1150, 'admin_acl_panel', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instances` VALUES(42, 28, 1150, 'admin_activity', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instances` VALUES(43, 29, 1150, 'admin_dashboard', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instances` VALUES(44, 30, 1150, 'admin_edit', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instances` VALUES(45, 31, 1150, 'admin_favorites', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instances` VALUES(46, 32, 1150, 'admin_feed', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instances` VALUES(47, 33, 1150, 'admin_footer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instances` VALUES(48, 34, 1150, 'admin_header', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 34);
INSERT INTO `molajo_extension_instances` VALUES(49, 35, 1150, 'admin_inbox', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 35);
INSERT INTO `molajo_extension_instances` VALUES(50, 36, 1150, 'admin_launchpad', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 36);
INSERT INTO `molajo_extension_instances` VALUES(51, 37, 1150, 'admin_list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 37);
INSERT INTO `molajo_extension_instances` VALUES(52, 38, 1150, 'admin_login', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 38);
INSERT INTO `molajo_extension_instances` VALUES(53, 39, 1150, 'admin_modal', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 39);
INSERT INTO `molajo_extension_instances` VALUES(54, 40, 1150, 'admin_pagination', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 40);
INSERT INTO `molajo_extension_instances` VALUES(55, 41, 1150, 'admin_toolbar', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 41);
INSERT INTO `molajo_extension_instances` VALUES(56, 42, 1150, 'audio', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 42);
INSERT INTO `molajo_extension_instances` VALUES(57, 43, 1150, 'contact_form', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 43);
INSERT INTO `molajo_extension_instances` VALUES(58, 44, 1150, 'default', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 44);
INSERT INTO `molajo_extension_instances` VALUES(59, 45, 1150, 'dummy', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 45);
INSERT INTO `molajo_extension_instances` VALUES(60, 46, 1150, 'faq', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 46);
INSERT INTO `molajo_extension_instances` VALUES(61, 47, 1150, 'item', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 47);
INSERT INTO `molajo_extension_instances` VALUES(62, 48, 1150, 'list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 48);
INSERT INTO `molajo_extension_instances` VALUES(63, 49, 1150, 'items', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 49);
INSERT INTO `molajo_extension_instances` VALUES(64, 50, 1150, 'list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 50);
INSERT INTO `molajo_extension_instances` VALUES(65, 51, 1150, 'pagination', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 51);
INSERT INTO `molajo_extension_instances` VALUES(66, 52, 1150, 'social_bookmarks', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 52);
INSERT INTO `molajo_extension_instances` VALUES(67, 53, 1150, 'syntaxhighlighter', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 53);
INSERT INTO `molajo_extension_instances` VALUES(68, 54, 1150, 'table', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 54);
INSERT INTO `molajo_extension_instances` VALUES(69, 55, 1150, 'tree', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 55);
INSERT INTO `molajo_extension_instances` VALUES(70, 56, 1150, 'twig_example', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 56);
INSERT INTO `molajo_extension_instances` VALUES(71, 57, 1150, 'video', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 57);
INSERT INTO `molajo_extension_instances` VALUES(72, 58, 1150, 'button', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 58);
INSERT INTO `molajo_extension_instances` VALUES(73, 59, 1150, 'colorpicker', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 59);
INSERT INTO `molajo_extension_instances` VALUES(74, 60, 1150, 'datepicker', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 60);
INSERT INTO `molajo_extension_instances` VALUES(75, 61, 1150, 'list', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 61);
INSERT INTO `molajo_extension_instances` VALUES(76, 62, 1150, 'media', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 62);
INSERT INTO `molajo_extension_instances` VALUES(77, 63, 1150, 'number', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 63);
INSERT INTO `molajo_extension_instances` VALUES(78, 64, 1150, 'option', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 64);
INSERT INTO `molajo_extension_instances` VALUES(79, 65, 1150, 'rules', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 65);
INSERT INTO `molajo_extension_instances` VALUES(80, 66, 1150, 'spacer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 66);
INSERT INTO `molajo_extension_instances` VALUES(81, 67, 1150, 'text', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 67);
INSERT INTO `molajo_extension_instances` VALUES(82, 68, 1150, 'textarea', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 68);
INSERT INTO `molajo_extension_instances` VALUES(83, 69, 1150, 'user', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 69);
INSERT INTO `molajo_extension_instances` VALUES(84, 70, 1150, 'article', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 70);
INSERT INTO `molajo_extension_instances` VALUES(85, 71, 1150, 'aside', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 71);
INSERT INTO `molajo_extension_instances` VALUES(86, 72, 1150, 'div', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 72);
INSERT INTO `molajo_extension_instances` VALUES(87, 73, 1150, 'footer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 73);
INSERT INTO `molajo_extension_instances` VALUES(88, 74, 1150, 'header', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 74);
INSERT INTO `molajo_extension_instances` VALUES(89, 75, 1150, 'horizontal', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 75);
INSERT INTO `molajo_extension_instances` VALUES(90, 76, 1150, 'nav', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 76);
INSERT INTO `molajo_extension_instances` VALUES(91, 77, 1150, 'none', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 77);
INSERT INTO `molajo_extension_instances` VALUES(92, 78, 1150, 'outline', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 78);
INSERT INTO `molajo_extension_instances` VALUES(93, 79, 1150, 'section', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 79);
INSERT INTO `molajo_extension_instances` VALUES(94, 80, 1150, 'table', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 80);
INSERT INTO `molajo_extension_instances` VALUES(95, 81, 1150, 'tabs', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 81);
INSERT INTO `molajo_extension_instances` VALUES(99, 82, 1200, 'Doctrine', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 82);
INSERT INTO `molajo_extension_instances` VALUES(100, 83, 1200, 'includes', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 83);
INSERT INTO `molajo_extension_instances` VALUES(101, 84, 1200, 'jplatform', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 84);
INSERT INTO `molajo_extension_instances` VALUES(102, 85, 1200, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 85);
INSERT INTO `molajo_extension_instances` VALUES(103, 86, 1200, 'Twig', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 86);
INSERT INTO `molajo_extension_instances` VALUES(106, 87, 1450, 'example', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 87);
INSERT INTO `molajo_extension_instances` VALUES(107, 88, 1450, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 88);
INSERT INTO `molajo_extension_instances` VALUES(108, 89, 1450, 'broadcast', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 89);
INSERT INTO `molajo_extension_instances` VALUES(109, 90, 1450, 'content', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 90);
INSERT INTO `molajo_extension_instances` VALUES(110, 91, 1450, 'emailcloak', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 91);
INSERT INTO `molajo_extension_instances` VALUES(111, 92, 1450, 'links', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 92);
INSERT INTO `molajo_extension_instances` VALUES(112, 93, 1450, 'loadmodule', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 93);
INSERT INTO `molajo_extension_instances` VALUES(113, 94, 1450, 'media', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 94);
INSERT INTO `molajo_extension_instances` VALUES(114, 95, 1450, 'protect', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 95);
INSERT INTO `molajo_extension_instances` VALUES(115, 96, 1450, 'responses', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 96);
INSERT INTO `molajo_extension_instances` VALUES(116, 97, 1450, 'aloha', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 97);
INSERT INTO `molajo_extension_instances` VALUES(117, 98, 1450, 'none', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 98);
INSERT INTO `molajo_extension_instances` VALUES(118, 99, 1450, 'article', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 99);
INSERT INTO `molajo_extension_instances` VALUES(119, 100, 1450, 'editor', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 100);
INSERT INTO `molajo_extension_instances` VALUES(120, 101, 1450, 'image', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 101);
INSERT INTO `molajo_extension_instances` VALUES(121, 102, 1450, 'pagebreak', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 102);
INSERT INTO `molajo_extension_instances` VALUES(122, 103, 1450, 'readmore', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 103);
INSERT INTO `molajo_extension_instances` VALUES(123, 104, 1450, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 104);
INSERT INTO `molajo_extension_instances` VALUES(124, 105, 1450, 'extend', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 105);
INSERT INTO `molajo_extension_instances` VALUES(125, 106, 1450, 'minifier', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 106);
INSERT INTO `molajo_extension_instances` VALUES(126, 107, 1450, 'search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 107);
INSERT INTO `molajo_extension_instances` VALUES(127, 108, 1450, 'tags', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 108);
INSERT INTO `molajo_extension_instances` VALUES(128, 109, 1450, 'urls', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 109);
INSERT INTO `molajo_extension_instances` VALUES(129, 110, 1450, 'molajosample', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 110);
INSERT INTO `molajo_extension_instances` VALUES(130, 111, 1450, 'categories', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 111);
INSERT INTO `molajo_extension_instances` VALUES(131, 112, 1450, 'articles', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 112);
INSERT INTO `molajo_extension_instances` VALUES(132, 113, 1450, 'cache', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 113);
INSERT INTO `molajo_extension_instances` VALUES(133, 114, 1450, 'compress', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 114);
INSERT INTO `molajo_extension_instances` VALUES(134, 115, 1450, 'create', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 115);
INSERT INTO `molajo_extension_instances` VALUES(135, 116, 1450, 'debug', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 116);
INSERT INTO `molajo_extension_instances` VALUES(136, 117, 1450, 'languagefilter', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 117);
INSERT INTO `molajo_extension_instances` VALUES(137, 118, 1450, 'log', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 118);
INSERT INTO `molajo_extension_instances` VALUES(138, 119, 1450, 'logout', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 119);
INSERT INTO `molajo_extension_instances` VALUES(139, 120, 1450, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 120);
INSERT INTO `molajo_extension_instances` VALUES(140, 121, 1450, 'p3p', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 121);
INSERT INTO `molajo_extension_instances` VALUES(141, 122, 1450, 'parameters', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 122);
INSERT INTO `molajo_extension_instances` VALUES(142, 123, 1450, 'redirect', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 123);
INSERT INTO `molajo_extension_instances` VALUES(143, 124, 1450, 'remember', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 124);
INSERT INTO `molajo_extension_instances` VALUES(144, 125, 1450, 'system', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 125);
INSERT INTO `molajo_extension_instances` VALUES(145, 126, 1450, 'webservices', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 126);
INSERT INTO `molajo_extension_instances` VALUES(146, 127, 1450, 'molajo', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 127);
INSERT INTO `molajo_extension_instances` VALUES(147, 128, 1450, 'profile', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 128);
INSERT INTO `molajo_extension_instances` VALUES(169, 129, 1500, 'construct', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 129);
INSERT INTO `molajo_extension_instances` VALUES(170, 130, 1500, 'install', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 130);
INSERT INTO `molajo_extension_instances` VALUES(171, 131, 1500, 'molajito', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 131);
INSERT INTO `molajo_extension_instances` VALUES(172, 132, 1500, 'sample', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 132);
INSERT INTO `molajo_extension_instances` VALUES(173, 133, 1500, 'system', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 133);
INSERT INTO `molajo_extension_instances` VALUES(176, 134, 1300, 'Administrator Menu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 134);
INSERT INTO `molajo_extension_instances` VALUES(177, 135, 1300, 'Main Menu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 135);
INSERT INTO `molajo_extension_instances` VALUES(179, 136, 1350, 'mod_assetwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'assetwidget', NULL, '{}', '{}', 'en-GB', 0, 136);
INSERT INTO `molajo_extension_instances` VALUES(180, 137, 1350, 'mod_aclwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'aclwidget', NULL, '{}', '{}', 'en-GB', 0, 137);
INSERT INTO `molajo_extension_instances` VALUES(181, 138, 1350, 'mod_breadcrumbs', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'breadcrumbs', NULL, '{}', '{}', 'en-GB', 0, 138);
INSERT INTO `molajo_extension_instances` VALUES(182, 139, 1350, 'mod_debug', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'debug', NULL, '{}', '{}', 'en-GB', 0, 139);
INSERT INTO `molajo_extension_instances` VALUES(183, 140, 1350, 'mod_categorywidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'categorywidget', NULL, '{}', '{}', 'en-GB', 0, 140);
INSERT INTO `molajo_extension_instances` VALUES(184, 141, 1350, 'mod_content', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'content', NULL, '{}', '{}', 'en-GB', 0, 141);
INSERT INTO `molajo_extension_instances` VALUES(185, 142, 1350, 'mod_custom', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'custom', NULL, '{}', '{}', 'en-GB', 0, 142);
INSERT INTO `molajo_extension_instances` VALUES(186, 143, 1350, 'mod_groupwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'groupwidget', NULL, '{}', '{}', 'en-GB', 0, 143);
INSERT INTO `molajo_extension_instances` VALUES(187, 144, 1350, 'mod_feed', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'feed', NULL, '{}', '{}', 'en-GB', 0, 144);
INSERT INTO `molajo_extension_instances` VALUES(188, 145, 1350, 'mod_filters', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'filters', NULL, '{}', '{}', 'en-GB', 0, 145);
INSERT INTO `molajo_extension_instances` VALUES(189, 146, 1350, 'mod_filebrowser', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'filebrowser', NULL, '{}', '{}', 'en-GB', 0, 146);
INSERT INTO `molajo_extension_instances` VALUES(190, 147, 1350, 'mod_footer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'footer', NULL, '{}', '{}', 'en-GB', 0, 147);
INSERT INTO `molajo_extension_instances` VALUES(191, 148, 1350, 'mod_gallery', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'gallery', NULL, '{}', '{}', 'en-GB', 0, 148);
INSERT INTO `molajo_extension_instances` VALUES(192, 149, 1350, 'mod_grid', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'grid', NULL, '{}', '{}', 'en-GB', 0, 149);
INSERT INTO `molajo_extension_instances` VALUES(193, 150, 1350, 'mod_gridbatch', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'gridbatch', NULL, '{}', '{}', 'en-GB', 0, 150);
INSERT INTO `molajo_extension_instances` VALUES(194, 151, 1350, 'mod_header', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'header', NULL, '{}', '{}', 'en-GB', 0, 151);
INSERT INTO `molajo_extension_instances` VALUES(195, 152, 1350, 'mod_iconbutton', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'iconbutton', NULL, '{}', '{}', 'en-GB', 0, 152);
INSERT INTO `molajo_extension_instances` VALUES(196, 153, 1350, 'mod_layout', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'layout', NULL, '{}', '{}', 'en-GB', 0, 153);
INSERT INTO `molajo_extension_instances` VALUES(197, 154, 1350, 'mod_login', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'login', NULL, '{}', '{}', 'en-GB', 0, 154);
INSERT INTO `molajo_extension_instances` VALUES(198, 155, 1350, 'mod_logout', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'logout', NULL, '{}', '{}', 'en-GB', 0, 155);
INSERT INTO `molajo_extension_instances` VALUES(199, 156, 1350, 'mod_members', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'members', NULL, '{}', '{}', 'en-GB', 0, 156);
INSERT INTO `molajo_extension_instances` VALUES(200, 158, 1350, 'mod_pagination', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'pagination', NULL, '{}', '{}', 'en-GB', 0, 158);
INSERT INTO `molajo_extension_instances` VALUES(201, 159, 1350, 'mod_plugins', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'plugins', NULL, '{}', '{}', 'en-GB', 0, 159);
INSERT INTO `molajo_extension_instances` VALUES(202, 160, 1350, 'mod_quicklinks', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'quicklinks', NULL, '{}', '{}', 'en-GB', 0, 160);
INSERT INTO `molajo_extension_instances` VALUES(203, 161, 1350, 'mod_search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'search', NULL, '{}', '{}', 'en-GB', 0, 161);
INSERT INTO `molajo_extension_instances` VALUES(204, 162, 1350, 'mod_submenu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'submenu', NULL, '{}', '{}', 'en-GB', 0, 162);
INSERT INTO `molajo_extension_instances` VALUES(205, 163, 1350, 'mod_syndicate', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'syndicate', NULL, '{}', '{}', 'en-GB', 0, 163);
INSERT INTO `molajo_extension_instances` VALUES(206, 164, 1350, 'mod_textbox', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'textbox', NULL, '{}', '{}', 'en-GB', 0, 164);
INSERT INTO `molajo_extension_instances` VALUES(207, 165, 1350, 'mod_title', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'title', NULL, '{}', '{}', 'en-GB', 0, 165);
INSERT INTO `molajo_extension_instances` VALUES(208, 166, 1350, 'mod_toolbar', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'toolbar', NULL, '{}', '{}', 'en-GB', 0, 166);
INSERT INTO `molajo_extension_instances` VALUES(210, 157, 1350, 'Administrator Menu Module', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'menu', NULL, '{}', '{"menu_id":"176","wrap":"none","layout":"admin_launchpad","start_level":"0","end_level":"0","show_all_children":"0","max_depth":"0","tag_id":"","class_suffix":"","window_open":"","layout":"","moduleclass_suffix":"_menu","cache":"1","cache_time":"900","cachemode":"itemid"}', 'en-GB', 0, 157);
INSERT INTO `molajo_extension_instances` VALUES(211, 157, 1350, 'Main Menu Module', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 'menu', NULL, '{}', '{"wrap":"none","layout":"list","menu_id":177,"start_level":"","end_level":"","show_all_children":"","max_depth":""}', 'en-GB', 0, 157);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_groups`
--

CREATE TABLE `molajo_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `content_type_id` tinyint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext,
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `position` varchar(45) NOT NULL DEFAULT ' ',
  `metadata` mediumtext,
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `molajo_groups`
--

INSERT INTO `molajo_groups` VALUES(1, 10, 100, 'Public', ' ', '', 'All visitors regardless of authentication status', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 1, 2, 1, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 1);
INSERT INTO `molajo_groups` VALUES(2, 10, 100, 'Guest', ' ', '', 'Visitors not authenticated', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 3, 4, 1, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 2);
INSERT INTO `molajo_groups` VALUES(3, 10, 100, 'Registered', ' ', '', 'Authentication visitors', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 5, 6, 1, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 3);
INSERT INTO `molajo_groups` VALUES(4, 10, 100, 'Administrator', ' ', '', 'System Administrator', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 7, 8, 1, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 4);
INSERT INTO `molajo_groups` VALUES(5, 10, 120, 'Administrator ', ' ', '', '', 0, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 42, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 1);
INSERT INTO `molajo_groups` VALUES(6, 10, 120, 'Mark Robinson', ' ', '', '', 0, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 100, 0, 0, 0, 0, ' ', NULL, '{}', '{}', 'en-GB', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_group_permissions`
--

CREATE TABLE `molajo_group_permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #_groups.id',
  `asset_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_assets.id',
  `action_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_actions.id',
  PRIMARY KEY (`id`),
  KEY `fk_group_permissions_assets` (`asset_id`),
  KEY `fk_group_permissions_actions` (`action_id`),
  KEY `fk_group_permissions_groups` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `molajo_group_permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_group_view_groups`
--

CREATE TABLE `molajo_group_view_groups` (
  `group_id` int(11) unsigned NOT NULL COMMENT 'FK to the #__group table.',
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'FK to the #__groupings table.',
  PRIMARY KEY (`view_group_id`,`group_id`),
  KEY `fk_group_view_groups_view_groups2` (`view_group_id`),
  KEY `fk_group_view_groups_groups2` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_group_view_groups`
--

INSERT INTO `molajo_group_view_groups` VALUES(1, 1);
INSERT INTO `molajo_group_view_groups` VALUES(2, 2);
INSERT INTO `molajo_group_view_groups` VALUES(3, 3);
INSERT INTO `molajo_group_view_groups` VALUES(4, 4);
INSERT INTO `molajo_group_view_groups` VALUES(3, 5);
INSERT INTO `molajo_group_view_groups` VALUES(4, 5);
INSERT INTO `molajo_group_view_groups` VALUES(5, 6);
INSERT INTO `molajo_group_view_groups` VALUES(6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_menu_items`
--

CREATE TABLE `molajo_menu_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `content_type_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext,
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `position` varchar(45) NOT NULL DEFAULT ' ',
  `metadata` mediumtext,
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_menu_items_extension_instances2` (`extension_instance_id`),
  KEY `fk_menu_items_content_type_ids2` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `molajo_menu_items`
--

INSERT INTO `molajo_menu_items` VALUES(1, 176, 2000, 'Root', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 0, 0, 65, 0, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 1);
INSERT INTO `molajo_menu_items` VALUES(2, 176, 2000, 'Create', '', 'create', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 1, 1, 12, 1, 1, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 2);
INSERT INTO `molajo_menu_items` VALUES(3, 176, 2000, 'Articles', '', 'articles', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 2, 2, 3, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 3);
INSERT INTO `molajo_menu_items` VALUES(4, 176, 2000, 'Contacts', '', 'contacts', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 2, 4, 5, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 4);
INSERT INTO `molajo_menu_items` VALUES(5, 176, 2000, 'Comments', '', 'comments', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 2, 6, 7, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 5);
INSERT INTO `molajo_menu_items` VALUES(6, 176, 2000, 'Layouts', '', 'layouts', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 2, 8, 9, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 6);
INSERT INTO `molajo_menu_items` VALUES(7, 176, 2000, 'Media', '', 'media', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 2, 10, 11, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 7);
INSERT INTO `molajo_menu_items` VALUES(8, 176, 2000, 'Access', '', 'access', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 1, 13, 22, 1, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 8);
INSERT INTO `molajo_menu_items` VALUES(9, 176, 2000, 'Profile', '', 'profile', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 8, 14, 15, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 9);
INSERT INTO `molajo_menu_items` VALUES(10, 176, 2000, 'Users', '', 'users', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 8, 16, 17, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 10);
INSERT INTO `molajo_menu_items` VALUES(11, 176, 2000, 'Groups', '', 'groups', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 8, 18, 19, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 11);
INSERT INTO `molajo_menu_items` VALUES(12, 176, 2000, 'Assets', '', 'assets', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 8, 20, 21, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 12);
INSERT INTO `molajo_menu_items` VALUES(13, 176, 2000, 'Build', '', 'build', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 1, 23, 34, 1, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 13);
INSERT INTO `molajo_menu_items` VALUES(14, 176, 2000, 'Categories', '', 'categories', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 13, 24, 25, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 14);
INSERT INTO `molajo_menu_items` VALUES(15, 176, 2000, 'Menus', '', 'menus', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 13, 26, 27, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 15);
INSERT INTO `molajo_menu_items` VALUES(16, 176, 2000, 'Menu Items', '', 'menuitems', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 13, 28, 29, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 16);
INSERT INTO `molajo_menu_items` VALUES(17, 176, 2000, 'Modules', '', 'modules', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 13, 30, 31, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 17);
INSERT INTO `molajo_menu_items` VALUES(18, 176, 2000, 'Templates', '', 'templates', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 13, 32, 33, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 18);
INSERT INTO `molajo_menu_items` VALUES(19, 176, 2000, 'Configure', '', 'configure', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 1, 35, 48, 1, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 19);
INSERT INTO `molajo_menu_items` VALUES(20, 176, 2000, 'Site', '', 'sites', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 19, 36, 37, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 20);
INSERT INTO `molajo_menu_items` VALUES(21, 176, 2000, 'Applications', '', 'applications', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 19, 38, 39, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 21);
INSERT INTO `molajo_menu_items` VALUES(22, 176, 2000, 'Checkin', '', 'checkin', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 19, 40, 41, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 22);
INSERT INTO `molajo_menu_items` VALUES(23, 176, 2000, 'Clean Cache', '', 'cleancache', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 19, 42, 43, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 23);
INSERT INTO `molajo_menu_items` VALUES(24, 176, 2000, 'Redirects', '', 'redirects', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 19, 44, 45, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 24);
INSERT INTO `molajo_menu_items` VALUES(25, 176, 2000, 'Plugins', '', 'plugins', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 19, 46, 47, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 25);
INSERT INTO `molajo_menu_items` VALUES(26, 176, 2000, 'Extend', '', 'extend', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 1, 49, 56, 1, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 26);
INSERT INTO `molajo_menu_items` VALUES(27, 176, 2000, 'Install', '', 'install', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 26, 50, 51, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 27);
INSERT INTO `molajo_menu_items` VALUES(28, 176, 2000, 'Update', '', 'update', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 26, 52, 53, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 28);
INSERT INTO `molajo_menu_items` VALUES(29, 176, 2000, 'Uninstall', '', 'uninstall', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 26, 54, 55, 2, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 29);
INSERT INTO `molajo_menu_items` VALUES(30, 176, 2000, 'Search', '', 'search', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 1, 57, 58, 1, 0, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 30);
INSERT INTO `molajo_menu_items` VALUES(31, 176, 2000, 'Home', '', 'home', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 1, 59, 60, 1, 1, ' ', '{"metadata_description":"","metadata_keywords":"","metadata_robots":"","metadata_author":"","metadata_rights":""}', '{}', '{"request":"176","page_title":"","page_id":"","page_class_suffix":"","category_id":"","author":"","number_of_items":"10","featured":"0","order_by":"1","pagination":"","layout":"","wrap":"div","layout_class_suffix":"","link_title":"","link_css":"","link_image":"","link_include_text":"","link_target":"","cache":"1","cache_time":"900","spam_protection":""}', 'en-GB', 0, 31);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_sessions`
--

CREATE TABLE `molajo_sessions` (
  `session_id` varchar(32) NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  `session_time` varchar(14) DEFAULT ' ',
  `data` longtext,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`),
  KEY `fk_sessions_applications2` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_sessions`
--

INSERT INTO `molajo_sessions` VALUES('168fd540d1b703c85e9018e2014b8f67', 2, '1321847997', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_sites`
--

CREATE TABLE `molajo_sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Application Primary Key',
  `name` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `path` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL Alias',
  `base_url` varchar(2048) NOT NULL DEFAULT ' ',
  `description` mediumtext,
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `custom_fields` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `molajo_sites`
--

INSERT INTO `molajo_sites` VALUES(1, 'Molajo', '1', '', 'Primary Site', '{}', '{}');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_site_applications`
--

CREATE TABLE `molajo_site_applications` (
  `site_id` int(11) unsigned NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`site_id`,`application_id`),
  KEY `fk_site_applications_sites2` (`site_id`),
  KEY `fk_site_applications_applications2` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_site_applications`
--

INSERT INTO `molajo_site_applications` VALUES(1, 1);
INSERT INTO `molajo_site_applications` VALUES(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_site_extension_instances`
--

CREATE TABLE `molajo_site_extension_instances` (
  `site_id` int(11) unsigned NOT NULL,
  `extension_instance_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`site_id`,`extension_instance_id`),
  KEY `fk_site_extension_instances_sites2` (`site_id`),
  KEY `fk_site_extension_instances_extension_instances2` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_site_extension_instances`
--

INSERT INTO `molajo_site_extension_instances` VALUES(1, 1);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 2);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 3);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 4);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 5);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 6);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 7);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 8);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 9);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 10);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 11);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 12);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 13);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 14);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 15);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 16);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 17);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 18);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 19);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 33);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 34);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 36);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 37);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 38);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 39);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 40);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 41);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 42);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 43);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 44);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 45);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 46);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 47);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 48);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 49);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 50);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 51);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 52);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 53);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 54);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 55);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 56);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 57);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 58);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 59);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 60);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 61);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 62);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 63);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 64);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 65);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 66);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 67);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 68);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 69);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 70);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 71);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 72);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 73);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 74);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 75);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 76);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 77);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 78);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 79);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 80);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 81);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 82);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 83);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 84);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 85);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 86);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 87);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 88);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 89);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 90);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 91);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 92);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 93);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 94);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 95);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 99);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 100);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 101);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 102);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 103);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 106);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 107);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 108);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 109);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 110);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 111);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 112);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 113);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 114);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 115);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 116);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 117);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 118);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 119);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 120);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 121);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 122);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 123);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 124);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 125);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 126);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 127);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 128);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 129);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 130);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 131);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 132);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 133);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 134);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 135);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 136);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 137);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 138);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 139);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 140);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 141);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 142);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 143);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 144);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 145);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 146);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 147);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 169);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 170);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 171);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 172);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 173);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 176);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 177);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 179);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 180);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 181);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 182);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 183);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 184);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 185);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 186);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 187);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 188);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 189);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 190);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 191);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 192);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 193);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 194);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 195);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 196);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 197);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 198);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 199);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 200);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 201);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 202);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 203);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 204);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 205);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 206);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 207);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 208);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 210);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 211);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_update_sites`
--

CREATE TABLE `molajo_update_sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT ' ',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `location` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `molajo_update_sites`
--

INSERT INTO `molajo_update_sites` VALUES(1, 'Molajo Core', 1, 'http://update.molajo.org/core/list.xml');
INSERT INTO `molajo_update_sites` VALUES(2, 'Molajo Directory', 1, 'http://update.molajo.org/directory/list.xml');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_users`
--

CREATE TABLE `molajo_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `content_text` mediumtext,
  `email` varchar(255) DEFAULT '  ',
  `password` varchar(100) NOT NULL DEFAULT '  ',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `send_email` tinyint(4) NOT NULL DEFAULT '0',
  `register_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_visit_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `custom_fields` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `molajo_users`
--

INSERT INTO `molajo_users` VALUES(42, 'admin', 'Administrator', '', '', 'admin@example.com', 'admin', 0, '1', 0, '2011-11-11 11:11:11', '0000-00-00 00:00:00', '{}', '{}');
INSERT INTO `molajo_users` VALUES(100, 'mark', 'Mark', 'Robinson', '<p>Great guy who sells insurance and coaches Little League.</p>', 'mark.robinson@example.com', 'mark', 0, '1', 0, '2011-11-02 17:45:17', '0000-00-00 00:00:00', '{}', '{"favorite_color":"red","nickname":"Fred","claim_to_fame":"No search results for Mark on Google."}');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_applications`
--

CREATE TABLE `molajo_user_applications` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_users.id',
  `application_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_applications.id',
  PRIMARY KEY (`application_id`,`user_id`),
  KEY `fk_user_applications_users` (`user_id`),
  KEY `fk_user_applications_applications` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_applications`
--

INSERT INTO `molajo_user_applications` VALUES(42, 1);
INSERT INTO `molajo_user_applications` VALUES(42, 2);
INSERT INTO `molajo_user_applications` VALUES(100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_groups`
--

CREATE TABLE `molajo_user_groups` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_users.id',
  `group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_groups.id',
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `fk_molajo_user_groups_molajo_users2` (`user_id`),
  KEY `fk_molajo_user_groups_molajo_groups2` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_groups`
--

INSERT INTO `molajo_user_groups` VALUES(42, 3);
INSERT INTO `molajo_user_groups` VALUES(42, 4);
INSERT INTO `molajo_user_groups` VALUES(42, 5);
INSERT INTO `molajo_user_groups` VALUES(100, 3);
INSERT INTO `molajo_user_groups` VALUES(100, 6);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_view_groups`
--

CREATE TABLE `molajo_user_view_groups` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_users.id',
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_groups.id',
  PRIMARY KEY (`view_group_id`,`user_id`),
  KEY `fk_molajo_user_groups_molajo_users2` (`user_id`),
  KEY `fk_molajo_user_groups_molajo_groups2` (`view_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_view_groups`
--

INSERT INTO `molajo_user_view_groups` VALUES(42, 3);
INSERT INTO `molajo_user_view_groups` VALUES(42, 4);
INSERT INTO `molajo_user_view_groups` VALUES(42, 5);
INSERT INTO `molajo_user_view_groups` VALUES(42, 6);
INSERT INTO `molajo_user_view_groups` VALUES(100, 3);
INSERT INTO `molajo_user_view_groups` VALUES(100, 5);
INSERT INTO `molajo_user_view_groups` VALUES(100, 7);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_view_groups`
--

CREATE TABLE `molajo_view_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `view_group_name_list` text NOT NULL,
  `view_group_id_list` text NOT NULL,
  `content_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `molajo_view_groups`
--

INSERT INTO `molajo_view_groups` VALUES(1, 'Public', '1', 100);
INSERT INTO `molajo_view_groups` VALUES(2, 'Guest', '2', 100);
INSERT INTO `molajo_view_groups` VALUES(3, 'Registered', '3', 100);
INSERT INTO `molajo_view_groups` VALUES(4, 'Administrator', '4', 100);
INSERT INTO `molajo_view_groups` VALUES(5, 'Registered, Administrator', '4,5', 100);
INSERT INTO `molajo_view_groups` VALUES(6, 'Private', '5', 120);
INSERT INTO `molajo_view_groups` VALUES(7, 'Private', '6', 120);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_view_group_permissions`
--

CREATE TABLE `molajo_view_group_permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_groups.id',
  `asset_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_assets.id',
  `action_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_actions.id',
  PRIMARY KEY (`id`),
  KEY `fk_view_group_permissions_view_groups2` (`view_group_id`),
  KEY `fk_view_group_permissions_actions2` (`action_id`),
  KEY `fk_view_group_permissions_assets2` (`asset_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=256 ;

--
-- Dumping data for table `molajo_view_group_permissions`
--

INSERT INTO `molajo_view_group_permissions` VALUES(1, 1, 1, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 1, 2, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(3, 1, 4, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(4, 1, 5, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(5, 1, 6, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(6, 1, 7, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(7, 1, 8, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(8, 1, 9, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(9, 1, 10, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(10, 1, 11, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(11, 1, 12, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(12, 1, 13, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(13, 1, 14, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(14, 1, 15, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(15, 1, 16, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(16, 1, 17, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(17, 1, 18, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(18, 1, 19, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(19, 1, 20, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(20, 1, 21, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(21, 1, 35, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(22, 1, 36, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(23, 1, 38, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(24, 1, 39, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(25, 1, 40, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(26, 1, 41, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(27, 1, 42, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(28, 1, 43, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(29, 1, 44, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(30, 1, 45, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(31, 1, 46, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(32, 1, 47, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(33, 1, 48, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(34, 1, 49, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(35, 1, 50, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(36, 1, 51, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(37, 1, 52, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(38, 1, 53, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(39, 1, 54, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(40, 1, 55, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(41, 1, 56, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(42, 1, 57, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(43, 1, 58, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(44, 1, 59, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(45, 1, 60, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(46, 1, 61, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(47, 1, 62, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(48, 1, 63, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(49, 1, 64, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(50, 1, 65, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(51, 1, 66, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(52, 1, 67, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(53, 1, 68, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(54, 1, 69, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(55, 1, 70, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(56, 1, 71, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(57, 1, 72, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(58, 1, 73, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(59, 1, 74, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(60, 1, 75, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(61, 1, 76, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(62, 1, 77, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(63, 1, 78, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(64, 1, 79, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(65, 1, 80, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(66, 1, 81, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(67, 1, 82, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(68, 1, 83, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(69, 1, 84, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(70, 1, 85, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(71, 1, 86, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(72, 1, 87, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(73, 1, 88, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(74, 1, 89, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(75, 1, 90, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(76, 1, 91, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(77, 1, 92, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(78, 1, 93, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(79, 1, 94, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(80, 1, 95, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(81, 1, 96, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(82, 1, 97, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(83, 1, 101, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(84, 1, 102, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(85, 1, 103, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(86, 1, 104, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(87, 1, 105, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(88, 1, 108, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(89, 1, 109, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(90, 1, 110, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(91, 1, 111, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(92, 1, 112, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(93, 1, 113, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(94, 1, 114, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(95, 1, 115, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(96, 1, 116, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(97, 1, 117, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(98, 1, 118, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(99, 1, 119, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(100, 1, 120, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(101, 1, 121, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(102, 1, 122, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(103, 1, 123, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(104, 1, 124, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(105, 1, 125, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(106, 1, 126, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(107, 1, 127, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(108, 1, 128, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(109, 1, 129, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(110, 1, 130, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(111, 1, 131, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(112, 1, 132, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(113, 1, 133, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(114, 1, 134, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(115, 1, 135, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(116, 1, 136, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(117, 1, 137, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(118, 1, 138, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(119, 1, 139, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(120, 1, 140, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(121, 1, 141, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(122, 1, 142, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(123, 1, 143, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(124, 1, 144, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(125, 1, 145, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(126, 1, 146, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(127, 1, 147, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(128, 1, 148, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(129, 1, 149, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(130, 1, 171, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(131, 1, 172, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(132, 1, 173, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(133, 1, 174, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(134, 1, 175, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(135, 1, 178, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(136, 1, 179, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(137, 3, 181, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(138, 3, 182, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(139, 3, 183, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(140, 3, 184, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(141, 3, 185, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(142, 3, 186, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(143, 3, 187, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(144, 3, 188, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(145, 3, 189, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(146, 3, 190, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(147, 3, 191, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(148, 3, 192, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(149, 3, 193, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(150, 3, 194, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(151, 3, 195, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(152, 3, 196, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(153, 3, 197, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(154, 3, 198, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(155, 3, 199, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(156, 3, 200, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(157, 3, 201, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(158, 3, 202, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(159, 3, 203, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(160, 3, 204, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(161, 3, 205, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(162, 3, 206, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(163, 3, 207, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(164, 3, 208, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(165, 3, 209, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(166, 1, 210, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(167, 1, 211, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(168, 1, 212, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(169, 1, 213, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(170, 1, 214, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(171, 1, 215, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(172, 1, 216, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(173, 1, 217, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(174, 1, 218, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(175, 1, 219, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(176, 1, 220, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(177, 1, 221, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(178, 1, 222, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(179, 1, 223, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(180, 1, 224, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(181, 1, 225, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(182, 1, 226, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(183, 1, 227, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(184, 1, 228, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(185, 1, 229, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(186, 1, 230, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(187, 1, 231, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(188, 1, 232, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(189, 1, 233, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(190, 1, 234, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(191, 1, 235, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(192, 1, 236, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(193, 1, 237, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(194, 1, 238, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(195, 1, 239, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(196, 1, 240, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(197, 1, 241, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(198, 1, 242, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(199, 1, 274, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(200, 1, 275, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(201, 1, 276, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(202, 1, 277, 3);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `molajo_application_extension_instances`
--
ALTER TABLE `molajo_application_extension_instances`
  ADD CONSTRAINT `fk_application_extensions_applications1` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_application_extension_instances_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_assets`
--
ALTER TABLE `molajo_assets`
  ADD CONSTRAINT `fk_assets_content_type_ids1` FOREIGN KEY (`content_type_id`) REFERENCES `molajo_content_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_asset_categories`
--
ALTER TABLE `molajo_asset_categories`
  ADD CONSTRAINT `fk_asset_categories_assets1` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asset_categories_categories1` FOREIGN KEY (`category_id`) REFERENCES `molajo_categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_asset_modules`
--
ALTER TABLE `molajo_asset_modules`
  ADD CONSTRAINT `fk_asset_modules_assets1` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asset_modules_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_categories`
--
ALTER TABLE `molajo_categories`
  ADD CONSTRAINT `fk_categories_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_categories_content_type_ids1` FOREIGN KEY (`content_type_id`) REFERENCES `molajo_content_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_component_options`
--
ALTER TABLE `molajo_component_options`
  ADD CONSTRAINT `fk_component_options_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_content`
--
ALTER TABLE `molajo_content`
  ADD CONSTRAINT `fk_content_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_content_content_type_ids1` FOREIGN KEY (`content_type_id`) REFERENCES `molajo_content_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extensions`
--
ALTER TABLE `molajo_extensions`
  ADD CONSTRAINT `fk_extensions_update_sites1` FOREIGN KEY (`update_site_id`) REFERENCES `molajo_update_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_extensions_content_type_ids1` FOREIGN KEY (`content_type_id`) REFERENCES `molajo_content_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extension_instances`
--
ALTER TABLE `molajo_extension_instances`
  ADD CONSTRAINT `fk_extension_instances_content_type_ids1` FOREIGN KEY (`content_type_id`) REFERENCES `molajo_content_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_extension_instances_extensions1` FOREIGN KEY (`extension_id`) REFERENCES `molajo_extensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_group_permissions`
--
ALTER TABLE `molajo_group_permissions`
  ADD CONSTRAINT `fk_group_permissions_assets1` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_permissions_actions1` FOREIGN KEY (`action_id`) REFERENCES `molajo_actions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_permissions_groups1` FOREIGN KEY (`group_id`) REFERENCES `molajo_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_group_view_groups`
--
ALTER TABLE `molajo_group_view_groups`
  ADD CONSTRAINT `fk_group_view_groups_view_groups1` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_view_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `molajo_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_menu_items`
--
ALTER TABLE `molajo_menu_items`
  ADD CONSTRAINT `fk_menu_items_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_menu_items_content_type_ids1` FOREIGN KEY (`content_type_id`) REFERENCES `molajo_content_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_sessions`
--
ALTER TABLE `molajo_sessions`
  ADD CONSTRAINT `fk_sessions_applications1` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_site_applications`
--
ALTER TABLE `molajo_site_applications`
  ADD CONSTRAINT `fk_site_applications_sites` FOREIGN KEY (`site_id`) REFERENCES `molajo_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_site_applications_applications` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_site_extension_instances`
--
ALTER TABLE `molajo_site_extension_instances`
  ADD CONSTRAINT `fk_site_extension_instances_sites1` FOREIGN KEY (`site_id`) REFERENCES `molajo_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_site_extension_instances_extension_instances1` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_applications`
--
ALTER TABLE `molajo_user_applications`
  ADD CONSTRAINT `fk_user_applications_users1` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_applications_applications1` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_groups`
--
ALTER TABLE `molajo_user_groups`
  ADD CONSTRAINT `fk_user_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `molajo_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_view_groups`
--
ALTER TABLE `molajo_user_view_groups`
  ADD CONSTRAINT `fk_user_groups_users10` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_view_groups_view_groups1` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_view_group_permissions`
--
ALTER TABLE `molajo_view_group_permissions`
  ADD CONSTRAINT `fk_view_group_permissions_view_groups1` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_view_group_permissions_actions1` FOREIGN KEY (`action_id`) REFERENCES `molajo_actions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_view_group_permissions_assets1` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
