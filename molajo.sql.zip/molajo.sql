-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 26, 2012 at 01:26 PM
-- Server version: 5.5.9
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `molajo`
--

-- --------------------------------------------------------

--
-- Table structure for table `molajo_action_types`
--

CREATE TABLE `molajo_action_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `title` varchar(255) NOT NULL DEFAULT ' ',
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_actions_table_title` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `molajo_action_types`
--

INSERT INTO `molajo_action_types` VALUES(1, 'login', 1);
INSERT INTO `molajo_action_types` VALUES(2, 'create', 1);
INSERT INTO `molajo_action_types` VALUES(3, 'view', 1);
INSERT INTO `molajo_action_types` VALUES(4, 'edit', 1);
INSERT INTO `molajo_action_types` VALUES(5, 'publish', 1);
INSERT INTO `molajo_action_types` VALUES(6, 'delete', 1);
INSERT INTO `molajo_action_types` VALUES(7, 'administer', 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_applications`
--

CREATE TABLE `molajo_applications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Application Primary Key',
  `asset_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `path` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL Alias',
  `description` mediumtext,
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `metadata` mediumtext,
  PRIMARY KEY (`id`),
  KEY `fk_applications_asset_types_index` (`asset_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `molajo_applications`
--

INSERT INTO `molajo_applications` VALUES(1, 50, 'site', '', 'Primary application for site visitors', '{}', '{}', NULL);
INSERT INTO `molajo_applications` VALUES(2, 50, 'administrator', 'administrator', 'Administrative site area for site construction', '{}', '{}', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_application_extension_instances`
--

CREATE TABLE `molajo_application_extension_instances` (
  `extension_instance_id` int(11) unsigned NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`extension_instance_id`,`application_id`),
  KEY `fk_application_extensions_applications_index` (`application_id`),
  KEY `fk_application_extension_instances_extension_instances_index` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_application_extension_instances`
--

INSERT INTO `molajo_application_extension_instances` VALUES(2, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(5, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(6, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(11, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(12, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(13, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(14, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(18, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(19, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(20, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(21, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(22, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(23, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(24, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(25, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(26, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(27, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(28, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(29, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(30, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(31, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(32, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(33, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(34, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(35, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(36, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(37, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(38, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(39, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(40, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(41, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(42, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(43, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(44, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(45, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(46, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(47, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(48, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(49, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(50, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(51, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(52, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(53, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(54, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(55, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(56, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(57, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(58, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(59, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(60, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(61, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(62, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(63, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(64, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(65, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(66, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(67, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(82, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(83, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(84, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(85, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(86, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(87, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(88, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(89, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(90, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(91, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(92, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(93, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(94, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(97, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(99, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(100, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(101, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(103, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(104, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(105, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(106, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(107, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(108, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(109, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(110, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(111, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(112, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(113, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(114, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(115, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(116, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(117, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(118, 1);
INSERT INTO `molajo_application_extension_instances` VALUES(0, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(1, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(2, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(3, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(4, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(5, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(6, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(7, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(8, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(9, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(10, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(11, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(12, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(13, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(14, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(15, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(16, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(17, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(18, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(19, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(20, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(21, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(22, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(23, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(24, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(25, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(26, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(27, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(28, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(29, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(30, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(31, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(32, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(33, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(34, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(35, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(36, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(37, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(38, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(39, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(40, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(41, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(42, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(43, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(44, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(45, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(46, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(47, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(48, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(49, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(50, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(51, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(52, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(53, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(54, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(55, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(56, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(57, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(58, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(59, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(60, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(61, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(62, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(63, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(64, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(65, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(66, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(67, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(82, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(83, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(84, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(85, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(86, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(87, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(88, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(89, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(90, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(91, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(92, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(93, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(94, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(98, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(99, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(103, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(104, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(105, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(106, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(107, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(108, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(109, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(110, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(111, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(112, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(113, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(114, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(115, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(116, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(117, 2);
INSERT INTO `molajo_application_extension_instances` VALUES(118, 2);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_assets`
--

CREATE TABLE `molajo_assets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Assets Primary Key',
  `asset_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `source_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Content Primary Key',
  `routable` tinyint(1) NOT NULL DEFAULT '0',
  `sef_request` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL',
  `request` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'The actually link the menu item refers to.',
  `request_option` varchar(45) NOT NULL,
  `request_model` varchar(45) NOT NULL,
  `redirect_to_id` int(11) unsigned NOT NULL DEFAULT '0',
  `view_group_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the molajo_groupings table',
  `primary_category_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sef_request` (`sef_request`(255)),
  KEY `request` (`request`(255)),
  KEY `index_assets_asset_types` (`asset_type_id`),
  KEY `parameters` (`request_option`,`request_model`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=157 ;

--
-- Dumping data for table `molajo_assets`
--

INSERT INTO `molajo_assets` VALUES(1, 10, 1, 0, '', '', '', '', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(2, 50, 1, 0, '', '', '', '', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(3, 50, 2, 0, 'administrator', '', '', '', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(5, 100, 1, 1, 'group/1', 'index.php?option=groups&model=group&id=1', 'groups', 'group', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(6, 100, 2, 1, 'group/2', 'index.php?option=groups&model=group&id=2', 'groups', 'group', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(7, 100, 3, 1, 'group/3', 'index.php?option=groups&model=group&id=3', 'groups', 'group', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(8, 100, 4, 1, 'group/4', 'index.php?option=groups&model=group&id=4', 'groups', 'group', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(9, 120, 5, 1, 'group/5', 'index.php?option=groups&model=group&id=5', 'groups', 'group', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(10, 120, 6, 1, 'group/6', 'index.php?option=groups&model=group&id=6', 'groups', 'group', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(12, 1050, 0, 1, 'extensions/components/0', 'index.php?option=extensions&model=components&id=0', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(13, 1050, 1, 1, 'extensions/components/1', 'index.php?option=extensions&model=components&id=1', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(14, 1050, 2, 1, 'extensions/components/2', 'index.php?option=extensions&model=components&id=2', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(15, 1050, 3, 1, 'extensions/components/3', 'index.php?option=extensions&model=components&id=3', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(16, 1050, 4, 1, 'extensions/components/4', 'index.php?option=extensions&model=components&id=4', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(17, 1050, 5, 1, 'extensions/components/5', 'index.php?option=extensions&model=components&id=5', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(18, 1050, 6, 1, 'extensions/components/6', 'index.php?option=extensions&model=components&id=6', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(19, 1050, 7, 1, 'extensions/components/7', 'index.php?option=extensions&model=components&id=7', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(20, 1050, 8, 1, 'extensions/components/8', 'index.php?option=extensions&model=components&id=8', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(21, 1050, 9, 1, 'extensions/components/9', 'index.php?option=extensions&model=components&id=9', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(22, 1050, 10, 1, 'extensions/components/10', 'index.php?option=extensions&model=components&id=10', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(23, 1050, 11, 1, 'extensions/components/11', 'index.php?option=extensions&model=components&id=11', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(24, 1050, 12, 1, 'extensions/components/12', 'index.php?option=extensions&model=components&id=12', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(25, 1050, 13, 1, 'extensions/components/13', 'index.php?option=extensions&model=components&id=13', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(26, 1050, 14, 1, 'extensions/components/14', 'index.php?option=extensions&model=components&id=14', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(27, 1050, 15, 1, 'extensions/components/15', 'index.php?option=extensions&model=components&id=15', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(28, 1050, 16, 1, 'extensions/components/16', 'index.php?option=extensions&model=components&id=16', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(29, 1050, 17, 1, 'extensions/components/17', 'index.php?option=extensions&model=components&id=17', 'extension', 'Components', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(30, 1100, 18, 1, 'extensions/languages/18', 'index.php?option=extensions&model=languages&id=18', 'extension', 'Languages', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(31, 1150, 19, 1, 'extensions/views/19', 'index.php?option=extensions&model=views&id=19', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(32, 1150, 20, 1, 'extensions/views/20', 'index.php?option=extensions&model=views&id=20', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(33, 1150, 21, 1, 'extensions/views/21', 'index.php?option=extensions&model=views&id=21', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(34, 1150, 22, 1, 'extensions/views/22', 'index.php?option=extensions&model=views&id=22', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(35, 1150, 23, 1, 'extensions/views/23', 'index.php?option=extensions&model=views&id=23', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(36, 1150, 24, 1, 'extensions/views/24', 'index.php?option=extensions&model=views&id=24', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(37, 1150, 25, 1, 'extensions/views/25', 'index.php?option=extensions&model=views&id=25', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(38, 1150, 26, 1, 'extensions/views/26', 'index.php?option=extensions&model=views&id=26', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(39, 1150, 27, 1, 'extensions/views/27', 'index.php?option=extensions&model=views&id=27', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(40, 1150, 28, 1, 'extensions/views/28', 'index.php?option=extensions&model=views&id=28', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(41, 1150, 29, 1, 'extensions/views/29', 'index.php?option=extensions&model=views&id=29', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(42, 1150, 30, 1, 'extensions/views/30', 'index.php?option=extensions&model=views&id=30', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(43, 1150, 31, 1, 'extensions/views/31', 'index.php?option=extensions&model=views&id=31', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(44, 1150, 32, 1, 'extensions/views/32', 'index.php?option=extensions&model=views&id=32', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(45, 1150, 33, 1, 'extensions/views/33', 'index.php?option=extensions&model=views&id=33', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(46, 1150, 34, 1, 'extensions/views/34', 'index.php?option=extensions&model=views&id=34', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(47, 1150, 35, 1, 'extensions/views/35', 'index.php?option=extensions&model=views&id=35', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(48, 1150, 36, 1, 'extensions/views/36', 'index.php?option=extensions&model=views&id=36', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(49, 1150, 37, 1, 'extensions/views/37', 'index.php?option=extensions&model=views&id=37', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(50, 1150, 38, 1, 'extensions/views/38', 'index.php?option=extensions&model=views&id=38', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(51, 1150, 39, 1, 'extensions/views/39', 'index.php?option=extensions&model=views&id=39', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(52, 1150, 40, 1, 'extensions/views/40', 'index.php?option=extensions&model=views&id=40', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(53, 1150, 41, 1, 'extensions/views/41', 'index.php?option=extensions&model=views&id=41', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(54, 1150, 42, 1, 'extensions/views/42', 'index.php?option=extensions&model=views&id=42', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(55, 1150, 43, 1, 'extensions/views/43', 'index.php?option=extensions&model=views&id=43', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(56, 1150, 44, 1, 'extensions/views/44', 'index.php?option=extensions&model=views&id=44', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(57, 1150, 45, 1, 'extensions/views/45', 'index.php?option=extensions&model=views&id=45', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(58, 1150, 46, 1, 'extensions/views/46', 'index.php?option=extensions&model=views&id=46', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(59, 1150, 47, 1, 'extensions/views/47', 'index.php?option=extensions&model=views&id=47', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(60, 1150, 48, 1, 'extensions/views/48', 'index.php?option=extensions&model=views&id=48', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(61, 1150, 49, 1, 'extensions/views/49', 'index.php?option=extensions&model=views&id=49', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(62, 1150, 50, 1, 'extensions/views/50', 'index.php?option=extensions&model=views&id=50', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(63, 1150, 51, 1, 'extensions/views/51', 'index.php?option=extensions&model=views&id=51', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(64, 1150, 52, 1, 'extensions/views/52', 'index.php?option=extensions&model=views&id=52', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(65, 1150, 53, 1, 'extensions/views/53', 'index.php?option=extensions&model=views&id=53', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(66, 1150, 54, 1, 'extensions/views/54', 'index.php?option=extensions&model=views&id=54', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(67, 1150, 55, 1, 'extensions/views/55', 'index.php?option=extensions&model=views&id=55', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(68, 1150, 56, 1, 'extensions/views/56', 'index.php?option=extensions&model=views&id=56', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(69, 1150, 57, 1, 'extensions/views/57', 'index.php?option=extensions&model=views&id=57', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(70, 1150, 58, 1, 'extensions/views/58', 'index.php?option=extensions&model=views&id=58', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(71, 1150, 59, 1, 'extensions/views/59', 'index.php?option=extensions&model=views&id=59', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(72, 1150, 60, 1, 'extensions/views/60', 'index.php?option=extensions&model=views&id=60', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(73, 1150, 61, 1, 'extensions/views/61', 'index.php?option=extensions&model=views&id=61', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(74, 1150, 62, 1, 'extensions/views/62', 'index.php?option=extensions&model=views&id=62', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(75, 1150, 63, 1, 'extensions/views/63', 'index.php?option=extensions&model=views&id=63', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(76, 1150, 64, 1, 'extensions/views/64', 'index.php?option=extensions&model=views&id=64', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(77, 1150, 65, 1, 'extensions/views/65', 'index.php?option=extensions&model=views&id=65', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(78, 1150, 66, 1, 'extensions/views/66', 'index.php?option=extensions&model=views&id=66', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(79, 1150, 67, 1, 'extensions/views/67', 'index.php?option=extensions&model=views&id=67', 'extension', 'Views', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(80, 1450, 82, 1, 'extensions/plugins/82', 'index.php?option=extensions&model=plugins&id=82', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(81, 1450, 83, 1, 'extensions/plugins/83', 'index.php?option=extensions&model=plugins&id=83', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(82, 1450, 84, 1, 'extensions/plugins/84', 'index.php?option=extensions&model=plugins&id=84', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(83, 1450, 85, 1, 'extensions/plugins/85', 'index.php?option=extensions&model=plugins&id=85', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(84, 1450, 86, 1, 'extensions/plugins/86', 'index.php?option=extensions&model=plugins&id=86', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(85, 1450, 87, 1, 'extensions/plugins/87', 'index.php?option=extensions&model=plugins&id=87', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(86, 1450, 88, 1, 'extensions/plugins/88', 'index.php?option=extensions&model=plugins&id=88', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(87, 1450, 89, 1, 'extensions/plugins/89', 'index.php?option=extensions&model=plugins&id=89', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(88, 1450, 90, 1, 'extensions/plugins/90', 'index.php?option=extensions&model=plugins&id=90', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(89, 1450, 91, 1, 'extensions/plugins/91', 'index.php?option=extensions&model=plugins&id=91', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(90, 1450, 92, 1, 'extensions/plugins/92', 'index.php?option=extensions&model=plugins&id=92', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(91, 1450, 93, 1, 'extensions/plugins/93', 'index.php?option=extensions&model=plugins&id=93', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(92, 1450, 94, 1, 'extensions/plugins/94', 'index.php?option=extensions&model=plugins&id=94', 'extension', 'Plugins', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(93, 1500, 97, 1, 'extensions/templates/97', 'index.php?option=extensions&model=templates&id=97', 'extension', 'Templates', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(94, 1500, 98, 1, 'extensions/templates/98', 'index.php?option=extensions&model=templates&id=98', 'extension', 'Templates', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(95, 1500, 99, 1, 'extensions/templates/99', 'index.php?option=extensions&model=templates&id=99', 'extension', 'Templates', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(96, 1300, 100, 1, 'extensions/menus/100', 'index.php?option=extensions&model=menus&id=100', 'extension', 'Menus', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(97, 1300, 101, 1, 'extensions/menus/101', 'index.php?option=extensions&model=menus&id=101', 'extension', 'Menus', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(98, 1350, 103, 1, 'extensions/modules/103', 'index.php?option=extensions&model=modules&id=103', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(99, 1350, 104, 1, 'extensions/modules/104', 'index.php?option=extensions&model=modules&id=104', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(100, 1350, 105, 1, 'extensions/modules/105', 'index.php?option=extensions&model=modules&id=105', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(101, 1350, 106, 1, 'extensions/modules/106', 'index.php?option=extensions&model=modules&id=106', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(102, 1350, 107, 1, 'extensions/modules/107', 'index.php?option=extensions&model=modules&id=107', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(103, 1350, 108, 1, 'extensions/modules/108', 'index.php?option=extensions&model=modules&id=108', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(104, 1350, 109, 1, 'extensions/modules/109', 'index.php?option=extensions&model=modules&id=109', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(105, 1350, 110, 1, 'extensions/modules/110', 'index.php?option=extensions&model=modules&id=110', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(106, 1350, 111, 1, 'extensions/modules/111', 'index.php?option=extensions&model=modules&id=111', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(107, 1350, 112, 1, 'extensions/modules/112', 'index.php?option=extensions&model=modules&id=112', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(108, 1350, 113, 1, 'extensions/modules/113', 'index.php?option=extensions&model=modules&id=113', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(109, 1350, 114, 1, 'extensions/modules/114', 'index.php?option=extensions&model=modules&id=114', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(110, 1350, 115, 1, 'extensions/modules/115', 'index.php?option=extensions&model=modules&id=115', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(111, 1350, 116, 1, 'extensions/modules/116', 'index.php?option=extensions&model=modules&id=116', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(112, 1350, 117, 1, 'extensions/modules/117', 'index.php?option=extensions&model=modules&id=117', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(113, 1350, 118, 1, 'extensions/modules/118', 'index.php?option=extensions&model=modules&id=118', 'extension', 'Modules', 0, 1, 0);
INSERT INTO `molajo_assets` VALUES(139, 2000, 102, 1, 'content', 'index.php?option=dashboard&model=dummy', 'dashboard', 'static', 0, 1, 3);
INSERT INTO `molajo_assets` VALUES(140, 10000, 130, 1, 'content/articles', 'index.php?option=articles&model=articles', 'articles', 'articles', 0, 1, 3);
INSERT INTO `molajo_assets` VALUES(141, 3000, 103, 1, 'category/content', 'index.php?option=categories&id=103', 'categories', 'category', 0, 3, 0);
INSERT INTO `molajo_assets` VALUES(142, 10000, 104, 1, 'content/article-1', 'index.php?option=articles&model=article&id=104', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(143, 10000, 105, 1, 'content/article-2', 'index.php?option=articles&model=article&id=105', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(144, 10000, 106, 1, 'content/article-3', 'index.php?option=articles&model=article&id=106', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(145, 10000, 107, 1, 'content/article-4', 'index.php?option=articles&model=article&id=107', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(146, 10000, 108, 1, 'content/article-5', 'index.php?option=articles&model=article&id=108', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(147, 10000, 109, 1, 'content/article-6', 'index.php?option=articles&model=article&id=109', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(148, 10000, 110, 1, 'content/article-7', 'index.php?option=articles&model=article&id=110', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(149, 10000, 111, 1, 'content/article-8', 'index.php?option=articles&model=article&id=111', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(150, 10000, 112, 1, 'content/article-9', 'index.php?option=articles&model=article&id=112', 'articles', 'article', 0, 3, 103);
INSERT INTO `molajo_assets` VALUES(151, 10000, 113, 1, 'content/article-10', 'index.php?option=articles&model=article&id=113', 'articles', 'article', 0, 3, 103);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_asset_activity`
--

CREATE TABLE `molajo_asset_activity` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `rating` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `activity_datetime` datetime DEFAULT NULL,
  `ip_address` varchar(15) NOT NULL DEFAULT '',
  `custom_fields` mediumtext,
  PRIMARY KEY (`id`),
  KEY `asset_activity_assets_index` (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `molajo_asset_activity`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_asset_categories`
--

CREATE TABLE `molajo_asset_categories` (
  `asset_id` int(11) unsigned NOT NULL DEFAULT '0',
  `category_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`asset_id`,`category_id`),
  KEY `fk_asset_categories_assets_index` (`asset_id`),
  KEY `fk_asset_categories_categories_index` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_asset_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_asset_extensions`
--

CREATE TABLE `molajo_asset_extensions` (
  `asset_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Actions Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`asset_id`,`extension_instance_id`),
  KEY `fk_asset_extensions_assets_index` (`asset_id`),
  KEY `fk_asset_extensions_extension_instances_index` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_asset_extensions`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_asset_types`
--

CREATE TABLE `molajo_asset_types` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Actions Primary Key',
  `title` varchar(255) NOT NULL DEFAULT ' ',
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `source_table` varchar(255) NOT NULL DEFAULT ' ',
  `component_option` varchar(45) NOT NULL DEFAULT ' ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60001 ;

--
-- Dumping data for table `molajo_asset_types`
--

INSERT INTO `molajo_asset_types` VALUES(1, 'System', 1, '', '');
INSERT INTO `molajo_asset_types` VALUES(10, 'Sites', 1, '__sites', 'sites');
INSERT INTO `molajo_asset_types` VALUES(50, 'Applications', 1, '__applications', 'applications');
INSERT INTO `molajo_asset_types` VALUES(100, 'System', 1, '__content', 'groups');
INSERT INTO `molajo_asset_types` VALUES(110, 'Normal', 1, '__content', 'groups');
INSERT INTO `molajo_asset_types` VALUES(120, 'User', 1, '__content', 'groups');
INSERT INTO `molajo_asset_types` VALUES(130, 'Friend', 1, '__content', 'groups');
INSERT INTO `molajo_asset_types` VALUES(500, 'Users', 1, '__users', 'users');
INSERT INTO `molajo_asset_types` VALUES(1050, 'Components', 1, '__extension_instances', 'extensions');
INSERT INTO `molajo_asset_types` VALUES(1100, 'Languages', 1, '__extension_instances', 'extensions');
INSERT INTO `molajo_asset_types` VALUES(1150, 'Views', 1, '__extension_instances', 'extensions');
INSERT INTO `molajo_asset_types` VALUES(1300, 'Menus', 1, '__extension_instances', 'extensions');
INSERT INTO `molajo_asset_types` VALUES(1350, 'Modules', 1, '__extension_instances', 'extensions');
INSERT INTO `molajo_asset_types` VALUES(1450, 'Plugins', 1, '__extension_instances', 'extensions');
INSERT INTO `molajo_asset_types` VALUES(1500, 'Templates', 1, '__extension_instances', 'extensions');
INSERT INTO `molajo_asset_types` VALUES(2000, 'Component', 1, '__content', 'menuitems');
INSERT INTO `molajo_asset_types` VALUES(2100, 'Link', 1, '__content', 'menuitems');
INSERT INTO `molajo_asset_types` VALUES(2200, 'Module', 1, '__content', 'menuitems');
INSERT INTO `molajo_asset_types` VALUES(2300, 'Separator', 1, '__content', 'menuitems');
INSERT INTO `molajo_asset_types` VALUES(3000, 'List', 0, '__content', 'categories');
INSERT INTO `molajo_asset_types` VALUES(3500, 'Tags', 0, '__content', 'categories');
INSERT INTO `molajo_asset_types` VALUES(10000, 'Articles', 0, '__content', 'articles');
INSERT INTO `molajo_asset_types` VALUES(20000, 'Contacts', 0, '__content', 'contacts');
INSERT INTO `molajo_asset_types` VALUES(30000, 'Comments', 0, '__content', 'comments');
INSERT INTO `molajo_asset_types` VALUES(40000, 'Dashboard', 0, '__dummy', 'dashboard');
INSERT INTO `molajo_asset_types` VALUES(50000, 'Media', 0, '__content', 'media');
INSERT INTO `molajo_asset_types` VALUES(60000, 'Views', 0, '__content', 'views');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_content`
--

CREATE TABLE `molajo_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `asset_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `path` varchar(2048) NOT NULL DEFAULT ' ',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext,
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `root` int(11) unsigned NOT NULL DEFAULT '0',
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `lvl` int(11) unsigned NOT NULL DEFAULT '0',
  `home` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `position` varchar(45) NOT NULL DEFAULT ' ',
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `metadata` mediumtext,
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_content_extension_instances_index` (`extension_instance_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=114 ;

--
-- Dumping data for table `molajo_content`
--

INSERT INTO `molajo_content` VALUES(0, 93, 1000, 'ROOT', '', ' ', 'root', '<p>Root Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_content` VALUES(1, 9, 100, 'Public', ' ', 'groups', 'public', 'All visitors regardless of authentication status', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 1, 2, 1, 0, ' ', '{}', '{}', NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_content` VALUES(2, 9, 100, 'Guest', ' ', 'groups', 'guest', 'Visitors not authenticated', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 4, 1, 0, ' ', '{}', '{}', NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_content` VALUES(3, 9, 100, 'Registered', ' ', 'groups', 'registered', 'Authentication visitors', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 5, 6, 1, 0, ' ', '{}', '{}', NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_content` VALUES(4, 9, 100, 'Administrator', ' ', 'groups', 'administrator', 'System Administrator', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 7, 8, 1, 0, ' ', '{}', '{}', NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_content` VALUES(5, 9, 120, 'Administrator ', ' ', 'groups', 'admin', '', 0, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 42, 0, 0, 0, 0, ' ', '{}', '{}', NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_content` VALUES(6, 9, 120, 'Mark Robinson', ' ', 'groups', 'mark', '', 0, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 100, 0, 0, 0, 0, ' ', '{}', '{}', NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_content` VALUES(101, 100, 2000, 'Root', '', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 101, 0, 0, 65, 0, 0, ' ', '{}', '{}', '{}', 'en-GB', 0, 101);
INSERT INTO `molajo_content` VALUES(102, 100, 2000, 'Content', '', '', 'content', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 101, 101, 1, 12, 1, 0, ' ', '{}', '{"extension_instance_id":"7","section":"content","id":"","category_id":"","template_id":"","page_id":"","page_css_id":"","page_css_class":"","view_id":"19","view_css_id":"","view_css_class":"","wrap_id":"67","wrap_css_id":"","wrap_css_class":"","cache":"1","cache_time":"900"}', '{"metadata_title":"Content", "metadata_description":"Dashboard", "metadata_keywords":"dashboard", "metadata_robots":"follow, index", "metadata_author":"Author Name", "metadata_content_rights":"CC"}', 'en-GB', 0, 102);
INSERT INTO `molajo_content` VALUES(103, 2, 3000, 'Content', '', ' ', 'content', '<p>Category for Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_content` VALUES(104, 2, 10000, 'Article 1', '', 'content', 'article-1', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_content` VALUES(105, 2, 10000, 'Article 2', '', 'content', 'article-2', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_content` VALUES(106, 2, 10000, 'Article 3', '', 'content', 'article-3', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_content` VALUES(107, 2, 10000, 'Article 4', '', 'content', 'article-4', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_content` VALUES(108, 2, 10000, 'Article 5', '', 'content', 'article-5', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_content` VALUES(109, 2, 10000, 'Article 6', '', 'content', 'article-6', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_content` VALUES(110, 2, 10000, 'Article 7', '', 'content', 'article-7', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_content` VALUES(111, 2, 10000, 'Article 8', '', 'content', 'article-8', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_content` VALUES(112, 2, 10000, 'Article 9', '', 'content', 'article-9', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_content` VALUES(113, 2, 10000, 'Article 10', '', 'content', 'article-10', '<p>Content</p>', 0, 0, 0, 1, '2011-11-01 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, ' ', NULL, NULL, NULL, 'en-GB', 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extensions`
--

CREATE TABLE `molajo_extensions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `extension_site_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `subtype` varchar(255) NOT NULL DEFAULT '',
  `asset_type_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `extensions_extension_sites_index` (`extension_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=102 ;

--
-- Dumping data for table `molajo_extensions`
--

INSERT INTO `molajo_extensions` VALUES(0, 1, 'core', '', 1050);
INSERT INTO `molajo_extensions` VALUES(1, 1, 'applications', '', 1050);
INSERT INTO `molajo_extensions` VALUES(2, 1, 'articles', '', 1050);
INSERT INTO `molajo_extensions` VALUES(3, 1, 'assets', '', 1050);
INSERT INTO `molajo_extensions` VALUES(4, 1, 'categories', '', 1050);
INSERT INTO `molajo_extensions` VALUES(5, 1, 'comments', '', 1050);
INSERT INTO `molajo_extensions` VALUES(6, 1, 'contacts', '''', 1050);
INSERT INTO `molajo_extensions` VALUES(7, 1, 'dashboard', '', 1050);
INSERT INTO `molajo_extensions` VALUES(8, 1, 'extensions', '', 1050);
INSERT INTO `molajo_extensions` VALUES(9, 1, 'groups', '', 1050);
INSERT INTO `molajo_extensions` VALUES(10, 1, 'installer', '', 1050);
INSERT INTO `molajo_extensions` VALUES(11, 1, 'login', '''', 1050);
INSERT INTO `molajo_extensions` VALUES(12, 1, 'media', '', 1050);
INSERT INTO `molajo_extensions` VALUES(13, 1, 'profile', '''', 1050);
INSERT INTO `molajo_extensions` VALUES(14, 1, 'search', '', 1050);
INSERT INTO `molajo_extensions` VALUES(15, 1, 'users', '', 1050);
INSERT INTO `molajo_extensions` VALUES(16, 1, 'site', '', 1050);
INSERT INTO `molajo_extensions` VALUES(17, 1, 'redirects', '', 1050);
INSERT INTO `molajo_extensions` VALUES(18, 1, 'English (UK)', 'en-GB', 1100);
INSERT INTO `molajo_extensions` VALUES(19, 1, 'dashboard', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(20, 1, 'dashboard-module', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(21, 1, 'default', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(22, 1, 'document-defer', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(23, 1, 'document-head', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(24, 1, 'dummy', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(25, 1, 'edit', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(26, 1, 'edit-editor', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(27, 1, 'edit-access-control', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(28, 1, 'edit-custom-fields', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(29, 1, 'edit-metadata', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(30, 1, 'edit-parameters', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(31, 1, 'edit-title', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(32, 1, 'edit-toolbar', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(33, 1, 'grid', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(34, 1, 'grid-batch', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(35, 1, 'grid-filters', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(36, 1, 'grid-pagination', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(37, 1, 'grid-submenu', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(38, 1, 'grid-table', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(39, 1, 'grid-title', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(40, 1, 'grid-toolbar', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(41, 1, 'page-header', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(42, 1, 'page-footer', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(43, 1, 'system-errors', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(44, 1, 'system-messages', 'extensions', 1150);
INSERT INTO `molajo_extensions` VALUES(45, 1, 'button', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(46, 1, 'colorpicker', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(47, 1, 'input', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(48, 1, 'media', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(49, 1, 'number', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(50, 1, 'option', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(51, 1, 'rules', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(52, 1, 'spacer', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(53, 1, 'textarea', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(54, 1, 'user', 'formfields', 1150);
INSERT INTO `molajo_extensions` VALUES(55, 1, 'default', 'pages', 1150);
INSERT INTO `molajo_extensions` VALUES(56, 1, 'system-error', 'pages', 1150);
INSERT INTO `molajo_extensions` VALUES(57, 1, 'system-offline', 'pages', 1150);
INSERT INTO `molajo_extensions` VALUES(58, 1, 'article', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(59, 1, 'aside', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(60, 1, 'default', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(61, 1, 'div', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(62, 1, 'footer', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(63, 1, 'header', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(64, 1, 'hgroup', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(65, 1, 'nav', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(66, 1, 'none', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(67, 1, 'section', 'wraps', 1150);
INSERT INTO `molajo_extensions` VALUES(68, 1, 'example', 'acl', 1450);
INSERT INTO `molajo_extensions` VALUES(69, 1, 'molajo', 'authentication', 1450);
INSERT INTO `molajo_extensions` VALUES(70, 1, 'none', 'editors', 1450);
INSERT INTO `molajo_extensions` VALUES(71, 1, 'article', 'editor-buttons', 1450);
INSERT INTO `molajo_extensions` VALUES(72, 1, 'editor', 'editor-buttons', 1450);
INSERT INTO `molajo_extensions` VALUES(73, 1, 'image', 'editor-buttons', 1450);
INSERT INTO `molajo_extensions` VALUES(74, 1, 'pagebreak', 'editor-buttons', 1450);
INSERT INTO `molajo_extensions` VALUES(75, 1, 'readmore', 'editor-buttons', 1450);
INSERT INTO `molajo_extensions` VALUES(76, 1, 'logout', 'system', 1450);
INSERT INTO `molajo_extensions` VALUES(77, 1, 'molajo', 'system', 1450);
INSERT INTO `molajo_extensions` VALUES(78, 1, 'remember', 'system', 1450);
INSERT INTO `molajo_extensions` VALUES(79, 1, 'system', 'system', 1450);
INSERT INTO `molajo_extensions` VALUES(80, 1, 'molajo', 'user', 1450);
INSERT INTO `molajo_extensions` VALUES(81, 1, 'cleanslate', '', 1500);
INSERT INTO `molajo_extensions` VALUES(82, 1, 'molajito', '', 1500);
INSERT INTO `molajo_extensions` VALUES(83, 1, 'system', '', 1500);
INSERT INTO `molajo_extensions` VALUES(84, 1, 'Administrator Menu', '', 1300);
INSERT INTO `molajo_extensions` VALUES(85, 1, 'Main Menu', '', 1300);
INSERT INTO `molajo_extensions` VALUES(86, 1, 'assetwidget', '', 1350);
INSERT INTO `molajo_extensions` VALUES(87, 1, 'aclwidget', '', 1350);
INSERT INTO `molajo_extensions` VALUES(88, 1, 'breadcrumbs', '', 1350);
INSERT INTO `molajo_extensions` VALUES(89, 1, 'categorywidget', '', 1350);
INSERT INTO `molajo_extensions` VALUES(90, 1, 'content', '', 1350);
INSERT INTO `molajo_extensions` VALUES(91, 1, 'custom', '', 1350);
INSERT INTO `molajo_extensions` VALUES(92, 1, 'dashboard', '', 1350);
INSERT INTO `molajo_extensions` VALUES(93, 1, 'dashboard-module', '', 1350);
INSERT INTO `molajo_extensions` VALUES(94, 1, 'default', '', 1350);
INSERT INTO `molajo_extensions` VALUES(95, 1, 'document-defer', '', 1350);
INSERT INTO `molajo_extensions` VALUES(96, 1, 'document-head', '', 1350);
INSERT INTO `molajo_extensions` VALUES(97, 1, 'dummy', '', 1350);
INSERT INTO `molajo_extensions` VALUES(98, 1, 'page-header', '', 1350);
INSERT INTO `molajo_extensions` VALUES(99, 1, 'page-footer', '', 1350);
INSERT INTO `molajo_extensions` VALUES(100, 1, 'system-errors', '', 1350);
INSERT INTO `molajo_extensions` VALUES(101, 1, 'system-messages', '', 1350);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extension_instances`
--

CREATE TABLE `molajo_extension_instances` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_id` int(11) unsigned NOT NULL,
  `asset_type_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `subtitle` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Subtitle',
  `alias` varchar(255) NOT NULL DEFAULT ' ',
  `content_text` mediumtext,
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `stickied` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'Published State 2: Archived 1: Published 0: Unpublished -1: Trashed -2: Spam -10 Version',
  `start_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish Begin Date and Time',
  `stop_publishing_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Publish End Date and Time',
  `version` int(11) unsigned NOT NULL DEFAULT '1' COMMENT 'Version Number',
  `version_of_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary ID for this Version',
  `status_prior_to_version` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'State value prior to creating this version copy and changing the state to Version',
  `created_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Created Date and Time',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Created by User ID',
  `modified_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Modified Date',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Modified By User ID',
  `checked_out_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Checked out Date and Time',
  `checked_out_by` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Checked out by User Id',
  `position` varchar(45) NOT NULL DEFAULT ' ',
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Attributes (Custom Fields)',
  `metadata` mediumtext,
  `language` char(7) NOT NULL DEFAULT 'en-GB',
  `translation_of_id` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_extension_instances_extensions_index` (`extension_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=134 ;

--
-- Dumping data for table `molajo_extension_instances`
--

INSERT INTO `molajo_extension_instances` VALUES(0, 0, 1050, 'core', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 0);
INSERT INTO `molajo_extension_instances` VALUES(1, 1, 1050, 'applications', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 1);
INSERT INTO `molajo_extension_instances` VALUES(2, 2, 1050, 'articles', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 2);
INSERT INTO `molajo_extension_instances` VALUES(3, 3, 1050, 'assets', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 3);
INSERT INTO `molajo_extension_instances` VALUES(4, 4, 1050, 'categories', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 4);
INSERT INTO `molajo_extension_instances` VALUES(5, 5, 1050, 'comments', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 5);
INSERT INTO `molajo_extension_instances` VALUES(6, 6, 1050, 'contacts', '''', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 6);
INSERT INTO `molajo_extension_instances` VALUES(7, 7, 1050, 'dashboard', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 7);
INSERT INTO `molajo_extension_instances` VALUES(8, 8, 1050, 'extensions', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 8);
INSERT INTO `molajo_extension_instances` VALUES(9, 9, 1050, 'groups', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 9);
INSERT INTO `molajo_extension_instances` VALUES(10, 10, 1050, 'installer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 10);
INSERT INTO `molajo_extension_instances` VALUES(11, 11, 1050, 'login', '''', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 11);
INSERT INTO `molajo_extension_instances` VALUES(12, 12, 1050, 'media', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 12);
INSERT INTO `molajo_extension_instances` VALUES(13, 13, 1050, 'profile', '''', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 13);
INSERT INTO `molajo_extension_instances` VALUES(14, 14, 1050, 'search', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 14);
INSERT INTO `molajo_extension_instances` VALUES(15, 15, 1050, 'users', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 15);
INSERT INTO `molajo_extension_instances` VALUES(16, 16, 1050, 'site', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 16);
INSERT INTO `molajo_extension_instances` VALUES(17, 17, 1050, 'redirects', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 17);
INSERT INTO `molajo_extension_instances` VALUES(18, 18, 1100, 'English (UK)', 'en-GB', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 18);
INSERT INTO `molajo_extension_instances` VALUES(19, 19, 1150, 'dashboard', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 19);
INSERT INTO `molajo_extension_instances` VALUES(20, 20, 1150, 'dashboard-module', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 20);
INSERT INTO `molajo_extension_instances` VALUES(21, 21, 1150, 'default', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 21);
INSERT INTO `molajo_extension_instances` VALUES(22, 22, 1150, 'document-defer', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 22);
INSERT INTO `molajo_extension_instances` VALUES(23, 23, 1150, 'document-head', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 23);
INSERT INTO `molajo_extension_instances` VALUES(24, 24, 1150, 'dummy', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 24);
INSERT INTO `molajo_extension_instances` VALUES(25, 25, 1150, 'edit', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 25);
INSERT INTO `molajo_extension_instances` VALUES(26, 26, 1150, 'edit-editor', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 26);
INSERT INTO `molajo_extension_instances` VALUES(27, 27, 1150, 'edit-access-control', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 27);
INSERT INTO `molajo_extension_instances` VALUES(28, 28, 1150, 'edit-custom-fields', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 28);
INSERT INTO `molajo_extension_instances` VALUES(29, 29, 1150, 'edit-metadata', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 29);
INSERT INTO `molajo_extension_instances` VALUES(30, 30, 1150, 'edit-parameters', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 30);
INSERT INTO `molajo_extension_instances` VALUES(31, 31, 1150, 'edit-title', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 31);
INSERT INTO `molajo_extension_instances` VALUES(32, 32, 1150, 'edit-toolbar', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 32);
INSERT INTO `molajo_extension_instances` VALUES(33, 33, 1150, 'grid', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 33);
INSERT INTO `molajo_extension_instances` VALUES(34, 34, 1150, 'grid-batch', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 34);
INSERT INTO `molajo_extension_instances` VALUES(35, 35, 1150, 'grid-filters', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 35);
INSERT INTO `molajo_extension_instances` VALUES(36, 36, 1150, 'grid-pagination', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 36);
INSERT INTO `molajo_extension_instances` VALUES(37, 37, 1150, 'grid-submenu', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 37);
INSERT INTO `molajo_extension_instances` VALUES(38, 38, 1150, 'grid-table', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 38);
INSERT INTO `molajo_extension_instances` VALUES(39, 39, 1150, 'grid-title', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 39);
INSERT INTO `molajo_extension_instances` VALUES(40, 40, 1150, 'grid-toolbar', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 40);
INSERT INTO `molajo_extension_instances` VALUES(41, 41, 1150, 'page-header', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 41);
INSERT INTO `molajo_extension_instances` VALUES(42, 42, 1150, 'page-footer', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 42);
INSERT INTO `molajo_extension_instances` VALUES(43, 43, 1150, 'system-errors', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 43);
INSERT INTO `molajo_extension_instances` VALUES(44, 44, 1150, 'system-messages', 'extensions', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 44);
INSERT INTO `molajo_extension_instances` VALUES(45, 45, 1150, 'button', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 45);
INSERT INTO `molajo_extension_instances` VALUES(46, 46, 1150, 'colorpicker', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 46);
INSERT INTO `molajo_extension_instances` VALUES(47, 47, 1150, 'input', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 47);
INSERT INTO `molajo_extension_instances` VALUES(48, 48, 1150, 'media', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 48);
INSERT INTO `molajo_extension_instances` VALUES(49, 49, 1150, 'number', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 49);
INSERT INTO `molajo_extension_instances` VALUES(50, 50, 1150, 'option', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 50);
INSERT INTO `molajo_extension_instances` VALUES(51, 51, 1150, 'rules', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 51);
INSERT INTO `molajo_extension_instances` VALUES(52, 52, 1150, 'spacer', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 52);
INSERT INTO `molajo_extension_instances` VALUES(53, 53, 1150, 'textarea', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 53);
INSERT INTO `molajo_extension_instances` VALUES(54, 54, 1150, 'user', 'formfields', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 54);
INSERT INTO `molajo_extension_instances` VALUES(55, 55, 1150, 'default', 'pages', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 55);
INSERT INTO `molajo_extension_instances` VALUES(56, 56, 1150, 'system-error', 'pages', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 56);
INSERT INTO `molajo_extension_instances` VALUES(57, 57, 1150, 'system-offline', 'pages', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 57);
INSERT INTO `molajo_extension_instances` VALUES(58, 58, 1150, 'article', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 58);
INSERT INTO `molajo_extension_instances` VALUES(59, 59, 1150, 'aside', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 59);
INSERT INTO `molajo_extension_instances` VALUES(60, 60, 1150, 'default', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 60);
INSERT INTO `molajo_extension_instances` VALUES(61, 61, 1150, 'div', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 61);
INSERT INTO `molajo_extension_instances` VALUES(62, 62, 1150, 'footer', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 62);
INSERT INTO `molajo_extension_instances` VALUES(63, 63, 1150, 'header', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 63);
INSERT INTO `molajo_extension_instances` VALUES(64, 64, 1150, 'hgroup', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 64);
INSERT INTO `molajo_extension_instances` VALUES(65, 65, 1150, 'nav', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 65);
INSERT INTO `molajo_extension_instances` VALUES(66, 66, 1150, 'none', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 66);
INSERT INTO `molajo_extension_instances` VALUES(67, 67, 1150, 'section', 'wraps', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 67);
INSERT INTO `molajo_extension_instances` VALUES(82, 68, 1450, 'example', 'acl', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 68);
INSERT INTO `molajo_extension_instances` VALUES(83, 69, 1450, 'molajo', 'authentication', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 69);
INSERT INTO `molajo_extension_instances` VALUES(84, 70, 1450, 'none', 'editors', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 70);
INSERT INTO `molajo_extension_instances` VALUES(85, 71, 1450, 'article', 'editor-buttons', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 71);
INSERT INTO `molajo_extension_instances` VALUES(86, 72, 1450, 'editor', 'editor-buttons', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 72);
INSERT INTO `molajo_extension_instances` VALUES(87, 73, 1450, 'image', 'editor-buttons', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 73);
INSERT INTO `molajo_extension_instances` VALUES(88, 74, 1450, 'pagebreak', 'editor-buttons', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 74);
INSERT INTO `molajo_extension_instances` VALUES(89, 75, 1450, 'readmore', 'editor-buttons', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 75);
INSERT INTO `molajo_extension_instances` VALUES(90, 76, 1450, 'logout', 'system', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 76);
INSERT INTO `molajo_extension_instances` VALUES(91, 77, 1450, 'molajo', 'system', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 77);
INSERT INTO `molajo_extension_instances` VALUES(92, 78, 1450, 'remember', 'system', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 78);
INSERT INTO `molajo_extension_instances` VALUES(93, 79, 1450, 'system', 'system', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 79);
INSERT INTO `molajo_extension_instances` VALUES(94, 80, 1450, 'molajo', 'user', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 80);
INSERT INTO `molajo_extension_instances` VALUES(97, 81, 1500, 'cleanslate', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 81);
INSERT INTO `molajo_extension_instances` VALUES(98, 82, 1500, 'molajito', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 82);
INSERT INTO `molajo_extension_instances` VALUES(99, 83, 1500, 'system', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 83);
INSERT INTO `molajo_extension_instances` VALUES(100, 84, 1300, 'Administrator Menu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 84);
INSERT INTO `molajo_extension_instances` VALUES(101, 85, 1300, 'Main Menu', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 85);
INSERT INTO `molajo_extension_instances` VALUES(103, 86, 1350, 'assetwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 86);
INSERT INTO `molajo_extension_instances` VALUES(104, 87, 1350, 'aclwidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'idget', '{}', '{}', NULL, 'en-GB', 0, 87);
INSERT INTO `molajo_extension_instances` VALUES(105, 88, 1350, 'breadcrumbs', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'breadcrumbs', '{}', '{}', NULL, 'en-GB', 0, 88);
INSERT INTO `molajo_extension_instances` VALUES(106, 89, 1350, 'categorywidget', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 89);
INSERT INTO `molajo_extension_instances` VALUES(107, 90, 1350, 'content', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'content', '{}', '{}', NULL, 'en-GB', 0, 90);
INSERT INTO `molajo_extension_instances` VALUES(108, 91, 1350, 'custom', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'om', '{}', '{}', NULL, 'en-GB', 0, 91);
INSERT INTO `molajo_extension_instances` VALUES(109, 92, 1350, 'dashboard', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'dashboard', '{}', '{}', NULL, 'en-GB', 0, 92);
INSERT INTO `molajo_extension_instances` VALUES(110, 93, 1350, 'dashboard-module', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'dashboard-module', '{}', '{}', NULL, 'en-GB', 0, 93);
INSERT INTO `molajo_extension_instances` VALUES(111, 94, 1350, 'default', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'ult', '{}', '{}', NULL, 'en-GB', 0, 94);
INSERT INTO `molajo_extension_instances` VALUES(112, 95, 1350, 'document-defer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 95);
INSERT INTO `molajo_extension_instances` VALUES(113, 96, 1350, 'document-head', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 96);
INSERT INTO `molajo_extension_instances` VALUES(114, 97, 1350, 'dummy', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'y', '{}', '{}', NULL, 'en-GB', 0, 97);
INSERT INTO `molajo_extension_instances` VALUES(115, 98, 1350, 'page-header', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'header', '{}', '{}', NULL, 'en-GB', 0, 98);
INSERT INTO `molajo_extension_instances` VALUES(116, 99, 1350, 'page-footer', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, 'footer', '{}', '{}', NULL, 'en-GB', 0, 99);
INSERT INTO `molajo_extension_instances` VALUES(117, 100, 1350, 'system-errors', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 100);
INSERT INTO `molajo_extension_instances` VALUES(118, 101, 1350, 'system-messages', '', '', '', 1, 0, 0, 1, '2011-11-11 11:11:11', '0000-00-00 00:00:00', 1, 0, 0, '2011-11-11 11:11:11', 0, '2011-11-11 11:11:11', 0, '0000-00-00 00:00:00', 0, '', '{}', '{}', NULL, 'en-GB', 0, 101);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extension_options`
--

CREATE TABLE `molajo_extension_options` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `extension_instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `application_id` int(11) unsigned NOT NULL DEFAULT '0',
  `protected` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `option_id` int(11) unsigned NOT NULL DEFAULT '0',
  `option_value_literal` varchar(255) NOT NULL DEFAULT ' ',
  `option_value` varchar(80) NOT NULL DEFAULT ' ',
  `ordering` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Ordering',
  PRIMARY KEY (`id`),
  KEY `fk_extension_options_extension_instances_index` (`extension_instance_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=396 ;

--
-- Dumping data for table `molajo_extension_options`
--

INSERT INTO `molajo_extension_options` VALUES(1, 1, 0, 0, 100, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(2, 1, 0, 0, 100, '__content', '__content', 1);
INSERT INTO `molajo_extension_options` VALUES(3, 1, 0, 0, 200, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(4, 1, 0, 0, 200, 'FIELD_ALIAS_LABEL', 'alias', 1);
INSERT INTO `molajo_extension_options` VALUES(5, 1, 0, 0, 200, 'FIELD_ASSET_TYPE_ID_LABEL', 'asset_type_id', 2);
INSERT INTO `molajo_extension_options` VALUES(6, 1, 0, 0, 200, 'FIELD_CHECKED_OUT_BY_LABEL', 'checked_out_by', 3);
INSERT INTO `molajo_extension_options` VALUES(7, 1, 0, 0, 200, 'FIELD_CHECKED_OUT_DATETIME_LABEL', 'checked_out_datetime', 4);
INSERT INTO `molajo_extension_options` VALUES(8, 1, 0, 0, 200, 'FIELD_CONTENT_TEXT_LABEL', 'content_text', 5);
INSERT INTO `molajo_extension_options` VALUES(9, 1, 0, 0, 200, 'FIELD_CREATED_BY_LABEL', 'created_by', 6);
INSERT INTO `molajo_extension_options` VALUES(10, 1, 0, 0, 200, 'FIELD_CREATED_DATETIME_LABEL', 'created_datetime', 7);
INSERT INTO `molajo_extension_options` VALUES(11, 1, 0, 0, 200, 'FIELD_EXTENSION_EXTENSIONS_ID_LABEL', 'extension_instance_id', 8);
INSERT INTO `molajo_extension_options` VALUES(12, 1, 0, 0, 200, 'FIELD_FEATURED_LABEL', 'featured', 9);
INSERT INTO `molajo_extension_options` VALUES(13, 1, 0, 0, 200, 'FIELD_HOME_LABEL', 'home', 10);
INSERT INTO `molajo_extension_options` VALUES(14, 1, 0, 0, 200, 'FIELD_ID_LABEL', 'id', 11);
INSERT INTO `molajo_extension_options` VALUES(15, 1, 0, 0, 200, 'FIELD_LANGUAGE_LABEL', 'language', 12);
INSERT INTO `molajo_extension_options` VALUES(16, 1, 0, 0, 200, 'FIELD_LEFT_LABEL', 'lft', 13);
INSERT INTO `molajo_extension_options` VALUES(17, 1, 0, 0, 200, 'FIELD_LEVEL_LABEL', 'lvl', 14);
INSERT INTO `molajo_extension_options` VALUES(18, 1, 0, 0, 200, 'FIELD_MODIFIED_BY_LABEL', 'modified_by', 15);
INSERT INTO `molajo_extension_options` VALUES(19, 1, 0, 0, 200, 'FIELD_MODIFIED_DATETIME_LABEL', 'modified_datetime', 16);
INSERT INTO `molajo_extension_options` VALUES(20, 1, 0, 0, 200, 'FIELD_ORDERING_LABEL', 'ordering', 17);
INSERT INTO `molajo_extension_options` VALUES(21, 1, 0, 0, 200, 'FIELD_PARENT_ID_LABEL', 'parent_id', 18);
INSERT INTO `molajo_extension_options` VALUES(22, 1, 0, 0, 200, 'FIELD_PATH_LABEL', 'path', 19);
INSERT INTO `molajo_extension_options` VALUES(23, 1, 0, 0, 200, 'FIELD_POSITION_LABEL', 'position', 20);
INSERT INTO `molajo_extension_options` VALUES(24, 1, 0, 0, 200, 'FIELD_PROTECTED_LABEL', 'protected', 21);
INSERT INTO `molajo_extension_options` VALUES(25, 1, 0, 0, 200, 'FIELD_RIGHT_LABEL', 'rgt', 22);
INSERT INTO `molajo_extension_options` VALUES(26, 1, 0, 0, 200, 'FIELD_ROOT_LABEL', 'root', 23);
INSERT INTO `molajo_extension_options` VALUES(27, 1, 0, 0, 200, 'FIELD_START_PUBLISHING_DATETIME_LABEL', 'start_publishing_datetime', 24);
INSERT INTO `molajo_extension_options` VALUES(28, 1, 0, 0, 200, 'FIELD_STATUS_PRIOR_TO_VERSION_LABEL', 'status_prior_to_version', 25);
INSERT INTO `molajo_extension_options` VALUES(29, 1, 0, 0, 200, 'FIELD_STATUS_LABEL', 'status', 26);
INSERT INTO `molajo_extension_options` VALUES(30, 1, 0, 0, 200, 'FIELD_STICKIED_LABEL', 'stickied', 27);
INSERT INTO `molajo_extension_options` VALUES(31, 1, 0, 0, 200, 'FIELD_STOP_PUBLISHING_DATETIME_LABEL', 'stop_publishing_datetime', 28);
INSERT INTO `molajo_extension_options` VALUES(32, 1, 0, 0, 200, 'FIELD_SUBTITLE_LABEL', 'subtitle', 29);
INSERT INTO `molajo_extension_options` VALUES(33, 1, 0, 0, 200, 'FIELD_TITLE_LABEL', 'title', 30);
INSERT INTO `molajo_extension_options` VALUES(34, 1, 0, 0, 200, 'FIELD_TRANSLATION_OF_ID_LABEL', 'translation_of_id', 31);
INSERT INTO `molajo_extension_options` VALUES(35, 1, 0, 0, 200, 'FIELD_VERSION_OF_ID_LABEL', 'version_of_id', 32);
INSERT INTO `molajo_extension_options` VALUES(36, 1, 0, 0, 200, 'FIELD_VERSION_LABEL', 'version', 33);
INSERT INTO `molajo_extension_options` VALUES(37, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_IMAGE1_LABEL', 'custom_fields_image1_label', 34);
INSERT INTO `molajo_extension_options` VALUES(38, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_IMAGE1_FILE', 'custom_fields_image1_file', 35);
INSERT INTO `molajo_extension_options` VALUES(39, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_IMAGE1_CREDIT', 'custom_fields_image1_credit', 36);
INSERT INTO `molajo_extension_options` VALUES(40, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_LINK1_LABEL', 'custom_fields_link1_label', 37);
INSERT INTO `molajo_extension_options` VALUES(41, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_LINK1_FILE', 'custom_fields_link1_url', 38);
INSERT INTO `molajo_extension_options` VALUES(42, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_VIDEO1_LABEL', 'custom_fields_video1_label', 39);
INSERT INTO `molajo_extension_options` VALUES(43, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_VIDEO1_URL', 'custom_fields_video1_url', 40);
INSERT INTO `molajo_extension_options` VALUES(44, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_AUDIO1_LABEL', 'custom_fields_audio1_label', 41);
INSERT INTO `molajo_extension_options` VALUES(45, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_AUDIO1_URL', 'custom_fields_audio1_url', 42);
INSERT INTO `molajo_extension_options` VALUES(46, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_FILE1_LABEL', 'custom_fields_file1_label', 43);
INSERT INTO `molajo_extension_options` VALUES(47, 1, 0, 0, 200, 'FIELD_CUSTOM_FIELDS_FILE1_URL', 'custom_fields_file1_url', 44);
INSERT INTO `molajo_extension_options` VALUES(48, 1, 0, 0, 200, 'FIELD_METADATA_TITLE', 'metadata_title', 45);
INSERT INTO `molajo_extension_options` VALUES(49, 1, 0, 0, 200, 'FIELD_METADATA_AUTHOR', 'metadata_author', 45);
INSERT INTO `molajo_extension_options` VALUES(50, 1, 0, 0, 200, 'FIELD_METADATA_CONTENT_RIGHTS', 'metadata_content_rights', 46);
INSERT INTO `molajo_extension_options` VALUES(51, 1, 0, 0, 200, 'FIELD_METADATA_DESCRIPTION', 'metadata_description', 47);
INSERT INTO `molajo_extension_options` VALUES(52, 1, 0, 0, 200, 'FIELD_METADATA_KEYWORDS', 'metadata_keywords', 48);
INSERT INTO `molajo_extension_options` VALUES(53, 1, 0, 0, 200, 'FIELD_METADATA_ROBOTS', 'metadata_robots', 49);
INSERT INTO `molajo_extension_options` VALUES(54, 1, 0, 0, 200, '', 'template_id', 50);
INSERT INTO `molajo_extension_options` VALUES(55, 1, 0, 0, 200, '', 'page_id', 51);
INSERT INTO `molajo_extension_options` VALUES(56, 1, 0, 0, 200, '', 'view_id', 52);
INSERT INTO `molajo_extension_options` VALUES(57, 1, 0, 0, 200, '', 'wrap_id', 53);
INSERT INTO `molajo_extension_options` VALUES(58, 1, 0, 0, 200, 'FIELD_CATEGORY_ID_PRIMARY', 'category_id_primary', 54);
INSERT INTO `molajo_extension_options` VALUES(59, 1, 0, 0, 200, 'FIELD_CATEGORY_ID_LIST', 'category_id_list', 55);
INSERT INTO `molajo_extension_options` VALUES(60, 1, 0, 0, 200, 'FIELD_CATEGORY_ID_TAGS', 'category_id_tags', 56);
INSERT INTO `molajo_extension_options` VALUES(61, 1, 0, 0, 200, 'FIELD_GROUP_ID_LIST_VIEW_ACTION', 'group_id_list_view_action', 57);
INSERT INTO `molajo_extension_options` VALUES(62, 1, 0, 0, 200, 'FIELD_GROUP_ID_LIST_CREATE_ACTION', 'group_id_list_create_action', 58);
INSERT INTO `molajo_extension_options` VALUES(63, 1, 0, 0, 200, 'FIELD_GROUP_ID_LIST_EDIT_ACTION', 'group_id_list_edit_action', 59);
INSERT INTO `molajo_extension_options` VALUES(64, 1, 0, 0, 200, 'FIELD_GROUP_ID_LIST_PUBLISH_ACTION', 'group_id_list_publish_action', 60);
INSERT INTO `molajo_extension_options` VALUES(65, 1, 0, 0, 200, 'FIELD_GROUP_ID_LIST_DELETE_ACTION', 'group_id_list_delete_action', 61);
INSERT INTO `molajo_extension_options` VALUES(66, 1, 0, 0, 200, 'FIELD_GROUP_ID_LIST_ADMINISTER_ACTION', 'group_id_list_administer_action', 62);
INSERT INTO `molajo_extension_options` VALUES(67, 1, 0, 0, 205, 'FIELD_ASSETS_ID', 'assets_id', 63);
INSERT INTO `molajo_extension_options` VALUES(68, 1, 0, 0, 205, 'FIELD_ASSET_TYPE_ID', 'assets_asset_type_id', 64);
INSERT INTO `molajo_extension_options` VALUES(69, 1, 0, 0, 205, 'FIELD_ASSETS_SOURCE_ID', 'assets_source_id', 65);
INSERT INTO `molajo_extension_options` VALUES(70, 1, 0, 0, 205, 'FIELD_ASSETS_ROUTABLE', 'assets_routable', 66);
INSERT INTO `molajo_extension_options` VALUES(71, 1, 0, 0, 205, 'FIELD_ASSETS_SEF_REQUEST', 'assets_sef_request', 67);
INSERT INTO `molajo_extension_options` VALUES(72, 1, 0, 0, 205, 'FIELD_ASSETS_REQUEST', 'assets_request', 68);
INSERT INTO `molajo_extension_options` VALUES(73, 1, 0, 0, 205, 'FIELD_ASSETS_OPTION', 'assets_request_option', 69);
INSERT INTO `molajo_extension_options` VALUES(74, 1, 0, 0, 205, 'FIELD_ASSETS_MODEL', 'assets_request_model', 70);
INSERT INTO `molajo_extension_options` VALUES(75, 1, 0, 0, 205, 'FIELD_ASSETS_REDIRECT_TO_ID', 'assets_redirect_to_id', 71);
INSERT INTO `molajo_extension_options` VALUES(76, 1, 0, 0, 205, 'FIELD_ASSETS_VIEW_GROUP_ID', 'assets_view_group_id', 72);
INSERT INTO `molajo_extension_options` VALUES(77, 1, 0, 0, 205, 'FIELD_ASSETS_PRIMARY_CATEGORY_ID', 'assets_primary_category_id', 73);
INSERT INTO `molajo_extension_options` VALUES(78, 1, 0, 0, 205, 'FIELD_ASSET_TYPES_COMPONENT_OPTION', 'asset_types_component_option', 76);
INSERT INTO `molajo_extension_options` VALUES(79, 1, 0, 0, 205, 'FIELD_ASSET_TYPES_ID', 'asset_types_id', 77);
INSERT INTO `molajo_extension_options` VALUES(80, 1, 0, 0, 205, 'FIELD_ASSET_TYPES_PROTECTED', 'asset_types_protected', 78);
INSERT INTO `molajo_extension_options` VALUES(81, 1, 0, 0, 205, 'FIELD_ASSET_TYPES_SOURCE_TABLE', 'asset_types_source_table', 79);
INSERT INTO `molajo_extension_options` VALUES(82, 1, 0, 0, 205, 'FIELD_ASSET_TYPES_TITLE', 'asset_types_title', 80);
INSERT INTO `molajo_extension_options` VALUES(83, 1, 0, 0, 210, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(84, 1, 0, 0, 210, 'FIELD_FEATURED', 'featured', 1);
INSERT INTO `molajo_extension_options` VALUES(85, 1, 0, 0, 210, 'FIELD_GROUPS_ADMINISTER_ACTION', 'groups_administer_action', 2);
INSERT INTO `molajo_extension_options` VALUES(86, 1, 0, 0, 210, 'FIELD_GROUPS_CREATE_ACTION', 'groups_create_action', 3);
INSERT INTO `molajo_extension_options` VALUES(87, 1, 0, 0, 210, 'FIELD_GROUPS_DELETE_ACTION', 'groups_delete_action', 4);
INSERT INTO `molajo_extension_options` VALUES(88, 1, 0, 0, 210, 'FIELD_GROUPS_EDIT_ACTION', 'groups_edit_action', 5);
INSERT INTO `molajo_extension_options` VALUES(89, 1, 0, 0, 210, 'FIELD_GROUPS_PUBLISH_ACTION', 'groups_publish_action', 6);
INSERT INTO `molajo_extension_options` VALUES(90, 1, 0, 0, 210, 'FIELD_GROUPS_VIEW_ACTION', 'groups_view_action', 7);
INSERT INTO `molajo_extension_options` VALUES(91, 1, 0, 0, 210, 'FIELD_ORDERING', 'ordering', 8);
INSERT INTO `molajo_extension_options` VALUES(92, 1, 0, 0, 210, 'FIELD_START_PUBLISHING_DATETIME', 'start_publishing_datetime', 9);
INSERT INTO `molajo_extension_options` VALUES(93, 1, 0, 0, 210, 'FIELD_STATUS', 'status', 10);
INSERT INTO `molajo_extension_options` VALUES(94, 1, 0, 0, 210, 'FIELD_STICKIED', 'stickied', 11);
INSERT INTO `molajo_extension_options` VALUES(95, 1, 0, 0, 210, 'FIELD_STOP_PUBLISHING_DATETIME', 'stop_publishing_datetime', 12);
INSERT INTO `molajo_extension_options` VALUES(96, 1, 0, 0, 220, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(97, 1, 0, 0, 220, 'FIELD_JSON_CUSTOM_FIELDS', 'custom_fields', 1);
INSERT INTO `molajo_extension_options` VALUES(98, 1, 0, 0, 220, 'FIELD_JSON_METADATA', 'metadata', 2);
INSERT INTO `molajo_extension_options` VALUES(99, 1, 0, 0, 220, 'FIELD_JSON_PARAMETERS', 'parameters', 3);
INSERT INTO `molajo_extension_options` VALUES(100, 1, 0, 0, 250, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(101, 1, 0, 0, 250, 'MOLAJO_OPTION_STATUS_ARCHIVED', '2', 1);
INSERT INTO `molajo_extension_options` VALUES(102, 1, 0, 0, 250, 'MOLAJO_OPTION_STATUS_PUBLISHED', '1', 2);
INSERT INTO `molajo_extension_options` VALUES(103, 1, 0, 0, 250, 'MOLAJO_OPTION_STATUS_UNPUBLISHED', '0', 3);
INSERT INTO `molajo_extension_options` VALUES(104, 1, 0, 0, 250, 'MOLAJO_OPTION_STATUS_TRASHED', '-1', 4);
INSERT INTO `molajo_extension_options` VALUES(105, 1, 0, 0, 250, 'MOLAJO_OPTION_STATUS_SPAMMED', '-2', 5);
INSERT INTO `molajo_extension_options` VALUES(106, 1, 0, 0, 250, 'MOLAJO_OPTION_STATUS_VERSION', '-10', 6);
INSERT INTO `molajo_extension_options` VALUES(107, 1, 0, 0, 250, 'MOLAJO_OPTION_STATUS_DRAFT', '-11', 7);
INSERT INTO `molajo_extension_options` VALUES(108, 1, 0, 0, 300, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(109, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_ARCHIVE', 'archive', 1);
INSERT INTO `molajo_extension_options` VALUES(110, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_CHECKIN', 'checkin', 2);
INSERT INTO `molajo_extension_options` VALUES(111, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_DELETE', 'delete', 3);
INSERT INTO `molajo_extension_options` VALUES(112, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_EDIT', 'edit', 4);
INSERT INTO `molajo_extension_options` VALUES(113, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_FEATURE', 'feature', 5);
INSERT INTO `molajo_extension_options` VALUES(114, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_HELP', 'help', 6);
INSERT INTO `molajo_extension_options` VALUES(115, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_NEW', 'new', 7);
INSERT INTO `molajo_extension_options` VALUES(116, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_PUBLISH', 'publish', 8);
INSERT INTO `molajo_extension_options` VALUES(117, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_RESTORE', 'restore', 9);
INSERT INTO `molajo_extension_options` VALUES(118, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_SEPARATOR', 'separator', 10);
INSERT INTO `molajo_extension_options` VALUES(119, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_SPAM', 'spam', 11);
INSERT INTO `molajo_extension_options` VALUES(120, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_STICKY', 'sticky', 12);
INSERT INTO `molajo_extension_options` VALUES(121, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_TRASH', 'trash', 13);
INSERT INTO `molajo_extension_options` VALUES(122, 1, 0, 0, 300, 'MOLAJO_OPTION_TOOLBAR_BUTTON_UNPUBLISH', 'unpublish', 14);
INSERT INTO `molajo_extension_options` VALUES(123, 1, 0, 0, 310, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(124, 1, 0, 0, 310, 'MOLAJO_SUBMENU_DEFAULT', 'default', 1);
INSERT INTO `molajo_extension_options` VALUES(125, 1, 0, 0, 310, 'MOLAJO_SUBMENU_DRAFTS', 'drafts', 2);
INSERT INTO `molajo_extension_options` VALUES(126, 1, 0, 0, 310, 'MOLAJO_SUBMENU_FEATURED', 'featured', 3);
INSERT INTO `molajo_extension_options` VALUES(127, 1, 0, 0, 310, 'MOLAJO_SUBMENU_VERSIONS', 'versions', 4);
INSERT INTO `molajo_extension_options` VALUES(128, 1, 0, 0, 310, 'MOLAJO_SUBMENU_STICKIED', 'stickied', 5);
INSERT INTO `molajo_extension_options` VALUES(129, 1, 0, 0, 310, 'MOLAJO_SUBMENU_STICKIED', 'published', 6);
INSERT INTO `molajo_extension_options` VALUES(130, 1, 0, 0, 310, 'MOLAJO_SUBMENU_UNPUBLISHED', 'unpublished', 7);
INSERT INTO `molajo_extension_options` VALUES(131, 1, 0, 0, 320, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(132, 1, 0, 0, 320, 'FIELD_ALIAS_LABEL', 'alias', 1);
INSERT INTO `molajo_extension_options` VALUES(133, 1, 0, 0, 320, 'FIELD_CATEGORY_ID_PRIMARY', 'category_id_primary', 2);
INSERT INTO `molajo_extension_options` VALUES(134, 1, 0, 0, 320, 'FIELD_CATEGORY_ID_LIST', 'category_id_list', 3);
INSERT INTO `molajo_extension_options` VALUES(135, 1, 0, 0, 320, 'FIELD_CATEGORY_ID_TAGS', 'category_id_tags', 4);
INSERT INTO `molajo_extension_options` VALUES(136, 1, 0, 0, 320, 'FIELD_CREATED_BY_LABEL', 'created_by', 5);
INSERT INTO `molajo_extension_options` VALUES(137, 1, 0, 0, 320, 'FIELD_CREATED_DATETIME_LABEL', 'created_datetime', 6);
INSERT INTO `molajo_extension_options` VALUES(138, 1, 0, 0, 320, 'FIELD_FEATURED_LABEL', 'featured', 7);
INSERT INTO `molajo_extension_options` VALUES(139, 1, 0, 0, 320, 'FIELD_GROUPS_ADMINISTER_ACTION', 'groups_administer_action', 8);
INSERT INTO `molajo_extension_options` VALUES(140, 1, 0, 0, 320, 'FIELD_GROUPS_CREATE_ACTION', 'groups_create_action', 9);
INSERT INTO `molajo_extension_options` VALUES(141, 1, 0, 0, 320, 'FIELD_GROUPS_DELETE_ACTION', 'groups_delete_action', 10);
INSERT INTO `molajo_extension_options` VALUES(142, 1, 0, 0, 320, 'FIELD_GROUPS_EDIT_ACTION', 'groups_edit_action', 11);
INSERT INTO `molajo_extension_options` VALUES(143, 1, 0, 0, 320, 'FIELD_GROUPS_PUBLISH_ACTION', 'groups_publish_action', 12);
INSERT INTO `molajo_extension_options` VALUES(144, 1, 0, 0, 320, 'FIELD_GROUPS_VIEW_ACTION', 'groups_view_action', 13);
INSERT INTO `molajo_extension_options` VALUES(145, 1, 0, 0, 320, 'FIELD_LANGUAGE_LABEL', 'language', 14);
INSERT INTO `molajo_extension_options` VALUES(146, 1, 0, 0, 320, 'FIELD_MODIFIED_BY_LABEL', 'modified_by', 15);
INSERT INTO `molajo_extension_options` VALUES(147, 1, 0, 0, 320, 'FIELD_MODIFIED_DATETIME_LABEL', 'modified_datetime', 16);
INSERT INTO `molajo_extension_options` VALUES(148, 1, 0, 0, 320, 'FIELD_PATH_LABEL', 'path', 17);
INSERT INTO `molajo_extension_options` VALUES(149, 1, 0, 0, 320, 'FIELD_POSITION_LABEL', 'position', 18);
INSERT INTO `molajo_extension_options` VALUES(150, 1, 0, 0, 320, 'FIELD_START_PUBLISHING_DATETIME_LABEL', 'start_publishing_datetime', 19);
INSERT INTO `molajo_extension_options` VALUES(151, 1, 0, 0, 320, 'FIELD_STATUS_LABEL', 'status', 20);
INSERT INTO `molajo_extension_options` VALUES(152, 1, 0, 0, 320, 'FIELD_STICKIED_LABEL', 'stickied', 21);
INSERT INTO `molajo_extension_options` VALUES(153, 1, 0, 0, 320, 'FIELD_STOP_PUBLISHING_DATETIME_LABEL', 'stop_publishing_datetime', 22);
INSERT INTO `molajo_extension_options` VALUES(154, 1, 0, 0, 320, 'FIELD_SUBTITLE_LABEL', 'subtitle', 23);
INSERT INTO `molajo_extension_options` VALUES(155, 1, 0, 0, 320, 'FIELD_TITLE_LABEL', 'title', 24);
INSERT INTO `molajo_extension_options` VALUES(156, 1, 0, 0, 330, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(157, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_APPLY', 'apply', 1);
INSERT INTO `molajo_extension_options` VALUES(158, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_CLOSE', 'close', 2);
INSERT INTO `molajo_extension_options` VALUES(159, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_HELP', 'help', 3);
INSERT INTO `molajo_extension_options` VALUES(160, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_RESTORE', 'restore', 4);
INSERT INTO `molajo_extension_options` VALUES(161, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_SAVE', 'save', 5);
INSERT INTO `molajo_extension_options` VALUES(162, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_SAVEANDNEW', 'saveandnew', 6);
INSERT INTO `molajo_extension_options` VALUES(163, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_SAVEASCOPY', 'saveascopy', 7);
INSERT INTO `molajo_extension_options` VALUES(164, 1, 0, 0, 330, 'MOLAJO_OPTION_TOOLBAR_BUTTON_SEPARATOR', 'separator', 8);
INSERT INTO `molajo_extension_options` VALUES(165, 1, 0, 0, 340, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(166, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_ARTICLE', 'article', 1);
INSERT INTO `molajo_extension_options` VALUES(167, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_AUDIO', 'audio', 2);
INSERT INTO `molajo_extension_options` VALUES(168, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_FILE', 'file', 3);
INSERT INTO `molajo_extension_options` VALUES(169, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_GALLERY', 'gallery', 4);
INSERT INTO `molajo_extension_options` VALUES(170, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_IMAGE', 'image', 5);
INSERT INTO `molajo_extension_options` VALUES(171, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_PAGEBREAK', 'pagebreak', 6);
INSERT INTO `molajo_extension_options` VALUES(172, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_READMORE', 'readmore', 7);
INSERT INTO `molajo_extension_options` VALUES(173, 1, 0, 0, 340, 'MANAGER_EDITOR_BUTTON_VIDEO', 'video', 8);
INSERT INTO `molajo_extension_options` VALUES(174, 1, 0, 0, 400, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(175, 1, 0, 0, 400, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 1);
INSERT INTO `molajo_extension_options` VALUES(176, 1, 0, 0, 400, 'sp-midi', 'sp-midi', 2);
INSERT INTO `molajo_extension_options` VALUES(177, 1, 0, 0, 400, 'vnd.3gpp.iufp', 'vnd.3gpp.iufp', 3);
INSERT INTO `molajo_extension_options` VALUES(178, 1, 0, 0, 400, 'vnd.4SB', 'vnd.4SB', 4);
INSERT INTO `molajo_extension_options` VALUES(179, 1, 0, 0, 400, 'vnd.CELP', 'vnd.CELP', 5);
INSERT INTO `molajo_extension_options` VALUES(180, 1, 0, 0, 400, 'vnd.audiokoz', 'vnd.audiokoz', 6);
INSERT INTO `molajo_extension_options` VALUES(181, 1, 0, 0, 400, 'vnd.cisco.nse', 'vnd.cisco.nse', 7);
INSERT INTO `molajo_extension_options` VALUES(182, 1, 0, 0, 400, 'vnd.cmles.radio-events', 'vnd.cmles.radio-events', 8);
INSERT INTO `molajo_extension_options` VALUES(183, 1, 0, 0, 400, 'vnd.cns.anp1', 'vnd.cns.anp1', 9);
INSERT INTO `molajo_extension_options` VALUES(184, 1, 0, 0, 400, 'vnd.cns.inf1', 'vnd.cns.inf1', 10);
INSERT INTO `molajo_extension_options` VALUES(185, 1, 0, 0, 400, 'vnd.dece.audio', 'vnd.dece.audio', 11);
INSERT INTO `molajo_extension_options` VALUES(186, 1, 0, 0, 400, 'vnd.digital-winds', 'vnd.digital-winds', 12);
INSERT INTO `molajo_extension_options` VALUES(187, 1, 0, 0, 400, 'vnd.dlna.adts', 'vnd.dlna.adts', 13);
INSERT INTO `molajo_extension_options` VALUES(188, 1, 0, 0, 400, 'vnd.dolby.heaac.1', 'vnd.dolby.heaac.1', 14);
INSERT INTO `molajo_extension_options` VALUES(189, 1, 0, 0, 400, 'vnd.dolby.heaac.2', 'vnd.dolby.heaac.2', 15);
INSERT INTO `molajo_extension_options` VALUES(190, 1, 0, 0, 400, 'vnd.dolby.mlp', 'vnd.dolby.mlp', 16);
INSERT INTO `molajo_extension_options` VALUES(191, 1, 0, 0, 400, 'vnd.dolby.mps', 'vnd.dolby.mps', 17);
INSERT INTO `molajo_extension_options` VALUES(192, 1, 0, 0, 400, 'vnd.dolby.pl2', 'vnd.dolby.pl2', 18);
INSERT INTO `molajo_extension_options` VALUES(193, 1, 0, 0, 400, 'vnd.dolby.pl2x', 'vnd.dolby.pl2x', 19);
INSERT INTO `molajo_extension_options` VALUES(194, 1, 0, 0, 400, 'vnd.dolby.pl2z', 'vnd.dolby.pl2z', 20);
INSERT INTO `molajo_extension_options` VALUES(195, 1, 0, 0, 400, 'vnd.dolby.pulse.1', 'vnd.dolby.pulse.1', 21);
INSERT INTO `molajo_extension_options` VALUES(196, 1, 0, 0, 400, 'vnd.dra', 'vnd.dra', 22);
INSERT INTO `molajo_extension_options` VALUES(197, 1, 0, 0, 400, 'vnd.dts', 'vnd.dts', 23);
INSERT INTO `molajo_extension_options` VALUES(198, 1, 0, 0, 400, 'vnd.dts.hd', 'vnd.dts.hd', 24);
INSERT INTO `molajo_extension_options` VALUES(199, 1, 0, 0, 400, 'vnd.dvb.file', 'vnd.dvb.file', 25);
INSERT INTO `molajo_extension_options` VALUES(200, 1, 0, 0, 400, 'vnd.everad.plj', 'vnd.everad.plj', 26);
INSERT INTO `molajo_extension_options` VALUES(201, 1, 0, 0, 400, 'vnd.hns.audio', 'vnd.hns.audio', 27);
INSERT INTO `molajo_extension_options` VALUES(202, 1, 0, 0, 400, 'vnd.lucent.voice', 'vnd.lucent.voice', 28);
INSERT INTO `molajo_extension_options` VALUES(203, 1, 0, 0, 400, 'vnd.ms-playready.media.pya', 'vnd.ms-playready.media.pya', 29);
INSERT INTO `molajo_extension_options` VALUES(204, 1, 0, 0, 400, 'vnd.nokia.mobile-xmf', 'vnd.nokia.mobile-xmf', 30);
INSERT INTO `molajo_extension_options` VALUES(205, 1, 0, 0, 400, 'vnd.nortel.vbk', 'vnd.nortel.vbk', 31);
INSERT INTO `molajo_extension_options` VALUES(206, 1, 0, 0, 400, 'vnd.nuera.ecelp4800', 'vnd.nuera.ecelp4800', 32);
INSERT INTO `molajo_extension_options` VALUES(207, 1, 0, 0, 400, 'vnd.nuera.ecelp7470', 'vnd.nuera.ecelp7470', 33);
INSERT INTO `molajo_extension_options` VALUES(208, 1, 0, 0, 400, 'vnd.nuera.ecelp9600', 'vnd.nuera.ecelp9600', 34);
INSERT INTO `molajo_extension_options` VALUES(209, 1, 0, 0, 400, 'vnd.octel.sbc', 'vnd.octel.sbc', 35);
INSERT INTO `molajo_extension_options` VALUES(210, 1, 0, 0, 400, 'vnd.qcelp', 'vnd.qcelp', 36);
INSERT INTO `molajo_extension_options` VALUES(211, 1, 0, 0, 400, 'vnd.rhetorex.32kadpcm', 'vnd.rhetorex.32kadpcm', 37);
INSERT INTO `molajo_extension_options` VALUES(212, 1, 0, 0, 400, 'vnd.rip', 'vnd.rip', 38);
INSERT INTO `molajo_extension_options` VALUES(213, 1, 0, 0, 400, 'vnd.sealedmedia.softseal-mpeg', 'vnd.sealedmedia.softseal-mpeg', 39);
INSERT INTO `molajo_extension_options` VALUES(214, 1, 0, 0, 400, 'vnd.vmx.cvsd', 'vnd.vmx.cvsd', 40);
INSERT INTO `molajo_extension_options` VALUES(215, 1, 0, 0, 410, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(216, 1, 0, 0, 410, 'cgm', 'cgm', 1);
INSERT INTO `molajo_extension_options` VALUES(217, 1, 0, 0, 410, 'jp2', 'jp2', 2);
INSERT INTO `molajo_extension_options` VALUES(218, 1, 0, 0, 410, 'jpm', 'jpm', 3);
INSERT INTO `molajo_extension_options` VALUES(219, 1, 0, 0, 410, 'jpx', 'jpx', 4);
INSERT INTO `molajo_extension_options` VALUES(220, 1, 0, 0, 410, 'naplps', 'naplps', 5);
INSERT INTO `molajo_extension_options` VALUES(221, 1, 0, 0, 410, 'png', 'png', 6);
INSERT INTO `molajo_extension_options` VALUES(222, 1, 0, 0, 410, 'prs.btif', 'prs.btif', 7);
INSERT INTO `molajo_extension_options` VALUES(223, 1, 0, 0, 410, 'prs.pti', 'prs.pti', 8);
INSERT INTO `molajo_extension_options` VALUES(224, 1, 0, 0, 410, 'vnd-djvu', 'vnd-djvu', 9);
INSERT INTO `molajo_extension_options` VALUES(225, 1, 0, 0, 410, 'vnd-svf', 'vnd-svf', 10);
INSERT INTO `molajo_extension_options` VALUES(226, 1, 0, 0, 410, 'vnd-wap-wbmp', 'vnd-wap-wbmp', 11);
INSERT INTO `molajo_extension_options` VALUES(227, 1, 0, 0, 410, 'vnd.adobe.photoshop', 'vnd.adobe.photoshop', 12);
INSERT INTO `molajo_extension_options` VALUES(228, 1, 0, 0, 410, 'vnd.cns.inf2', 'vnd.cns.inf2', 13);
INSERT INTO `molajo_extension_options` VALUES(229, 1, 0, 0, 410, 'vnd.dece.graphic', 'vnd.dece.graphic', 14);
INSERT INTO `molajo_extension_options` VALUES(230, 1, 0, 0, 410, 'vnd.dvb.subtitle', 'vnd.dvb.subtitle', 15);
INSERT INTO `molajo_extension_options` VALUES(231, 1, 0, 0, 410, 'vnd.dwg', 'vnd.dwg', 16);
INSERT INTO `molajo_extension_options` VALUES(232, 1, 0, 0, 410, 'vnd.dxf', 'vnd.dxf', 17);
INSERT INTO `molajo_extension_options` VALUES(233, 1, 0, 0, 410, 'vnd.fastbidsheet', 'vnd.fastbidsheet', 18);
INSERT INTO `molajo_extension_options` VALUES(234, 1, 0, 0, 410, 'vnd.fpx', 'vnd.fpx', 19);
INSERT INTO `molajo_extension_options` VALUES(235, 1, 0, 0, 410, 'vnd.fst', 'vnd.fst', 20);
INSERT INTO `molajo_extension_options` VALUES(236, 1, 0, 0, 410, 'vnd.fujixerox.edmics-mmr', 'vnd.fujixerox.edmics-mmr', 21);
INSERT INTO `molajo_extension_options` VALUES(237, 1, 0, 0, 410, 'vnd.fujixerox.edmics-rlc', 'vnd.fujixerox.edmics-rlc', 22);
INSERT INTO `molajo_extension_options` VALUES(238, 1, 0, 0, 410, 'vnd.globalgraphics.pgb', 'vnd.globalgraphics.pgb', 23);
INSERT INTO `molajo_extension_options` VALUES(239, 1, 0, 0, 410, 'vnd.microsoft.icon', 'vnd.microsoft.icon', 24);
INSERT INTO `molajo_extension_options` VALUES(240, 1, 0, 0, 410, 'vnd.mix', 'vnd.mix', 25);
INSERT INTO `molajo_extension_options` VALUES(241, 1, 0, 0, 410, 'vnd.ms-modi', 'vnd.ms-modi', 26);
INSERT INTO `molajo_extension_options` VALUES(242, 1, 0, 0, 410, 'vnd.net-fpx', 'vnd.net-fpx', 27);
INSERT INTO `molajo_extension_options` VALUES(243, 1, 0, 0, 410, 'vnd.radiance', 'vnd.radiance', 28);
INSERT INTO `molajo_extension_options` VALUES(244, 1, 0, 0, 410, 'vnd.sealed-png', 'vnd.sealed-png', 29);
INSERT INTO `molajo_extension_options` VALUES(245, 1, 0, 0, 410, 'vnd.sealedmedia.softseal-gif', 'vnd.sealedmedia.softseal-gif', 30);
INSERT INTO `molajo_extension_options` VALUES(246, 1, 0, 0, 410, 'vnd.sealedmedia.softseal-jpg', 'vnd.sealedmedia.softseal-jpg', 31);
INSERT INTO `molajo_extension_options` VALUES(247, 1, 0, 0, 410, 'vnd.xiff', 'vnd.xiff', 32);
INSERT INTO `molajo_extension_options` VALUES(248, 1, 0, 0, 420, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(249, 1, 0, 0, 420, 'n3', 'n3', 1);
INSERT INTO `molajo_extension_options` VALUES(250, 1, 0, 0, 420, 'prs.fallenstein.rst', 'prs.fallenstein.rst', 2);
INSERT INTO `molajo_extension_options` VALUES(251, 1, 0, 0, 420, 'prs.lines.tag', 'prs.lines.tag', 3);
INSERT INTO `molajo_extension_options` VALUES(252, 1, 0, 0, 420, 'rtf', 'rtf', 4);
INSERT INTO `molajo_extension_options` VALUES(253, 1, 0, 0, 420, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 5);
INSERT INTO `molajo_extension_options` VALUES(254, 1, 0, 0, 420, 'tab-separated-values', 'tab-separated-values', 6);
INSERT INTO `molajo_extension_options` VALUES(255, 1, 0, 0, 420, 'turtle', 'turtle', 7);
INSERT INTO `molajo_extension_options` VALUES(256, 1, 0, 0, 420, 'vnd-curl', 'vnd-curl', 8);
INSERT INTO `molajo_extension_options` VALUES(257, 1, 0, 0, 420, 'vnd.DMClientScript', 'vnd.DMClientScript', 9);
INSERT INTO `molajo_extension_options` VALUES(258, 1, 0, 0, 420, 'vnd.IPTC.NITF', 'vnd.IPTC.NITF', 10);
INSERT INTO `molajo_extension_options` VALUES(259, 1, 0, 0, 420, 'vnd.IPTC.NewsML', 'vnd.IPTC.NewsML', 11);
INSERT INTO `molajo_extension_options` VALUES(260, 1, 0, 0, 420, 'vnd.abc', 'vnd.abc', 12);
INSERT INTO `molajo_extension_options` VALUES(261, 1, 0, 0, 420, 'vnd.curl', 'vnd.curl', 13);
INSERT INTO `molajo_extension_options` VALUES(262, 1, 0, 0, 420, 'vnd.dvb.subtitle', 'vnd.dvb.subtitle', 14);
INSERT INTO `molajo_extension_options` VALUES(263, 1, 0, 0, 420, 'vnd.esmertec.theme-descriptor', 'vnd.esmertec.theme-descriptor', 15);
INSERT INTO `molajo_extension_options` VALUES(264, 1, 0, 0, 420, 'vnd.fly', 'vnd.fly', 16);
INSERT INTO `molajo_extension_options` VALUES(265, 1, 0, 0, 420, 'vnd.fmi.flexstor', 'vnd.fmi.flexstor', 17);
INSERT INTO `molajo_extension_options` VALUES(266, 1, 0, 0, 420, 'vnd.graphviz', 'vnd.graphviz', 18);
INSERT INTO `molajo_extension_options` VALUES(267, 1, 0, 0, 420, 'vnd.in3d.3dml', 'vnd.in3d.3dml', 19);
INSERT INTO `molajo_extension_options` VALUES(268, 1, 0, 0, 420, 'vnd.in3d.spot', 'vnd.in3d.spot', 20);
INSERT INTO `molajo_extension_options` VALUES(269, 1, 0, 0, 420, 'vnd.latex-z', 'vnd.latex-z', 21);
INSERT INTO `molajo_extension_options` VALUES(270, 1, 0, 0, 420, 'vnd.motorola.reflex', 'vnd.motorola.reflex', 22);
INSERT INTO `molajo_extension_options` VALUES(271, 1, 0, 0, 420, 'vnd.ms-mediapackage', 'vnd.ms-mediapackage', 23);
INSERT INTO `molajo_extension_options` VALUES(272, 1, 0, 0, 420, 'vnd.net2phone.commcenter.command', 'vnd.net2phone.commcenter.command', 24);
INSERT INTO `molajo_extension_options` VALUES(273, 1, 0, 0, 420, 'vnd.si.uricatalogue', 'vnd.si.uricatalogue', 25);
INSERT INTO `molajo_extension_options` VALUES(274, 1, 0, 0, 420, 'vnd.sun.j2me.app-descriptor', 'vnd.sun.j2me.app-descriptor', 26);
INSERT INTO `molajo_extension_options` VALUES(275, 1, 0, 0, 420, 'vnd.trolltech.linguist', 'vnd.trolltech.linguist', 27);
INSERT INTO `molajo_extension_options` VALUES(276, 1, 0, 0, 420, 'vnd.wap-wml', 'vnd.wap-wml', 28);
INSERT INTO `molajo_extension_options` VALUES(277, 1, 0, 0, 420, 'vnd.wap.si', 'vnd.wap.si', 29);
INSERT INTO `molajo_extension_options` VALUES(278, 1, 0, 0, 420, 'vnd.wap.wmlscript', 'vnd.wap.wmlscript', 30);
INSERT INTO `molajo_extension_options` VALUES(279, 1, 0, 0, 430, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(280, 1, 0, 0, 430, 'jpm', 'jpm', 1);
INSERT INTO `molajo_extension_options` VALUES(281, 1, 0, 0, 430, 'mj2', 'mj2', 2);
INSERT INTO `molajo_extension_options` VALUES(282, 1, 0, 0, 430, 'quicktime', 'quicktime', 3);
INSERT INTO `molajo_extension_options` VALUES(283, 1, 0, 0, 430, 'rtp-enc-aescm128', 'rtp-enc-aescm128', 4);
INSERT INTO `molajo_extension_options` VALUES(284, 1, 0, 0, 430, 'vnd-mpegurl', 'vnd-mpegurl', 5);
INSERT INTO `molajo_extension_options` VALUES(285, 1, 0, 0, 430, 'vnd-vivo', 'vnd-vivo', 6);
INSERT INTO `molajo_extension_options` VALUES(286, 1, 0, 0, 430, 'vnd.CCTV', 'vnd.CCTV', 7);
INSERT INTO `molajo_extension_options` VALUES(287, 1, 0, 0, 430, 'vnd.dece-mp4', 'vnd.dece-mp4', 8);
INSERT INTO `molajo_extension_options` VALUES(288, 1, 0, 0, 430, 'vnd.dece.hd', 'vnd.dece.hd', 9);
INSERT INTO `molajo_extension_options` VALUES(289, 1, 0, 0, 430, 'vnd.dece.mobile', 'vnd.dece.mobile', 10);
INSERT INTO `molajo_extension_options` VALUES(290, 1, 0, 0, 430, 'vnd.dece.pd', 'vnd.dece.pd', 11);
INSERT INTO `molajo_extension_options` VALUES(291, 1, 0, 0, 430, 'vnd.dece.sd', 'vnd.dece.sd', 12);
INSERT INTO `molajo_extension_options` VALUES(292, 1, 0, 0, 430, 'vnd.dece.video', 'vnd.dece.video', 13);
INSERT INTO `molajo_extension_options` VALUES(293, 1, 0, 0, 430, 'vnd.directv-mpeg', 'vnd.directv-mpeg', 14);
INSERT INTO `molajo_extension_options` VALUES(294, 1, 0, 0, 430, 'vnd.directv.mpeg-tts', 'vnd.directv.mpeg-tts', 15);
INSERT INTO `molajo_extension_options` VALUES(295, 1, 0, 0, 430, 'vnd.dvb.file', 'vnd.dvb.file', 16);
INSERT INTO `molajo_extension_options` VALUES(296, 1, 0, 0, 430, 'vnd.fvt', 'vnd.fvt', 17);
INSERT INTO `molajo_extension_options` VALUES(297, 1, 0, 0, 430, 'vnd.hns.video', 'vnd.hns.video', 18);
INSERT INTO `molajo_extension_options` VALUES(298, 1, 0, 0, 430, 'vnd.iptvforum.1dparityfec-1010', 'vnd.iptvforum.1dparityfec-1010', 19);
INSERT INTO `molajo_extension_options` VALUES(299, 1, 0, 0, 430, 'vnd.iptvforum.1dparityfec-2005', 'vnd.iptvforum.1dparityfec-2005', 20);
INSERT INTO `molajo_extension_options` VALUES(300, 1, 0, 0, 430, 'vnd.iptvforum.2dparityfec-1010', 'vnd.iptvforum.2dparityfec-1010', 21);
INSERT INTO `molajo_extension_options` VALUES(301, 1, 0, 0, 430, 'vnd.iptvforum.2dparityfec-2005', 'vnd.iptvforum.2dparityfec-2005', 22);
INSERT INTO `molajo_extension_options` VALUES(302, 1, 0, 0, 430, 'vnd.iptvforum.ttsavc', 'vnd.iptvforum.ttsavc', 23);
INSERT INTO `molajo_extension_options` VALUES(303, 1, 0, 0, 430, 'vnd.iptvforum.ttsmpeg2', 'vnd.iptvforum.ttsmpeg2', 24);
INSERT INTO `molajo_extension_options` VALUES(304, 1, 0, 0, 430, 'vnd.motorola.video', 'vnd.motorola.video', 25);
INSERT INTO `molajo_extension_options` VALUES(305, 1, 0, 0, 430, 'vnd.motorola.videop', 'vnd.motorola.videop', 26);
INSERT INTO `molajo_extension_options` VALUES(306, 1, 0, 0, 430, 'vnd.mpegurl', 'vnd.mpegurl', 27);
INSERT INTO `molajo_extension_options` VALUES(307, 1, 0, 0, 430, 'vnd.ms-playready.media.pyv', 'vnd.ms-playready.media.pyv', 28);
INSERT INTO `molajo_extension_options` VALUES(308, 1, 0, 0, 430, 'vnd.nokia.interleaved-multimedia', 'vnd.nokia.interleaved-multimedia', 29);
INSERT INTO `molajo_extension_options` VALUES(309, 1, 0, 0, 430, 'vnd.nokia.videovoip', 'vnd.nokia.videovoip', 30);
INSERT INTO `molajo_extension_options` VALUES(310, 1, 0, 0, 430, 'vnd.objectvideo', 'vnd.objectvideo', 31);
INSERT INTO `molajo_extension_options` VALUES(311, 1, 0, 0, 430, 'vnd.sealed-swf', 'vnd.sealed-swf', 32);
INSERT INTO `molajo_extension_options` VALUES(312, 1, 0, 0, 430, 'vnd.sealed.mpeg1', 'vnd.sealed.mpeg1', 33);
INSERT INTO `molajo_extension_options` VALUES(313, 1, 0, 0, 430, 'vnd.sealed.mpeg4', 'vnd.sealed.mpeg4', 34);
INSERT INTO `molajo_extension_options` VALUES(314, 1, 0, 0, 430, 'vnd.sealed.swf', 'vnd.sealed.swf', 35);
INSERT INTO `molajo_extension_options` VALUES(315, 1, 0, 0, 430, 'vnd.sealedmedia.softseal-mov', 'vnd.sealedmedia.softseal-mov', 36);
INSERT INTO `molajo_extension_options` VALUES(316, 1, 0, 0, 430, 'vnd.uvvu.mp4', 'vnd.uvvu.mp4', 37);
INSERT INTO `molajo_extension_options` VALUES(317, 1, 0, 0, 1100, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(318, 1, 0, 0, 1100, 'display', 'add', 1);
INSERT INTO `molajo_extension_options` VALUES(319, 1, 0, 0, 1100, 'display', 'edit', 2);
INSERT INTO `molajo_extension_options` VALUES(320, 1, 0, 0, 1100, 'display', 'display', 3);
INSERT INTO `molajo_extension_options` VALUES(321, 1, 0, 0, 1100, 'edit', 'apply', 4);
INSERT INTO `molajo_extension_options` VALUES(322, 1, 0, 0, 1100, 'edit', 'cancel', 5);
INSERT INTO `molajo_extension_options` VALUES(323, 1, 0, 0, 1100, 'edit', 'create', 6);
INSERT INTO `molajo_extension_options` VALUES(324, 1, 0, 0, 1100, 'edit', 'save', 7);
INSERT INTO `molajo_extension_options` VALUES(325, 1, 0, 0, 1100, 'edit', 'saveascopy', 8);
INSERT INTO `molajo_extension_options` VALUES(326, 1, 0, 0, 1100, 'edit', 'saveandnew', 9);
INSERT INTO `molajo_extension_options` VALUES(327, 1, 0, 0, 1100, 'edit', 'restore', 10);
INSERT INTO `molajo_extension_options` VALUES(328, 1, 0, 0, 1100, 'multiple', 'archive', 11);
INSERT INTO `molajo_extension_options` VALUES(329, 1, 0, 0, 1100, 'multiple', 'publish', 12);
INSERT INTO `molajo_extension_options` VALUES(330, 1, 0, 0, 1100, 'multiple', 'unpublish', 13);
INSERT INTO `molajo_extension_options` VALUES(331, 1, 0, 0, 1100, 'multiple', 'spam', 14);
INSERT INTO `molajo_extension_options` VALUES(332, 1, 0, 0, 1100, 'multiple', 'trash', 15);
INSERT INTO `molajo_extension_options` VALUES(333, 1, 0, 0, 1100, 'multiple', 'feature', 16);
INSERT INTO `molajo_extension_options` VALUES(334, 1, 0, 0, 1100, 'multiple', 'unfeature', 17);
INSERT INTO `molajo_extension_options` VALUES(335, 1, 0, 0, 1100, 'multiple', 'sticky', 18);
INSERT INTO `molajo_extension_options` VALUES(336, 1, 0, 0, 1100, 'multiple', 'unsticky', 19);
INSERT INTO `molajo_extension_options` VALUES(337, 1, 0, 0, 1100, 'multiple', 'checkin', 20);
INSERT INTO `molajo_extension_options` VALUES(338, 1, 0, 0, 1100, 'multiple', 'reorder', 21);
INSERT INTO `molajo_extension_options` VALUES(339, 1, 0, 0, 1100, 'multiple', 'orderup', 22);
INSERT INTO `molajo_extension_options` VALUES(340, 1, 0, 0, 1100, 'multiple', 'orderdown', 23);
INSERT INTO `molajo_extension_options` VALUES(341, 1, 0, 0, 1100, 'multiple', 'saveorder', 24);
INSERT INTO `molajo_extension_options` VALUES(342, 1, 0, 0, 1100, 'multiple', 'delete', 25);
INSERT INTO `molajo_extension_options` VALUES(343, 1, 0, 0, 1100, 'multiple', 'copy', 26);
INSERT INTO `molajo_extension_options` VALUES(344, 1, 0, 0, 1100, 'multiple', 'move', 27);
INSERT INTO `molajo_extension_options` VALUES(345, 1, 0, 0, 1100, 'login', 'login', 28);
INSERT INTO `molajo_extension_options` VALUES(346, 1, 0, 0, 1100, 'login', 'logout', 29);
INSERT INTO `molajo_extension_options` VALUES(347, 1, 0, 0, 10100, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(348, 1, 0, 0, 10100, 'view', 'view', 1);
INSERT INTO `molajo_extension_options` VALUES(349, 1, 0, 0, 10100, 'create', 'create', 2);
INSERT INTO `molajo_extension_options` VALUES(350, 1, 0, 0, 10100, 'edit', 'edit', 3);
INSERT INTO `molajo_extension_options` VALUES(351, 1, 0, 0, 10100, 'publish', 'publish', 4);
INSERT INTO `molajo_extension_options` VALUES(352, 1, 0, 0, 10100, 'delete', 'delete', 5);
INSERT INTO `molajo_extension_options` VALUES(353, 1, 0, 0, 10100, 'administer', 'administer', 6);
INSERT INTO `molajo_extension_options` VALUES(354, 1, 0, 0, 10200, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(355, 1, 0, 0, 10200, 'create', 'add', 1);
INSERT INTO `molajo_extension_options` VALUES(356, 1, 0, 0, 10200, 'administer', 'administer', 2);
INSERT INTO `molajo_extension_options` VALUES(357, 1, 0, 0, 10200, 'edit', 'apply', 3);
INSERT INTO `molajo_extension_options` VALUES(358, 1, 0, 0, 10200, 'publish', 'archive', 4);
INSERT INTO `molajo_extension_options` VALUES(359, 1, 0, 0, 10200, '', 'cancel', 5);
INSERT INTO `molajo_extension_options` VALUES(360, 1, 0, 0, 10200, 'administer', 'checkin', 6);
INSERT INTO `molajo_extension_options` VALUES(361, 1, 0, 0, 10200, '', 'close', 7);
INSERT INTO `molajo_extension_options` VALUES(362, 1, 0, 0, 10200, 'create', 'copy', 8);
INSERT INTO `molajo_extension_options` VALUES(363, 1, 0, 0, 10200, 'create', 'create', 9);
INSERT INTO `molajo_extension_options` VALUES(364, 1, 0, 0, 10200, 'delete', 'delete', 10);
INSERT INTO `molajo_extension_options` VALUES(365, 1, 0, 0, 10200, 'view', 'view', 11);
INSERT INTO `molajo_extension_options` VALUES(366, 1, 0, 0, 10200, 'edit', 'edit', 12);
INSERT INTO `molajo_extension_options` VALUES(367, 1, 0, 0, 10200, 'publish', 'editstate', 13);
INSERT INTO `molajo_extension_options` VALUES(368, 1, 0, 0, 10200, 'publish', 'feature', 14);
INSERT INTO `molajo_extension_options` VALUES(369, 1, 0, 0, 10200, 'login', 'login', 15);
INSERT INTO `molajo_extension_options` VALUES(370, 1, 0, 0, 10200, 'logout', 'logout', 16);
INSERT INTO `molajo_extension_options` VALUES(371, 1, 0, 0, 10200, 'edit', 'manage', 17);
INSERT INTO `molajo_extension_options` VALUES(372, 1, 0, 0, 10200, 'edit', 'move', 18);
INSERT INTO `molajo_extension_options` VALUES(373, 1, 0, 0, 10200, 'publish', 'orderdown', 19);
INSERT INTO `molajo_extension_options` VALUES(374, 1, 0, 0, 10200, 'publish', 'orderup', 20);
INSERT INTO `molajo_extension_options` VALUES(375, 1, 0, 0, 10200, 'publish', 'publish', 21);
INSERT INTO `molajo_extension_options` VALUES(376, 1, 0, 0, 10200, 'publish', 'reorder', 22);
INSERT INTO `molajo_extension_options` VALUES(377, 1, 0, 0, 10200, 'publish', 'restore', 23);
INSERT INTO `molajo_extension_options` VALUES(378, 1, 0, 0, 10200, 'edit', 'save', 24);
INSERT INTO `molajo_extension_options` VALUES(379, 1, 0, 0, 10200, 'edit', 'saveascopy', 25);
INSERT INTO `molajo_extension_options` VALUES(380, 1, 0, 0, 10200, 'edit', 'saveandnew', 26);
INSERT INTO `molajo_extension_options` VALUES(381, 1, 0, 0, 10200, 'publish', 'saveorder', 27);
INSERT INTO `molajo_extension_options` VALUES(382, 1, 0, 0, 10200, 'view', 'search', 28);
INSERT INTO `molajo_extension_options` VALUES(383, 1, 0, 0, 10200, 'publish', 'spam', 29);
INSERT INTO `molajo_extension_options` VALUES(384, 1, 0, 0, 10200, 'publish', 'state', 30);
INSERT INTO `molajo_extension_options` VALUES(385, 1, 0, 0, 10200, 'publish', 'sticky', 31);
INSERT INTO `molajo_extension_options` VALUES(386, 1, 0, 0, 10200, 'publish', 'trash', 32);
INSERT INTO `molajo_extension_options` VALUES(387, 1, 0, 0, 10200, 'publish', 'unfeature', 33);
INSERT INTO `molajo_extension_options` VALUES(388, 1, 0, 0, 10200, 'publish', 'unpublish', 34);
INSERT INTO `molajo_extension_options` VALUES(389, 1, 0, 0, 10200, 'publish', 'unsticky', 35);
INSERT INTO `molajo_extension_options` VALUES(390, 7, 0, 0, 100, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(391, 7, 0, 0, 100, '__dummy', '__dummy', 1);
INSERT INTO `molajo_extension_options` VALUES(392, 11, 0, 0, 100, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(393, 11, 0, 0, 100, '__dummy', '__dummy', 1);
INSERT INTO `molajo_extension_options` VALUES(394, 11, 0, 0, 100, '', '', 0);
INSERT INTO `molajo_extension_options` VALUES(395, 11, 0, 0, 100, '__dummy', '__dummy', 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_extension_sites`
--

CREATE TABLE `molajo_extension_sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT ' ',
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `location` varchar(2048) NOT NULL,
  `custom_fields` mediumtext,
  `parameters` mediumtext,
  `metadata` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `molajo_extension_sites`
--

INSERT INTO `molajo_extension_sites` VALUES(1, 'Molajo Core', 1, 'http://update.molajo.org/core.xml', '', '', NULL);
INSERT INTO `molajo_extension_sites` VALUES(2, 'Molajo Directory', 1, 'http://update.molajo.org/directory.xml', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_group_permissions`
--

CREATE TABLE `molajo_group_permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to #_groups.id',
  `asset_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_assets.id',
  `action_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_actions.id',
  PRIMARY KEY (`id`),
  KEY `fk_group_permissions_actions_index` (`action_id`),
  KEY `fk_group_permissions_content_index` (`group_id`),
  KEY `fk_group_permissions_assets_index` (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `molajo_group_permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_group_view_groups`
--

CREATE TABLE `molajo_group_view_groups` (
  `group_id` int(11) unsigned NOT NULL COMMENT 'FK to the molajo_group table.',
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'FK to the molajo_groupings table.',
  PRIMARY KEY (`view_group_id`,`group_id`),
  KEY `fk_group_view_groups_view_groups_index` (`view_group_id`),
  KEY `fk_group_view_groups_groups_index` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_group_view_groups`
--

INSERT INTO `molajo_group_view_groups` VALUES(1, 1);
INSERT INTO `molajo_group_view_groups` VALUES(2, 2);
INSERT INTO `molajo_group_view_groups` VALUES(3, 3);
INSERT INTO `molajo_group_view_groups` VALUES(4, 4);
INSERT INTO `molajo_group_view_groups` VALUES(3, 5);
INSERT INTO `molajo_group_view_groups` VALUES(4, 5);
INSERT INTO `molajo_group_view_groups` VALUES(6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_sessions`
--

CREATE TABLE `molajo_sessions` (
  `session_id` varchar(32) NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  `session_time` varchar(14) DEFAULT ' ',
  `data` longtext,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`),
  KEY `fk_sessions_applications_index` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_sites`
--

CREATE TABLE `molajo_sites` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Application Primary Key',
  `asset_type_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT ' ' COMMENT 'Title',
  `path` varchar(2048) NOT NULL DEFAULT ' ' COMMENT 'URL Alias',
  `base_url` varchar(2048) NOT NULL DEFAULT ' ',
  `description` mediumtext,
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `metadata` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `molajo_sites`
--

INSERT INTO `molajo_sites` VALUES(1, 10, 'Molajo', '', '', 'Primary Site', '{}', '{}', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_site_applications`
--

CREATE TABLE `molajo_site_applications` (
  `site_id` int(11) unsigned NOT NULL,
  `application_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`site_id`,`application_id`),
  KEY `fk_site_applications_sites_index` (`site_id`),
  KEY `fk_site_applications_applications_index` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_site_applications`
--

INSERT INTO `molajo_site_applications` VALUES(1, 1);
INSERT INTO `molajo_site_applications` VALUES(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_site_extension_instances`
--

CREATE TABLE `molajo_site_extension_instances` (
  `site_id` int(11) unsigned NOT NULL,
  `extension_instance_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`site_id`,`extension_instance_id`),
  KEY `fk_site_extension_instances_sites_index` (`site_id`),
  KEY `fk_site_extension_instances_extension_instances_index` (`extension_instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `molajo_site_extension_instances`
--

INSERT INTO `molajo_site_extension_instances` VALUES(1, 0);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 1);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 2);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 3);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 4);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 5);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 6);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 7);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 8);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 9);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 10);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 11);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 12);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 13);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 14);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 15);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 16);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 17);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 18);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 19);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 20);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 21);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 22);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 23);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 24);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 25);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 26);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 27);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 28);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 29);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 30);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 31);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 32);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 33);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 34);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 35);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 36);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 37);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 38);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 39);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 40);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 41);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 42);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 43);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 44);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 45);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 46);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 47);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 48);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 49);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 50);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 51);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 52);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 53);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 54);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 55);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 56);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 57);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 58);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 59);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 60);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 61);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 62);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 63);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 64);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 65);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 66);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 67);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 82);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 83);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 84);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 85);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 86);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 87);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 88);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 89);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 90);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 91);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 92);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 93);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 94);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 97);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 98);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 99);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 100);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 101);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 103);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 104);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 105);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 106);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 107);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 108);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 109);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 110);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 111);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 112);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 113);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 114);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 115);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 116);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 117);
INSERT INTO `molajo_site_extension_instances` VALUES(1, 118);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_users`
--

CREATE TABLE `molajo_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `asset_type_id` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT '',
  `last_name` varchar(150) DEFAULT '',
  `content_text` mediumtext,
  `email` varchar(255) DEFAULT '  ',
  `password` varchar(100) NOT NULL DEFAULT '  ',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `send_email` tinyint(4) NOT NULL DEFAULT '0',
  `register_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_visit_datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `custom_fields` mediumtext,
  `parameters` mediumtext COMMENT 'Configurable Parameter Values',
  `metadata` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `last_name_first_name` (`last_name`,`first_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `molajo_users`
--

INSERT INTO `molajo_users` VALUES(42, 500, 'admin', 'Administrator', '', '', 'admin@example.com', 'admin', 0, '1', 0, '2011-11-11 11:11:11', '0000-00-00 00:00:00', '{}', '{}', NULL);
INSERT INTO `molajo_users` VALUES(100, 500, 'mark', 'Mark', 'Robinson', '<p>Great guy who sells insurance and coaches Little League.</p>', 'mark.robinson@example.com', 'mark', 0, '1', 0, '2011-11-02 17:45:17', '0000-00-00 00:00:00', '{"favorite_color":"red","nickname":"Fred","claim_to_fame":"No search results for Mark on Google."}', '{}', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_activity`
--

CREATE TABLE `molajo_user_activity` (
  `id` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000' COMMENT 'Foreign Key to molajo_users.id',
  `action_id` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000',
  `asset_id` int(11) unsigned zerofill NOT NULL DEFAULT '00000000000',
  `activity_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_activity_user_index` (`user_id`),
  KEY `user_activity_assets_index` (`asset_id`),
  KEY `user_activity_action_index` (`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `molajo_user_activity`
--


-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_applications`
--

CREATE TABLE `molajo_user_applications` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_users.id',
  `application_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_applications.id',
  PRIMARY KEY (`application_id`,`user_id`),
  KEY `fk_user_applications_users_index` (`user_id`),
  KEY `fk_user_applications_applications_index` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_applications`
--

INSERT INTO `molajo_user_applications` VALUES(42, 1);
INSERT INTO `molajo_user_applications` VALUES(42, 2);
INSERT INTO `molajo_user_applications` VALUES(100, 1);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_groups`
--

CREATE TABLE `molajo_user_groups` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_users.id',
  `group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_groups.id',
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `fk_molajo_user_groups_molajo_users_index` (`user_id`),
  KEY `fk_molajo_user_groups_molajo_groups_index` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_groups`
--

INSERT INTO `molajo_user_groups` VALUES(42, 3);
INSERT INTO `molajo_user_groups` VALUES(42, 4);
INSERT INTO `molajo_user_groups` VALUES(42, 5);
INSERT INTO `molajo_user_groups` VALUES(100, 3);
INSERT INTO `molajo_user_groups` VALUES(100, 6);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_user_view_groups`
--

CREATE TABLE `molajo_user_view_groups` (
  `user_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_users.id',
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_groups.id',
  PRIMARY KEY (`view_group_id`,`user_id`),
  KEY `fk_user_groups_users_index` (`user_id`),
  KEY `fk_user_view_groups_view_groups_index` (`view_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `molajo_user_view_groups`
--

INSERT INTO `molajo_user_view_groups` VALUES(42, 3);
INSERT INTO `molajo_user_view_groups` VALUES(42, 4);
INSERT INTO `molajo_user_view_groups` VALUES(42, 5);
INSERT INTO `molajo_user_view_groups` VALUES(100, 3);
INSERT INTO `molajo_user_view_groups` VALUES(100, 5);
INSERT INTO `molajo_user_view_groups` VALUES(100, 7);

-- --------------------------------------------------------

--
-- Table structure for table `molajo_view_groups`
--

CREATE TABLE `molajo_view_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `view_group_name_list` text NOT NULL,
  `view_group_id_list` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `molajo_view_groups`
--

INSERT INTO `molajo_view_groups` VALUES(1, 'Public', '1');
INSERT INTO `molajo_view_groups` VALUES(2, 'Guest', '2');
INSERT INTO `molajo_view_groups` VALUES(3, 'Registered', '3');
INSERT INTO `molajo_view_groups` VALUES(4, 'Administrator', '4');
INSERT INTO `molajo_view_groups` VALUES(5, 'Registered, Administrator', '4,5');
INSERT INTO `molajo_view_groups` VALUES(6, 'Private', '5');
INSERT INTO `molajo_view_groups` VALUES(7, 'Private', '6');

-- --------------------------------------------------------

--
-- Table structure for table `molajo_view_group_permissions`
--

CREATE TABLE `molajo_view_group_permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `view_group_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_groups.id',
  `asset_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_assets.id',
  `action_id` int(11) unsigned NOT NULL COMMENT 'Foreign Key to molajo_actions.id',
  PRIMARY KEY (`id`),
  KEY `fk_view_group_permissions_view_groups_index` (`view_group_id`),
  KEY `fk_view_group_permissions_actions_index` (`action_id`),
  KEY `fk_view_group_permissions_assets_index` (`asset_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=128 ;

--
-- Dumping data for table `molajo_view_group_permissions`
--

INSERT INTO `molajo_view_group_permissions` VALUES(1, 1, 1, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(2, 1, 2, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(3, 1, 3, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(4, 1, 5, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(5, 1, 6, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(6, 1, 7, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(7, 1, 8, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(8, 1, 9, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(9, 1, 10, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(10, 1, 12, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(11, 1, 13, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(12, 1, 14, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(13, 1, 15, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(14, 1, 16, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(15, 1, 17, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(16, 1, 18, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(17, 1, 19, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(18, 1, 20, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(19, 1, 21, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(20, 1, 22, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(21, 1, 23, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(22, 1, 24, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(23, 1, 25, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(24, 1, 26, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(25, 1, 27, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(26, 1, 28, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(27, 1, 29, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(28, 1, 30, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(29, 1, 31, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(30, 1, 32, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(31, 1, 33, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(32, 1, 34, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(33, 1, 35, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(34, 1, 36, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(35, 1, 37, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(36, 1, 38, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(37, 1, 39, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(38, 1, 40, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(39, 1, 41, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(40, 1, 42, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(41, 1, 43, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(42, 1, 44, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(43, 1, 45, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(44, 1, 46, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(45, 1, 47, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(46, 1, 48, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(47, 1, 49, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(48, 1, 50, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(49, 1, 51, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(50, 1, 52, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(51, 1, 53, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(52, 1, 54, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(53, 1, 55, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(54, 1, 56, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(55, 1, 57, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(56, 1, 58, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(57, 1, 59, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(58, 1, 60, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(59, 1, 61, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(60, 1, 62, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(61, 1, 63, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(62, 1, 64, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(63, 1, 65, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(64, 1, 66, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(65, 1, 67, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(66, 1, 68, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(67, 1, 69, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(68, 1, 70, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(69, 1, 71, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(70, 1, 72, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(71, 1, 73, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(72, 1, 74, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(73, 1, 75, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(74, 1, 76, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(75, 1, 77, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(76, 1, 78, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(77, 1, 79, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(78, 1, 80, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(79, 1, 81, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(80, 1, 82, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(81, 1, 83, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(82, 1, 84, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(83, 1, 85, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(84, 1, 86, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(85, 1, 87, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(86, 1, 88, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(87, 1, 89, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(88, 1, 90, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(89, 1, 91, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(90, 1, 92, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(91, 1, 93, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(92, 1, 94, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(93, 1, 95, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(94, 1, 96, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(95, 1, 97, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(96, 1, 98, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(97, 1, 99, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(98, 1, 100, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(99, 1, 101, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(100, 1, 102, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(101, 1, 103, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(102, 1, 104, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(103, 1, 105, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(104, 1, 106, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(105, 1, 107, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(106, 1, 108, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(107, 1, 109, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(108, 1, 110, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(109, 1, 111, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(110, 1, 112, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(111, 1, 113, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(112, 1, 139, 3);
INSERT INTO `molajo_view_group_permissions` VALUES(113, 1, 140, 3);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `molajo_application_extension_instances`
--
ALTER TABLE `molajo_application_extension_instances`
  ADD CONSTRAINT `fk_application_extensions_applications` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_application_extension_instances_extension_instances` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_assets`
--
ALTER TABLE `molajo_assets`
  ADD CONSTRAINT `fk_assets_asset_types` FOREIGN KEY (`asset_type_id`) REFERENCES `molajo_asset_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_asset_activity`
--
ALTER TABLE `molajo_asset_activity`
  ADD CONSTRAINT `fk_asset_activity_assets` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`asset_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_asset_categories`
--
ALTER TABLE `molajo_asset_categories`
  ADD CONSTRAINT `fk_asset_categories_assets` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asset_categories_categories` FOREIGN KEY (`category_id`) REFERENCES `molajo_content` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_asset_extensions`
--
ALTER TABLE `molajo_asset_extensions`
  ADD CONSTRAINT `fk_asset_modules_assets` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_asset_extension_extension_instances` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_content`
--
ALTER TABLE `molajo_content`
  ADD CONSTRAINT `fk_content_extension_instances` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extensions`
--
ALTER TABLE `molajo_extensions`
  ADD CONSTRAINT `fk_extensions_extension_sites` FOREIGN KEY (`extension_site_id`) REFERENCES `molajo_extension_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extension_instances`
--
ALTER TABLE `molajo_extension_instances`
  ADD CONSTRAINT `fk_extension_instances_extensions` FOREIGN KEY (`extension_id`) REFERENCES `molajo_extensions` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_extension_options`
--
ALTER TABLE `molajo_extension_options`
  ADD CONSTRAINT `fk_component_options_extension_instances` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_group_permissions`
--
ALTER TABLE `molajo_group_permissions`
  ADD CONSTRAINT `fk_group_permissions_actions` FOREIGN KEY (`action_id`) REFERENCES `molajo_action_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_permissions_content` FOREIGN KEY (`group_id`) REFERENCES `molajo_content` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_permissions_assets` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_group_view_groups`
--
ALTER TABLE `molajo_group_view_groups`
  ADD CONSTRAINT `fk_group_view_groups_view_groups` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_group_view_groups_groups` FOREIGN KEY (`group_id`) REFERENCES `molajo_content` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_sessions`
--
ALTER TABLE `molajo_sessions`
  ADD CONSTRAINT `fk_sessions_applications` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_site_applications`
--
ALTER TABLE `molajo_site_applications`
  ADD CONSTRAINT `fk_site_applications_sites` FOREIGN KEY (`site_id`) REFERENCES `molajo_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_site_applications_applications` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_site_extension_instances`
--
ALTER TABLE `molajo_site_extension_instances`
  ADD CONSTRAINT `fk_site_extension_instances_sites` FOREIGN KEY (`site_id`) REFERENCES `molajo_sites` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_site_extension_instances_extension_instances` FOREIGN KEY (`extension_instance_id`) REFERENCES `molajo_extension_instances` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_activity`
--
ALTER TABLE `molajo_user_activity`
  ADD CONSTRAINT `fk_user_applications_users_fk` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_activity_stream_assets_fk` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_activity_stream_action_types_fk'` FOREIGN KEY (`action_id`) REFERENCES `molajo_action_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_applications`
--
ALTER TABLE `molajo_user_applications`
  ADD CONSTRAINT `fk_user_applications_users` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_applications_applications` FOREIGN KEY (`application_id`) REFERENCES `molajo_applications` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_groups`
--
ALTER TABLE `molajo_user_groups`
  ADD CONSTRAINT `fk_user_groups_users` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_groups_groups` FOREIGN KEY (`group_id`) REFERENCES `molajo_content` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_user_view_groups`
--
ALTER TABLE `molajo_user_view_groups`
  ADD CONSTRAINT `fk_user_view_groups_users` FOREIGN KEY (`user_id`) REFERENCES `molajo_users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_view_groups_view_groups` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `molajo_view_group_permissions`
--
ALTER TABLE `molajo_view_group_permissions`
  ADD CONSTRAINT `fk_view_group_permissions_view_groups` FOREIGN KEY (`view_group_id`) REFERENCES `molajo_view_groups` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_view_group_permissions_actions` FOREIGN KEY (`action_id`) REFERENCES `molajo_action_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_view_group_permissions_assets` FOREIGN KEY (`asset_id`) REFERENCES `molajo_assets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
